#!/bin/sh

cd frontend
npm run build

rsync -aP  dist/ zpems:/home/ubuntu/www/ZP-EMS/frontend/dist/
# ssh zpems "source ~/.nvm/nvm.sh && cd /home/ubuntu/www/ZP-EMS/frontend/ && npm install && pm2 restart zpems-backend"