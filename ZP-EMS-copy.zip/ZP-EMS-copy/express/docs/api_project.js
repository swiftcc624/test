define({
  "name": "express-rest-es2017-boilerplate",
  "version": "1.2.2",
  "description": "Express boilerplate for building RESTful APIs",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2024-06-21T18:52:51.313Z",
    "url": "https://apidocjs.com",
    "version": "0.28.1"
  }
});
