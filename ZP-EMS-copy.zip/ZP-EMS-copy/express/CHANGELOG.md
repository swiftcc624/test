
1.2.1 / 2017-10-04
==================

  * Fix linter
  * Upgrade dependencies
  * Fix tests
  * Merge pull request #16 from gkatsanos/patch-1

1.2.0 / 2017-09-23
==================

  * Finish social authentication
  * WIP: Add Bearer auth strategy and create tests
  * WIP: Implementing social login
  * Merge pull request #7 from danielfsousa/greenkeeper/passport-jwt-3.0.0
  * fix(package): update passport-jwt to version 3.0.0

1.1.0 / 2017-08-12
==================

  * Fix jwtStrategy
  * Remove winston in favor of pm2 logs
  * Add docs route
  * Refactoring configuration and error handling
  * fix(package): update passport to version 0.4.0
  * chore(package): update sinon to version 3.0.0

1.0.2 / 2017-07-24
==================

  * Update README

1.0.1 / 2017-07-23
==================

  * Update docs

1.0.0 / 2017-07-23
==================

  * First release
