const mongoose = require('mongoose');

const User = require('./user.model');
const { UserType } = require('./user.model');

const customerSchema = new mongoose.Schema(
  {
    currency: {
      type: String,
      // required: true,
    },
  },
  {}
);

const Customer = User.discriminator(UserType.CUSTOMER, customerSchema);

module.exports = Customer;
