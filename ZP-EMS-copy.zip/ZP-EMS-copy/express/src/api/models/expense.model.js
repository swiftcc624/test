const mongoose = require('mongoose');

const TransactionLine = require('./transactionLine.model');
const { TransactionLineType } = require('./transactionLine.model');

// rate: total, quantity: 1, amount: rate*1=total
const expenseSchema = new mongoose.Schema({
  receiptFileId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'File',
    required: false,
  },
  merchantName: {
    type: String,
    required: true,
  },
  date: {
    type: Date,
    required: true,
  },
  categoryId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'Category',
  },
});

const Expense = TransactionLine.discriminator(
  TransactionLineType.Expense,
  expenseSchema
);

module.exports = Expense;
