const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

// TODO: complete TaskStatus to match netsuite
// const TaskStatus = ['pending', 'in_progress', 'completed'];

const taskSchema = new mongoose.Schema(
  {
    nid: {
      type: String,
      required: true,
      unique: true,
      default: uuidv4,
    },
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
    },
    status: {
      type: String,
      // enum: ['pending', 'in_progress', 'completed'],
      // default: 'pending',
    },

    projectId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'Project',
    },
    assigneeIds: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    ],
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

taskSchema.virtual('project', {
  ref: 'Project',
  localField: 'projectId',
  foreignField: '_id',
  justOne: true,
});
taskSchema.virtual('assignees', {
  ref: 'User',
  localField: 'assigneeIds',
  foreignField: '_id',
});

module.exports = mongoose.model('Task', taskSchema);
