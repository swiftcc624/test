const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const TransactionType = {
  PURCHASE_REQUISITION: 'PurchaseRequisition',
  EXPENSE_REPORT: 'ExpenseReport',
};

const transactionSchema = new mongoose.Schema(
  {
    nid: {
      type: String,
      required: true,
      unique: true,
      default: uuidv4,
    },
    date: {
      type: Date,
      default: Date.now,
    },
    memo: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      required: true,
      enum: [
        TransactionType.PURCHASE_REQUISITION,
        TransactionType.EXPENSE_REPORT,
      ],
    },

    currencyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Currency',
      required: true,
    },
    entityId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    lastSubmittedAt: { type: Date, default: null },
    deletedAt: { type: Date, default: null },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
    discriminatorKey: 'type',
  }
);

transactionSchema.virtual('lines', {
  ref: 'TransactionLine',
  localField: '_id',
  foreignField: 'transactionId',
});

transactionSchema.pre(/^find/, function (next) {
  // this query will not return soft deleted records
  this.where({ deletedAt: null });
  next();
});

const Transaction = mongoose.model('Transaction', transactionSchema);

module.exports = Transaction;
module.exports.TransactionType = TransactionType;
