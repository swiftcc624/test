const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const TransactionLineType = {
  PURCHASE_REQUISITION_LINE: 'PurchaseRequisitionLine',
  EXPENSE: 'Expense',
};

const transactionLineSchema = new mongoose.Schema(
  {
    nid: {
      type: String,
      required: true,
      unique: true,
      default: uuidv4,
    },
    quantity: {
      type: Number,
      required: true,
    },
    rate: {
      type: Number,
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      required: true,
      enum: [
        TransactionLineType.PURCHASE_REQUISITION_LINE,
        TransactionLineType.EXPENSE,
      ],
    },

    currencyId: {
      type: mongoose.Schema.Types.ObjectId,
      // required: true,
      ref: 'Currency',
    },
    itemId: {
      type: mongoose.Schema.Types.ObjectId,
      // required: true,
      ref: 'Item',
    },
    transactionId: {
      type: mongoose.Schema.Types.ObjectId,
      // required: true,
      ref: 'Transaction',
    },
    entityId: {
      type: mongoose.Schema.Types.ObjectId,
      // required: true,
      ref: 'User',
    },

    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
    discriminatorKey: 'type',
  }
);

// common virtual fields
transactionLineSchema.virtual('currency', {
  ref: 'Currency',
  localField: 'currencyId',
  foreignField: '_id',
  justOne: true,
});

transactionLineSchema.virtual('item', {
  ref: 'Item',
  localField: 'itemId',
  foreignField: '_id',
  justOne: true,
});

transactionLineSchema.virtual('entity', {
  ref: 'User',
  localField: 'entityId',
  foreignField: '_id',
  justOne: true,
});

transactionLineSchema.virtual('transaction', {
  ref: 'Transaction',
  localField: 'transactionId',
  foreignField: '_id',
  justOne: true,
});

// Expense virtual fields
transactionLineSchema.virtual('receiptFile', {
  ref: 'File',
  localField: 'receiptFileId',
  foreignField: '_id',
  justOne: true,
});

transactionLineSchema.virtual('category', {
  ref: 'Category',
  localField: 'categoryId',
  foreignField: '_id',
  justOne: true,
});

transactionLineSchema.pre(/^find/, function (next) {
  // this query will not return soft deleted records
  this.where({ deletedAt: null });
  next();
});

const TransactionLine = mongoose.model(
  'TransactionLine',
  transactionLineSchema
);

module.exports = TransactionLine;
module.exports.TransactionLineType = TransactionLineType;
