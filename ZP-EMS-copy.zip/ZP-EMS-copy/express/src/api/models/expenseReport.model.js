const mongoose = require('mongoose');

const Transaction = require('./transaction.model');
const { TransactionType } = require('./transaction.model');

const expenseReportSchema = new mongoose.Schema({
  status: {
    type: String,
    enum: ['open', 'submitted', 'approved', 'rejected'],
    default: 'open',
  },
  tranId: {
    type: String,
    unique: true,
  },
});

const CounterSchema = new mongoose.Schema({
  _id: String,
  seq: { type: Number, default: 0 },
});

const Counter = mongoose.model('Counter', CounterSchema);

expenseReportSchema.pre('save', async function (next) {
  if (!this.tranId) {
    const countUpdate = await Counter.findByIdAndUpdate(
      { _id: 'expenseReportTranId' },
      { $inc: { seq: 1 } },
      { new: true, upsert: true }
    );
    this.tranId = countUpdate.seq.toString();
  }
  next();
});

const ExpenseReport = Transaction.discriminator(
  TransactionType.EXPENSE_REPORT,
  expenseReportSchema
);

module.exports = ExpenseReport;

// expenseReportSchema.pre(/^find/, function (next) {
//   this.find({ deletedAt: null });
//   next();
// });
