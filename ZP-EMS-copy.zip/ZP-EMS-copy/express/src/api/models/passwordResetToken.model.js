const mongoose = require('mongoose');
const crypto = require('crypto');
const moment = require('moment-timezone');
const { v4: uuidv4 } = require('uuid');

/**
 * Refresh Token Schema
 * @private
 */
const passwordResetTokenSchema = new mongoose.Schema({
  resetToken: {
    type: String,
    required: true,
    index: true,
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'User',
  },
  userEmail: {
    type: 'String',
    required: true,
    // ref: 'User',
  },
  expires: { type: Date },
});

passwordResetTokenSchema.statics = {
  /**
   * Generate a reset token object and saves it into the database
   *
   * @param {User} user
   * @returns {ResetToken}
   */
  async generate(user) {
    const userId = user._id;
    const userEmail = user.email;
    const resetToken = `${userId}.${crypto.randomBytes(40).toString('hex')}`;
    const expires = moment().add(2, 'hours').toDate();
    const ResetTokenObject = new PasswordResetToken({
      resetToken,
      userId,
      userEmail,
      expires,
    });
    await ResetTokenObject.save();
    return ResetTokenObject;
  },
};

/**
 * @typedef RefreshToken
 */
const PasswordResetToken = mongoose.model(
  'PasswordResetToken',
  passwordResetTokenSchema
);
module.exports = PasswordResetToken;
