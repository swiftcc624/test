const mongoose = require('mongoose');

const asyncTaskSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      enum: ['waiting', 'active', 'completed', 'failed'],
      default: 'waiting',
    },
    taskData: {
      type: Object,
      default: {},
    },
    priority: {
      type: Number,
      default: 0,
    },
    resultData: {
      type: Object,
      default: {},
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

module.exports = mongoose.model('AsyncTask', asyncTaskSchema);
