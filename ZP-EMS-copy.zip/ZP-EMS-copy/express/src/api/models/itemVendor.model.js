const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const itemVendorSchema = new mongoose.Schema(
  {
    nid: {
      type: String,
      required: true,
      unique: true,
      default: uuidv4,
    },

    isPreferred: {
      type: Boolean,
      required: true,
    },
    vendorPrice: {
      type: Number,
      required: false,
    },

    itemId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'Item',
    },
    vendorId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
    currencyId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'Currency',
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

itemVendorSchema.virtual('vendor', {
  ref: 'User',
  localField: 'vendorId',
  foreignField: '_id',
  justOne: true,
});
itemVendorSchema.virtual('currency', {
  ref: 'Currency',
  localField: 'currencyId',
  foreignField: '_id',
  justOne: true,
});

module.exports = mongoose.model('ItemVendor', itemVendorSchema);
