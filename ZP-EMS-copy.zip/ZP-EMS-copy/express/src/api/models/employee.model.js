const mongoose = require('mongoose');

const User = require('./user.model');
const { UserType } = require('./user.model');

const employeeSchema = new mongoose.Schema({}, {});

const Employee = User.discriminator(UserType.EMPLOYEE, employeeSchema);

module.exports = Employee;
