const mongoose = require('mongoose');

const TransactionLine = require('../models/transactionLine.model');
const { TransactionLineType } = require('../models/transactionLine.model');

const purchaseRequisitionLineSchema = new mongoose.Schema(
  {
    vendorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  {}
);

const PurchaseRequisitionLine = TransactionLine.discriminator(
  TransactionLineType.PURCHASE_REQUISITION_LINE,
  purchaseRequisitionLineSchema
);

module.exports = PurchaseRequisitionLine;
