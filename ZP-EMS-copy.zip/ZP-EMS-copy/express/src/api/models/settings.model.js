const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const expenseReportSchema = new mongoose.Schema(
  {
    logo: {
      type: String,
      default: null,
    },
    dateFormat: {
      type: String,
      default: 'MM/DD/YYYY',
    },
    timeFormat: {
      type: String,
      default: 'HH:mm:ss',
    },
    emailDomain: {
      type: String,
    },

    netsuiteConnectionInfo: {
      type: Object,
      default: null,
    },
    openAIAPIKey: {
      type: String,
      default: null,
    },
    expenseSettings: {
      type: Object,
      default: null,
    },
    expenseReportSettings: {
      type: Object,
      default: null,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

module.exports = mongoose.model('Settings', expenseReportSchema);
