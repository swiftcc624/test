const mongoose = require('mongoose');

const User = require('../models/user.model');
const { UserType } = require('../models/user.model');

const addressSchema = new mongoose.Schema(
  {
    type: {
      type: String, // 1: Individual, 2: Company
      required: true,
    },
    contactEmail: {
      type: String,
      required: true,
    },
    phoneCode: {
      type: String,
      required: true,
    },
    phoneNumber: {
      type: String,
      required: true,
    },
    firstName: {
      type: String,
      required: true,
    },
    middleName: {
      type: String,
    },
    lastName: {
      type: String,
      required: true,
    },
    company: {
      type: String,
    },
    address1: {
      type: String,
      required: true,
    },
    address2: {
      type: String,
    },
    city: {
      type: String,
      required: true,
    },
    country: {
      type: String,
      required: true,
    },
    state: {
      type: String,
      required: true,
    },
    zip: {
      type: String,
      required: true,
    },
  },
  {
    _id: false,
  }
);

const paymentMethodSchema = new mongoose.Schema(
  {
    method: {
      type: String, // 1: Check, 2: Other
      required: true,
    },
  },
  {
    _id: false,
  }
);

const taxFormSchema = new mongoose.Schema(
  {
    taxFormFileId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'File',
    },
  },
  { _id: false, toJSON: { virtuals: true }, toObject: { virtuals: true } }
);

taxFormSchema.virtual('taxFormFile', {
  ref: 'File',
  localField: 'taxFormFileId',
  foreignField: '_id',
  justOne: true,
});

const vendorSchema = new mongoose.Schema(
  {
    address: addressSchema,
    paymentMethod: {
      type: Object,
      required: false,
    },
    taxForm: taxFormSchema,
  },
  {}
);

const Vendor = User.discriminator(UserType.VENDOR, vendorSchema);

module.exports = Vendor;
