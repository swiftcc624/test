const mongoose = require('mongoose');

const Transaction = require('../models/transaction.model');
const { TransactionType } = require('../models/transaction.model');

const purchaseRequisitionSchema = new mongoose.Schema(
  {
    receiveBy: {
      type: Date,
      required: true,
    },
  },
  {}
);

const PurchaseRequisition = Transaction.discriminator(
  TransactionType.PURCHASE_REQUISITION,
  purchaseRequisitionSchema
);

module.exports = PurchaseRequisition;
