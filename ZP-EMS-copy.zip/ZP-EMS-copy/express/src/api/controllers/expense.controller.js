const mongoose = require('mongoose');
const httpStatus = require('http-status');
const Expense = require('../models/expense.model');
const Category = require('../models/category.model');
const File = require('../models/file.model');

const fs = require('fs');
const { parse } = require('csv-parse/sync');

const {
  parseReceiptImageWithChatGPT,
  getChatgptCompletion,
} = require('../services/openai');

const pdfParse = require('pdf-parse');

const parsePdf = async (filePath) => {
  const dataBuffer = fs.readFileSync(filePath);
  const data = await pdfParse(dataBuffer);
  return data.text;
};

const {
  getPagination,
  getSortOptions,
  buildPaginatedResponse,
} = require('../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const sortOptions = getSortOptions(req);
    const { offset, limit } = getPagination(req);

    const {
      dateFrom,
      dateTo,
      merchantName,
      categoryId,
      entityScope = 'all',
      status,
    } = req.query;
    const filters = {};
    if (dateFrom || dateTo) {
      filters.date = {};
      if (dateFrom) filters.date.$gte = new Date(dateFrom);
      if (dateTo) filters.date.$lte = new Date(dateTo);
    }
    if (merchantName) filters.merchantName = new RegExp(merchantName, 'i');
    if (categoryId)
      filters.categoryId =
        mongoose.Types.ObjectId.createFromHexString(categoryId);
    if (req.user.role !== 'admin') {
      filters['entityId'] = req.user._id;
    } else {
      if (entityScope === 'mine') {
        filters['entityId'] = req.user._id;
      } else if (entityScope === 'others') {
        filters['entityId'] = { $ne: req.user._id };
      }
    }

    const statusFilter = {};
    if (status) {
      if (!status.includes('not_reported')) {
        statusFilter['transaction.status'] = { $in: status.split(',') };
      } else {
        statusFilter['$or'] = [
          { 'transaction.status': { $in: status.split(',') } },
          { transaction: null },
        ];
      }
    }

    const pipeline = [
      {
        $match: { ...filters, deletedAt: null },
      },
      {
        $lookup: {
          from: 'categories',
          localField: 'categoryId',
          foreignField: '_id',
          as: 'category',
        },
      },
      {
        $unwind: {
          path: '$category',
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: 'currencies',
          localField: 'currencyId',
          foreignField: '_id',
          as: 'currency',
        },
      },
      {
        $unwind: {
          path: '$currency',
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: 'files',
          localField: 'receiptFileId',
          foreignField: '_id',
          as: 'receiptFile',
        },
      },
      {
        $unwind: {
          path: '$receiptFile',
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: 'users',
          localField: 'entityId',
          foreignField: '_id',
          as: 'entity',
        },
      },
      {
        $unwind: {
          path: '$entity',
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: 'transactions',
          localField: 'transactionId',
          foreignField: '_id',
          as: 'transaction',
        },
      },
      {
        $unwind: {
          path: '$transaction',
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: statusFilter,
      },
    ];

    let totalResults = await Expense.aggregate([
      ...pipeline,
      { $count: 'totalResults' },
    ]);
    totalResults = totalResults?.[0]?.totalResults || 0;

    if (Object.keys(sortOptions).length > 0) {
      pipeline.push({ $sort: sortOptions });
    }
    if (offset > 0) {
      pipeline.push({ $skip: offset });
    }
    if (limit > 0) {
      pipeline.push({ $limit: limit });
    }

    let query = Expense.aggregate(pipeline);
    const items = await query.exec();

    const results = await buildPaginatedResponse(items, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const expense = new Expense({
      ...req.body,
    });
    const savedExpense = await expense.save();
    res.status(httpStatus.CREATED);
    res.json(savedExpense);
  } catch (error) {
    next(error);
  }
};

exports.get = async (req, res, next) => {
  try {
    const expense = await Expense.findById(req.params.id);
    res.json(expense);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const expense = await Expense.findById(req.params.id);

    if (!expense) {
      return res.status(404).send('Expense not found');
    }

    if (req.body.rate) {
      expense.quantity = 1;
      expense.amount = req.body.rate;
    }

    Object.keys(req.body).forEach((key) => {
      expense[key] = req.body[key];
    });
    const savedExpense = await expense.save();
    res.json(savedExpense);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const expense = await Expense.findById(req.params.id);

    if (!expense) {
      return res.status(404).send('Expense not found');
    }

    expense.deletedAt = new Date();
    await expense.save();

    res.status(httpStatus.NO_CONTENT).end();
  } catch (error) {
    next(error);
  }
};

exports.group = async (req, res, next) => {
  const {
    dateFrom,
    dateTo,
    merchantName,
    categoryId,
    entityScope = 'all',
    status,
  } = req.query;

  const filters = {};
  if (dateFrom || dateTo) {
    filters.date = {};
    if (dateFrom) filters.date.$gte = new Date(dateFrom);
    if (dateTo) filters.date.$lte = new Date(dateTo);
  }
  if (merchantName) filters.merchantName = new RegExp(merchantName, 'i');
  if (categoryId) {
    filters.categoryId =
      mongoose.Types.ObjectId.createFromHexString(categoryId);
  }
  if (status) {
    filters['transaction.status'] = { $in: status.split(',') };
  }

  if (req.user.role !== 'admin') {
    filters['entityId'] = req.user._id;
  } else {
    if (entityScope === 'mine') {
      filters['entityId'] = req.user._id;
    } else if (entityScope === 'others') {
      filters['entityId'] = { $ne: req.user._id };
    }
  }

  console.log('filters', filters);

  try {
    const expenseGroup = await Expense.aggregate([
      {
        $match: {
          deletedAt: null,
        },
      },
      {
        $lookup: {
          from: 'transactions',
          localField: 'transactionId',
          foreignField: '_id',
          as: 'transaction',
        },
      },
      {
        $match: filters,
      },
      {
        $group: {
          _id: '$categoryId',
          total: { $sum: '$amount' },
          count: { $sum: 1 },
          average: { $avg: '$amount' },
          lines: { $push: '$$ROOT' },
        },
      },

      {
        $lookup: {
          from: 'categories', // use the actual name of the categories collection
          localField: '_id',
          foreignField: '_id',
          as: 'category',
        },
      },
      {
        $unwind: '$category',
      },
    ]);
    res.json(expenseGroup);
  } catch (error) {
    next(error);
  }
};

exports.scanReceipt = async (req, res, next) => {
  try {
    const { receiptFileId } = req.body;

    console.log('receiptFileId', receiptFileId);
    const receiptFile = await File.findById(receiptFileId);
    console.log('receiptFile', receiptFile);

    if (!receiptFile) {
      return res.status(400).send('Receipt file not found');
    }

    let parsedData;

    const receiptFileType = receiptFile.url.endsWith('.pdf') ? 'pdf' : 'image';
    if (receiptFileType === 'pdf') {
      parsedData = await parsePdf(receiptFile.filepath);
    } else {
      parsedData = await parseReceiptImageWithChatGPT(receiptFile.filepath);
    }

    console.log('result', parsedData);

    const categories = await Category.find({ status: 'active' });

    const userMessage = `
Here are expense categories as array:
    ${JSON.stringify(categories.map(({ name, id }) => ({ name, id })))}
------------------------------------------------------------------------------------------------------------------------------------------------

Here is expense info:
    ${parsedData}
------------------------------------------------------------------------------------------------------------------------------------------------

I need to know the expense category of the expense info, merchant name, date and total amount.

please give me response as the following json format:

{
  categoryId: [category id],
  merchantName: [merchant name],
  date: [date],
  total: [total amount in number, no currency symbol],
  currency: [currency],
}
    `;
    const expenseData = await getChatgptCompletion({
      systemMessage: 'You are a helpful assistant.',
      userMessage,
    });

    res.json({ result: parsedData, expenseData });
  } catch (error) {
    next(error);
  }
};

exports.importFromCsv = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).send('No file uploaded.');
    }

    const csvData = fs.readFileSync(req.file.path, 'utf8');
    const records = parse(csvData, {
      columns: true,
      skip_empty_lines: true,
    });

    const expenses = await Promise.all(
      records.map(async (record) => {
        const category = await Category.findOne({ name: record.Category });
        return {
          merchantName: record.Merchant,
          date: new Date(record.ExpenseDate),
          total: parseFloat(record.Total),
          category: category.id,
          attendee: record.Attendee,
          currency: 'USD',
        };
      })
    );

    const savedExpenses = await Expense.insertMany(expenses);
    res.json(savedExpenses);
  } catch (error) {
    next(error);
  }
};
