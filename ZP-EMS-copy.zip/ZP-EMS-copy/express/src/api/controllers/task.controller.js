const httpStatus = require('http-status');
const Task = require('../models/task.model');

exports.list = async (req, res, next) => {
  try {
    const { projectId, sorting } = req.query;

    // filtering
    const queryOptions = {};
    if (projectId) {
      queryOptions['projectId'] = projectId;
    }

    // sorting
    const sortOptions = {};
    if (sorting) {
      const sortFields = sorting.split(',');
      sortFields.forEach((sortField) => {
        const sortOrder = sortField.startsWith('-') ? -1 : 1;
        const fieldName = sortField.replace(/^-/, '').replace(/-/, '.');
        sortOptions[fieldName] = sortOrder;
      });
    }

    const tasks = await Task.find(queryOptions)
      .populate({
        path: 'projectId',
        populate: {
          path: 'customerId',
        },
      })
      .populate('assigneeIds')
      .sort(sortOptions);

    res.json(tasks);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { projectId, name, description, assigneeIds } = req.body;

    const task = await Task.finOne({ id });
    if (!task) {
      return res.status(httpStatus.NOT_FOUND).end();
    }

    task.projectId = projectId;
    task.name = name;
    task.description = description;
    task.assigneeIds = assigneeIds;
    task.save();

    res.json(task);
  } catch (error) {
    next(error);
  }
};
