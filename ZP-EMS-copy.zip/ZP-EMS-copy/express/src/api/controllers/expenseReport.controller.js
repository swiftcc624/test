const moment = require('moment-timezone');
const httpStatus = require('http-status');
const ExpenseReport = require('../models/expenseReport.model');
const Expense = require('../models/expense.model');
const Category = require('../models/category.model');
const User = require('../models/user.model');

const {
  createExpenseReport,
  updateExpenseReport,
  executeSuiteQLQuery,
} = require('../services/netsuite');

const {
  getPagination,
  getSortOptions,
  buildPaginatedResponse,
} = require('../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const sortOptions = getSortOptions(req);
    const { offset, limit } = getPagination(req);

    const { dateFrom, dateTo, memo, tranId, entityScope, status } = req.query;

    const filters = {};
    if (dateFrom || dateTo) {
      filters.date = {};
      if (dateFrom) filters.date.$gte = new Date(dateFrom);
      if (dateTo) filters.date.$lte = new Date(dateTo);
    }
    if (tranId) filters.tranId = tranId;
    if (memo) filters.memo = new RegExp(memo, 'i');
    if (tranId) filters.tranId = new RegExp(tranId, 'i');
    if (status) filters.status = { $in: status.split(',') };

    if (req.user.role !== 'admin') {
      filters['entityId'] = req.user._id;
    } else {
      if (entityScope === 'mine') {
        filters.entityId = req.user._id;
      } else if (entityScope === 'others') {
        filters.entityId = { $ne: req.user._id };
      }
    }
    console.log('filters', filters);

    let query = ExpenseReport.find(filters)
      .populate({
        path: 'lines',
        populate: {
          path: 'category',
          model: 'Category',
        },
      })
      .sort(sortOptions)
      .skip(offset);
    if (limit > 0) {
      query = query.limit(limit);
    }
    const items = await query.exec();

    const totalResults = await ExpenseReport.countDocuments(filters);

    const results = await buildPaginatedResponse(items, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const expenseReport = new ExpenseReport({ ...req.body });
    const savedExpenseReport = await expenseReport.save();

    res.status(httpStatus.CREATED);
    res.json(savedExpenseReport);
  } catch (error) {
    next(error);
  }
};

exports.get = async (req, res, next) => {
  try {
    const expenseReport = await ExpenseReport.findById(req.params.id);
    res.json(expenseReport);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const expenseReport = await ExpenseReport.findById(req.params.id);

    if (!expenseReport) {
      return res.status(404).send('Expense report not found');
    }

    Object.keys(req.body).forEach((key) => {
      expenseReport[key] = req.body[key];
    });
    const savedExpenseReport = await expenseReport.save();
    res.json(savedExpenseReport);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const expenseReport = await ExpenseReport.findById(req.params.id);

    if (!expenseReport) {
      return res.status(404).send('Expense report not found');
    }

    expenseReport.deletedAt = new Date();
    await expenseReport.save();

    res.status(httpStatus.NO_CONTENT).end();
  } catch (error) {
    next(error);
  }
};

exports.submit = async (req, res, next) => {
  try {
    const expenseReport = await ExpenseReport.findById(req.params.id).populate({
      path: 'lines',
      populate: [
        {
          path: 'category',
          model: 'Category',
        },
        {
          path: 'currency',
          model: 'Currency',
        },
      ],
    });

    const items = [];
    for (const expense of expenseReport.lines) {
      items.push({
        category: {
          id: parseInt(expense.category.nid),
        },
        amount: expense.amount,
        currency: parseInt(expense.currency.nid),
        memo: expense.description,
        expensedate: moment(expense.date).format('YYYY-MM-DD'),
      });
    }

    const entity = await User.findById(expenseReport.entityId);

    const body = {
      supervisorapproval: true,
      accountingapproval: true,
      externalid: expenseReport._id,
      entity: {
        id: entity.nid,
      },
      expense: { items },
      memo: expenseReport.memo,
    };

    try {
      const result = await executeSuiteQLQuery(
        `SELECT id from transaction where recordtype ='expensereport' AND externalid='${expenseReport._id}'`
      );
      const nid = result?.items?.[0]?.id;

      if (!nid) {
        const data = await createExpenseReport(body);
        console.log('AAA --- submitted to netsuite', data);

        const result = await executeSuiteQLQuery(
          `SELECT id from transaction where recordtype ='expensereport' AND externalid='${expenseReport._id}'`
        );
        expenseReport.lastSubmittedAt = new Date();
        expenseReport.status = 'submitted';
        expenseReport.nid = result.items[0].id;
        await expenseReport.save();
        res.json({ ok: true, body, response: data, error: null });
      } else {
        // const data = await updateExpenseReport(15619, body);
        const data = await updateExpenseReport(nid, body);
        console.log('AAA --- submitted to netsuite', data);

        expenseReport.lastSubmittedAt = new Date();
        expenseReport.nid = nid;
        await expenseReport.save();
        res.json({ ok: true, body, response: data, error: null });
      }
    } catch (error) {
      console.log(error);

      res.status(httpStatus.BAD_REQUEST).json({
        ok: false,
        body,
        error: error.response.data,
      });
    }
  } catch (error) {
    next(error);
  }
};

const fs = require('fs');
const { parse } = require('csv-parse/sync');

// TODO: implement importFromCsv
exports.importFromCsv = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).send('No file uploaded.');
    }

    const csvData = fs.readFileSync(req.file.path, 'utf8');
    const records = parse(csvData, {
      columns: true,
      skip_empty_lines: true,
    });

    const expenseReports = [];

    for (const record of records) {
      let found = expenseReports.find((x) => x.id === record.ExpenseReportID);
      if (found) {
        if (record.Merchant && record.ExpenseDate && record.Total) {
          const category = await Category.findOne({ name: record.Category });

          found.expenses.push({
            userId: req.user._id,
            merchantName: record.Merchant,
            date: new Date(record.ExpenseDate),
            total: parseFloat(record.Total),
            category: category._id,
            attendee: record.Attendee,
            currency: 'USD',
          });
        }
      } else {
        const expenseReport = {
          id: record.ExpenseReportID,
          name: record.ReportName,
          date: new Date(record.ExpenseReportDate),
          status: record.Status,
          submittedAt: record.SubmittedAt,

          expenses: [],
        };

        if (record.Merchant && record.ExpenseDate && record.Total) {
          const category = await Category.findOne({ name: record.Category });

          expenseReport.expenses.push({
            userId: req.user._id,
            merchantName: record.Merchant,
            date: new Date(record.ExpenseDate),
            total: parseFloat(record.Total),
            category: category._id,
            attendee: record.Attendee,
            currency: 'USD',
          });
        }

        expenseReports.push(expenseReport);
      }
    }

    for (const expenseReport of expenseReports) {
      const expenses = expenseReport.expenses;
      delete expenseReport.id;
      delete expenseReport.expenses;

      const savedExpenseReport = await new ExpenseReport(expenseReport).save();
      console.log('saved expense report', savedExpenseReport);

      const savedExpenses = await Expense.insertMany(
        expenses.map((x) => ({ ...x, expenseReportId: savedExpenseReport.id }))
      );
    }

    res.status(httpStatus.NO_CONTENT).end();
  } catch (error) {
    next(error);
  }
};
