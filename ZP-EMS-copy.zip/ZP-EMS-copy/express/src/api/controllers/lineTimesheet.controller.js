const httpStatus = require('http-status');
const LineTimesheet = require('../models/lineTimesheet.model');
const TimeEntry = require('../models/timeEntry.model');
const { isUUIDv4 } = require('../utils/utils');

const {
  createTimeEntry,
  updateTimeEntry,
  executeSuiteQLQuery,
} = require('../services/netsuite');

const {
  getPagination,
  getQueryOptions,
  getSortOptions,
  buildPaginatedResponse,
} = require('../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const { weekStartDate } = req.query;

    const timesheets = await LineTimesheet.aggregate([
      {
        $match: {
          weekStartDate: new Date(weekStartDate),
          userId: req.user._id,
        },
      },
      {
        $lookup: {
          from: 'timeentries',
          localField: '_id',
          foreignField: 'lineTimesheetId',
          as: 'timeEntries',
        },
      },
    ]);

    res.json(timesheets);
  } catch (error) {
    next(error);
  }
};

exports.getWeeklyTimesheets = async (req, res, next) => {
  const { offset, limit } = getPagination(req);
  const sortOptions = getSortOptions(req);

  const { dateFrom, dateTo } = req.query;
  const queryOptions = {};
  if (dateFrom || dateTo) {
    queryOptions.date = {};
    if (dateFrom) queryOptions.date.$gte = new Date(dateFrom);
    if (dateTo) queryOptions.date.$lte = new Date(dateTo);
  }

  try {
    const pipeline = [
      {
        $match: {
          userId: req.user._id,
          ...queryOptions,
        },
      },
      {
        $lookup: {
          from: 'linetimesheets', // Ensure this is the correct collection name
          localField: 'lineTimesheetId',
          foreignField: '_id',
          as: 'lineTimesheet',
        },
      },
      {
        $unwind: '$lineTimesheet', // Deconstruct the array to sum durations
      },
      {
        $group: {
          _id: '$lineTimesheet.weekStartDate', // Group by week start date
          totalDuration: { $sum: '$$ROOT.duration' }, // Sum the duration of time entries
          timeEntries: { $push: '$$ROOT' }, // Collect all lineTimesheets under the week start date
        },
      },
    ];

    let totalResults = await TimeEntry.aggregate([
      ...pipeline,
      { $count: 'totalResults' },
    ]);
    totalResults = totalResults?.[0]?.totalResults || 0;

    if (Object.keys(sortOptions).length > 0) {
      pipeline.push({ $sort: sortOptions });
    }
    if (offset > 0) {
      pipeline.push({ $skip: offset });
    }
    if (limit > 0) {
      pipeline.push({ $limit: limit });
    }

    const timesheets = await TimeEntry.aggregate(pipeline);
    const results = await buildPaginatedResponse(timesheets, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const timesheet = new LineTimesheet({
      ...req.body,
      userId: req.user._id,
    });
    await timesheet.save();
    res.status(httpStatus.CREATED);
    res.json(timesheet);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const { id } = req.params;
    const lineTimesheet = await LineTimesheet.findById(id);
    Object.keys(req.body).forEach((key) => {
      lineTimesheet[key] = req.body[key];
    });
    const savedLineTimesheet = await lineTimesheet.save();

    res.json(savedLineTimesheet);
  } catch (error) {
    next(error);
  }
};

exports.createOrUpdateTimeEntry = async (req, res, next) => {
  try {
    const { id } = req.params;
    const lineTimesheet = await LineTimesheet.findById(id);

    if (!lineTimesheet) {
      throw new Error('Line timesheet not found');
    }

    const { date } = req.body;

    if (!date) {
      throw new Error('Date is required');
    }

    const timeEntry = await TimeEntry.findOne({
      lineTimesheetId: id,
      date,
      userId: req.user._id,
    });

    if (timeEntry) {
      Object.keys(req.body).forEach((key) => {
        timeEntry[key] = req.body[key];
      });
      await timeEntry.save();
      res.json(timeEntry);
    } else {
      const savedTimeEntry = await TimeEntry.create({
        lineTimesheetId: id,
        date,
        userId: req.user._id,
        ...req.body,
      });
      res.json(savedTimeEntry);
    }
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const { id } = req.params;
    await TimeEntry.deleteMany({ lineTimesheetId: id });
    await LineTimesheet.findByIdAndDelete(id);
    res.status(httpStatus.NO_CONTENT);
    res.end();
  } catch (error) {
    next(error);
  }
};

function formatHours(hours) {
  const wholeHours = Math.floor(hours);
  const minutes = Math.round((hours - wholeHours) * 60);
  return `${wholeHours}:${minutes < 10 ? '0' : ''}${minutes}`;
}

const submitTimeEntry = async (timeEntry, lineTimesheet, user) => {
  const body = {
    externalid: timeEntry._id,
    employee: user.nid,
    customer: lineTimesheet.project.nid,
    caseTaskEvent: lineTimesheet.task.nid,
    // item: "176",
    trandate: timeEntry.date,
    hours: formatHours(timeEntry.duration),
    subsidiary: 1,
    location: 1,
    memo: timeEntry.description,
  };

  console.log(body);

  if (isUUIDv4(timeEntry.nid)) {
    const data = await createTimeEntry(body);
    console.log('submitted to netsuite - created', data);

    const result = await executeSuiteQLQuery(
      `SELECT id, displayfield FROM timebill where externalid='${timeEntry._id}'`
    );

    await TimeEntry.findByIdAndUpdate(
      timeEntry._id,
      {
        submittedAt: new Date(),
        nid: result.items[0].id,
      },
      { new: true } // this option returns the updated document
    );
  } else {
    const data = await updateTimeEntry(timeEntry.nid, body);
    console.log('submitted to netsuite - updated', data);

    await TimeEntry.findByIdAndUpdate(
      timeEntry._id,
      {
        submittedAt: new Date(),
      },
      { new: true } // this option returns the updated document
    );
  }
};

exports.submitTimeEntries = async (req, res, next) => {
  try {
    const { weekStartDate } = req.query;

    const timesheets = await LineTimesheet.aggregate([
      {
        $match: {
          weekStartDate: new Date(weekStartDate),
          userId: req.user._id,
        },
      },
      {
        $lookup: {
          from: 'timeentries',
          localField: '_id',
          foreignField: 'lineTimesheetId',
          as: 'timeEntries',
        },
      },
      {
        $lookup: {
          from: 'tasks',
          localField: 'taskId',
          foreignField: '_id',
          as: 'task',
        },
      },
      {
        $lookup: {
          from: 'projects',
          localField: 'projectId',
          foreignField: '_id',
          as: 'project',
        },
      },
      {
        $unwind: '$task',
      },
      {
        $unwind: '$project',
      },
      {
        $lookup: {
          from: 'users',
          localField: 'project.customerId',
          foreignField: '_id',
          as: 'customer',
        },
      },
      {
        $unwind: {
          path: '$customer',
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);

    for (const timesheet of timesheets) {
      for (const timeEntry of timesheet.timeEntries) {
        try {
          await submitTimeEntry(timeEntry, timesheet, req.user);
        } catch (error) {
          console.log(error.response?.data);
          res.status(httpStatus.BAD_REQUEST).json({
            ok: false,
            body,
            error: error.response?.data,
          });
        }
      }
    }

    res.json(timesheets);
  } catch (error) {
    next(error);
  }
};
