const httpStatus = require('http-status');

const Vendor = require('../models/vendor.model');

exports.get = async (req, res, next) => {
  try {
    const { id } = req.params;

    const vendor = await Vendor.findById(id).populate('taxForm.taxFormFile');

    res.json(vendor);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const { id } = req.params;
    const vendor = await Vendor.findById(id);
    if (!vendor) {
      return res.status(httpStatus.NOT_FOUND).end();
    }

    Object.keys(req.body).forEach((key) => {
      vendor[key] = req.body[key];
    });

    const savedVender = await vendor.save();

    res.json(savedVender);
  } catch (error) {
    next(error);
  }
};
