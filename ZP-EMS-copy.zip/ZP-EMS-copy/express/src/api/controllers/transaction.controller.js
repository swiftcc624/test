const httpStatus = require('http-status');
const Transaction = require('../models/transaction.model');
const { TransactionType } = require('../models/transaction.model');
const TransactionLine = require('../models/transactionLine.model');
const PurchaseRequisition = require('../models/purchaseRequisition.model');
const PurchaseRequisitionLine = require('../models/purchaseRequisitionLine.model');

const {
  getPagination,
  getQueryOptions,
  getSortOptions,
  buildPaginatedResponse,
} = require('../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const { offset, limit } = getPagination(req);
    const queryOptions = getQueryOptions(req);
    const sortOptions = getSortOptions(req);

    let query = Transaction.find(queryOptions);
    if (Object.keys(sortOptions).length > 0) {
      query = query.sort(sortOptions);
    }
    if (offset > 0) {
      query = query.skip(offset);
    }
    if (limit > 0) {
      query = query.limit(limit);
    }

    const totalResults = await Transaction.countDocuments(queryOptions);

    const transactions = await query.exec();

    const results = await buildPaginatedResponse(transactions, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const { type, lines, ...body } = req.body;

    let transaction;
    if (type === TransactionType.PURCHASE_REQUISITION) {
      transaction = new PurchaseRequisition({ ...body });
    }

    const savedTransaction = await transaction.save();

    for (const line of lines) {
      if (savedTransaction.type === TransactionType.PURCHASE_REQUISITION) {
        const transactionLine = new PurchaseRequisitionLine({
          ...line,
          currencyId: savedTransaction.currencyId,
          transactionId: savedTransaction.id,
        });
        transactionLine.save();
      }
    }

    res.status(httpStatus.CREATED);
    res.json(savedTransaction);
  } catch (error) {
    next(error);
  }
};

exports.get = async (req, res, next) => {
  try {
    const transaction = await Transaction.findById(req.params.id).populate(
      'lines'
    );
    res.json(transaction);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const transaction = await Transaction.findById(req.params.id);

    const { lines, ...body } = req.body;

    Object.keys(body).forEach((key) => {
      transaction[key] = body[key];
    });
    const savedTransaction = await transaction.save();

    for (const line of lines) {
      if (line.id) {
        const transactionLine = await TransactionLine.findById(line.id);
        Object.keys(line).forEach((key) => {
          transaction[key] = line[key];
        });
        transactionLine.currencyId = savedTransaction.currencyId;
        await transactionLine.save();
      } else {
        if (savedTransaction.type === TransactionType.PURCHASE_REQUISITION) {
          const transactionLine = new PurchaseRequisitionLine({
            ...line,
            currencyId: savedTransaction.currencyId,
            transactionId: savedTransaction.id,
          });
          transactionLine.save();
        }
      }
    }

    res.json(savedTransaction);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const transaction = await Transaction.findById(req.params.id);
    await transaction.remove();
    res.status(httpStatus.NO_CONTENT).end();
  } catch (error) {
    next(error);
  }
};
