const httpStatus = require('http-status');
const TransactionLine = require('../models/transactionLine.model');

exports.list = async (req, res, next) => {
  try {
    const transactionLines = await TransactionLine.find({});
    res.json(transactionLines);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const transactionLine = new TransactionLine({ ...req.body });
    const savedTransactionLine = await transactionLine.save();

    res.status(httpStatus.CREATED);
    res.json(savedTransactionLine);
  } catch (error) {
    next(error);
  }
};

exports.get = async (req, res, next) => {
  try {
    const transactionLine = await TransactionLine.findById(req.params.id);
    res.json(transactionLine);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const transactionLine = await TransactionLine.findById(req.params.id);
    Object.keys(req.body).forEach((key) => {
      transactionLine[key] = req.body[key];
    });
    const savedTransactionLine = await transactionLine.save();
    res.json(savedTransactionLine);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const transactionLine = await TransactionLine.findById(req.params.id);
    await transactionLine.remove();
    res.status(httpStatus.NO_CONTENT).end();
  } catch (error) {
    next(error);
  }
};
