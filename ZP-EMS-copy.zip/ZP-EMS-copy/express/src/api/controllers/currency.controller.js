const httpStatus = require('http-status');
const Currency = require('../models/currency.model');
const {
  getPagination,
  getQueryOptions,
  getSortOptions,
  buildPaginatedResponse,
} = require('../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const { offset, limit } = getPagination(req);
    const queryOptions = getQueryOptions(req);
    const sortOptions = getSortOptions(req);

    let query = Currency.find(queryOptions);
    if (Object.keys(sortOptions).length > 0) {
      query = query.sort(sortOptions);
    }
    if (offset > 0) {
      query = query.skip(offset);
    }
    if (limit > 0) {
      query = query.limit(limit);
    }

    const currencies = await query.exec();
    const totalResults = await Currency.countDocuments(queryOptions);
    const results = await buildPaginatedResponse(currencies, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const currency = new Currency({ ...req.body });
    const savedCurrency = await currency.save();

    res.status(httpStatus.CREATED);
    res.json(savedCurrency);
  } catch (error) {
    next(error);
  }
};

exports.get = async (req, res, next) => {
  try {
    const currency = await Currency.findById(req.params.id);
    res.json(currency);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const currency = await Currency.findById(req.params.id);
    Object.keys(req.body).forEach((key) => {
      currency[key] = req.body[key];
    });
    const savedCurrency = await currency.save();
    res.json(savedCurrency);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const currency = await Currency.findById(req.params.id);
    if (!currency) {
      throw new ApiError(httpStatus.NOT_FOUND, 'Currency not found');
    }

    await Currency.findByIdAndDelete(req.params.id);

    res.status(httpStatus.NO_CONTENT).end();
  } catch (error) {
    next(error);
  }
};
