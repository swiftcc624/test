const httpStatus = require('http-status');
const Task = require('../../models/task.model');
const {
  getPagination,
  getQueryOptions,
  getSortOptions,
  buildPaginatedResponse,
} = require('../../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const { offset, limit } = getPagination(req);
    const queryOptions = getQueryOptions(req);
    const sortOptions = getSortOptions(req);

    let query = Task.find(queryOptions)
      .populate({
        path: 'project',
        populate: {
          path: 'customer',
        },
      })
      .populate('assignees');

    if (Object.keys(sortOptions).length > 0) {
      query = query.sort(sortOptions);
    }
    if (offset > 0) {
      query = query.skip(offset);
    }
    if (limit > 0) {
      query = query.limit(limit);
    }

    const tasks = await query.exec();

    const totalResults = await Task.countDocuments(queryOptions);
    const results = await buildPaginatedResponse(tasks, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { projectId, name, description, assigneeIds } = req.body;

    const task = await Task.finOne({ id });
    if (!task) {
      return res.status(httpStatus.NOT_FOUND).end();
    }

    task.projectId = projectId;
    task.name = name;
    task.description = description;
    task.assigneeIds = assigneeIds;
    task.save();

    res.json(task);
  } catch (error) {
    next(error);
  }
};
