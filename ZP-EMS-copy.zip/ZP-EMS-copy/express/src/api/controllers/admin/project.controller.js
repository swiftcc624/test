const Project = require('../../models/project.model');
const {
  getPagination,
  getQueryOptions,
  getSortOptions,
  buildPaginatedResponse,
} = require('../../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const { offset, limit } = getPagination(req);
    const queryOptions = getQueryOptions(req);
    const sortOptions = getSortOptions(req);

    let query = Project.find(queryOptions).populate('customer');
    if (Object.keys(sortOptions).length > 0) {
      query = query.sort(sortOptions);
    }
    if (offset > 0) {
      query = query.skip(offset);
    }
    if (limit > 0) {
      query = query.limit(limit);
    }

    const projects = await query.exec();
    const totalResults = await Project.countDocuments(queryOptions);
    const results = await buildPaginatedResponse(projects, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};
