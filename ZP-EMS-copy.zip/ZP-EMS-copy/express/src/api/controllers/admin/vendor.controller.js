const httpStatus = require('http-status');
const { v4: uuidv4 } = require('uuid');

const User = require('../../models/user.model');
const Vendor = require('../../models/vendor.model');
const Invitation = require('../../models/invitation.model');
const { UserType } = require('../../models/user.model');

const {
  getPagination,
  getQueryOptions,
  getSortOptions,
  buildPaginatedResponse,
} = require('../../utils/pagination');
exports.list = async (req, res, next) => {
  try {
    const { offset, limit } = getPagination(req);
    const queryOptions = getQueryOptions(req);
    const sortOptions = getSortOptions(req);

    let query = Vendor.find(queryOptions);
    if (Object.keys(sortOptions).length > 0) {
      query = query.sort(sortOptions);
    }
    if (offset > 0) {
      query = query.skip(offset);
    }
    if (limit > 0) {
      query = query.limit(limit);
    }

    const totalResults = await Vendor.countDocuments(queryOptions);

    const vendors = await query.exec();

    const results = await buildPaginatedResponse(vendors, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const { contactName, companyName, email } = req.body;

    const vendor = new Vendor({
      email,
      name: contactName,
      status: 'inactive',
      password: '123qweasd',
      //////////////////////////////
      companyName,
    });

    await vendor.save();

    res.status(httpStatus.CREATED).json(vendor);
  } catch (error) {
    next(error);
  }
};

exports.get = async (req, res, next) => {
  try {
    const { id } = req.params;

    const vendor = await Vendor.findById(id).populate('taxForm.taxFormFile');

    res.json(vendor);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const { id } = req.params;
    const vendor = await Vendor.findById(id);
    if (!vendor) {
      return res.status(httpStatus.NOT_FOUND).end();
    }

    Object.keys(req.body).forEach((key) => {
      vendor[key] = req.body[key];
    });

    const savedVender = await vendor.save();

    res.json(savedVender);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const { id } = req.params;

    await Vendor.findByIdAndDelete(id);

    res.status(httpStatus.NO_CONTENT).end();
  } catch (error) {
    next(error);
  }
};

exports.invite = async (req, res, next) => {
  try {
    const { email } = req.body;

    // Check if user already exists
    let user = await User.findOne({
      email: email,
      userType: UserType.VENDOR,
    });
    if (user) {
      if (
        (user.isInvited && user.invitationStatus === 'accepted') ||
        !user.isInvited
      ) {
        return res.status(httpStatus.CONFLICT).json({
          message: 'User already exists.',
        });
      }
    }

    // Generate an invitation
    const newUser = new User({
      email,
      userType: UserType.VENDOR,
      isInvited: true,
      invitationStatus: 'pending',
      password: uuidv4(),
      status: 'inactive',
    });
    await newUser.save();

    const invitation = await Invitation.generate({
      userId: newUser._id,
      userEmail: email,
    });

    // TODO: don't hard code base url
    const invitationLink = `https://financeerpai.com/invitations/${invitation._id}?token=${invitation.token}`;
    console.log(`Invitation link: ${invitationLink}`);

    res.status(200).json({
      message: 'Invitation sent successfully.',
      invitationLink,
    });
  } catch (error) {
    next(error);
  }
};
