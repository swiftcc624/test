const mongoose = require('mongoose');
const httpStatus = require('http-status');
const moment = require('moment-timezone');

const TimeEntry = require('../models/timeEntry.model');
const LineTimesheet = require('../models/lineTimesheet.model');
const Project = require('../models/project.model');

const {
  getTimeEntryJson,
  transcribeAudioToText,
} = require('../services/openai');

const {
  getPagination,
  getSortOptions,
  buildPaginatedResponse,
} = require('../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const sortOptions = getSortOptions(req);
    const { offset, limit } = getPagination(req);

    const { dateFrom, dateTo, projectId, taskId, sorting } = req.query;

    //filtering
    const queryOptions = {};
    if (dateFrom || dateTo) {
      queryOptions.date = {};
      if (dateFrom) queryOptions.date.$gte = new Date(dateFrom);
      if (dateTo) queryOptions.date.$lte = new Date(dateTo);
    }
    queryOptions.userId = req.user._id;

    const afterQueryOptions = {};
    if (projectId) {
      afterQueryOptions['lineTimesheet.projectId'] = projectId;
    }
    if (taskId) {
      afterQueryOptions['lineTimesheet.taskId'] = taskId;
    }

    console.log(afterQueryOptions);

    // const timeEntries = await TimeEntry.find(queryOptions);
    const pipeline = [
      {
        $match: queryOptions,
      },
      {
        $lookup: {
          from: 'linetimesheets',
          localField: 'lineTimesheetId',
          foreignField: '_id',
          as: 'lineTimesheet',
        },
      },
      {
        $unwind: '$lineTimesheet',
      },
      {
        $match: afterQueryOptions,
      },
      {
        $lookup: {
          from: 'projects',
          localField: 'lineTimesheet.projectId',
          foreignField: '_id',
          as: 'project',
        },
      },
      {
        $lookup: {
          from: 'tasks',
          localField: 'lineTimesheet.taskId',
          foreignField: '_id',
          as: 'task',
        },
      },
      {
        $unwind: '$project',
      },
      {
        $unwind: '$task',
      },
    ];

    let totalResults = await TimeEntry.aggregate([
      ...pipeline,
      { $count: 'totalResults' },
    ]);
    totalResults = totalResults?.[0]?.totalResults || 0;

    if (Object.keys(sortOptions).length > 0) {
      pipeline.push({ $sort: sortOptions });
    }
    if (offset > 0) {
      pipeline.push({ $skip: offset });
    }
    if (limit > 0) {
      pipeline.push({ $limit: limit });
    }

    const timeEntries = await TimeEntry.aggregate(pipeline);
    const results = buildPaginatedResponse(timeEntries, totalResults, {
      offset,
      limit,
    });

    res.json(results);
  } catch (error) {
    next(error);
  }
};

exports.getTimeReports = async (req, res, next) => {
  try {
    const { dateFrom, dateTo } = req.query;
    const queryOptions = {};
    if (dateFrom || dateTo) {
      queryOptions.date = {};
      if (dateFrom) queryOptions.date.$gte = new Date(dateFrom);
      if (dateTo) queryOptions.date.$lte = new Date(dateTo);
    }

    const timeReports = await TimeEntry.aggregate([
      {
        $match: queryOptions,
      },
      {
        $group: {
          _id: '$date',
          totalDuration: { $sum: '$duration' },
        },
      },
      //sort
      {
        $sort: { _id: 1 },
      },
    ]);

    res.json(timeReports);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const { duration, description, date, projectId, taskId } = req.body;

    const weekStartDate = new Date(
      moment(date).startOf('isoWeek').format('YYYY-MM-DD')
    );

    const lineTimesheet = await LineTimesheet.findOne({
      weekStartDate,
      taskId,
      projectId,
      userId: req.user._id,
    });

    let shouldCreateNewLineTimesheet = false;

    // TODO: find a better way to check if a time entry already exists
    if (lineTimesheet) {
      const existingTimeEntry = await TimeEntry.findOne({
        lineTimesheetId: lineTimesheet._id,
        date,
        userId: req.user._id,
      });
      if (existingTimeEntry) {
        shouldCreateNewLineTimesheet = true;
      }
    } else {
      shouldCreateNewLineTimesheet = true;
    }

    let lineTimesheetId;
    if (shouldCreateNewLineTimesheet) {
      const newLineTimesheet = new LineTimesheet({
        weekStartDate,
        taskId,
        projectId,
        userId: req.user._id,
      });
      await newLineTimesheet.save();

      lineTimesheetId = newLineTimesheet._id;
    } else {
      lineTimesheetId = lineTimesheet._id;
    }

    const timeEntry = new TimeEntry({
      duration,
      description,
      date,
      lineTimesheetId,
      userId: req.user._id,
    });

    await timeEntry.save();

    res.status(httpStatus.CREATED).json(timeEntry);
  } catch (error) {
    next(error);
  }
};

exports.get = async (req, res, next) => {
  try {
    const { id } = req.params;

    const timeEntry = await TimeEntry.findById(id);

    res.json(timeEntry);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { duration, description, date, projectId, taskId } = req.body;

    const timeEntry = await TimeEntry.findById(id);
    if (!timeEntry) {
      return res.status(httpStatus.NOT_FOUND).end();
    }

    const weekStartDate = new Date(
      moment(date).startOf('isoWeek').format('YYYY-MM-DD')
    );

    const lineTimesheet = await LineTimesheet.findById(
      timeEntry.lineTimesheetId
    );

    if (!lineTimesheet) {
      return res.status(httpStatus.NOT_FOUND).end();
    }

    if (
      lineTimesheet.weekStartDate.getTime() === weekStartDate.getTime() &&
      lineTimesheet.taskId === taskId &&
      lineTimesheet.projectId === projectId
    ) {
      timeEntry.duration = duration;
      timeEntry.description = description;
      timeEntry.date = date;
      timeEntry.save();
    } else {
      const newLineTimesheet = new LineTimesheet({
        weekStartDate,
        taskId,
        projectId,
        userId: timeEntry.userId,
      });
      await newLineTimesheet.save();

      timeEntry.lineTimesheetId = newLineTimesheet._id;
      timeEntry.duration = duration;
      timeEntry.description = description;
      timeEntry.date = date;
      timeEntry.save();
    }

    res.json(timeEntry);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const { id } = req.params;

    const timeEntry = await TimeEntry.findById(id);

    console.log('timeEntry', timeEntry);

    if (!timeEntry) {
      return res.status(404).send('Time entry not found');
    }

    await TimeEntry.findByIdAndDelete(id);

    res.status(httpStatus.NO_CONTENT).end();
  } catch (error) {
    next(error);
  }
};

exports.getTimeEntryJsonFromAudio = async (req, res, next) => {
  try {
    const projects = await Project.aggregate([
      {
        $lookup: {
          from: 'tasks',
          let: { projectId: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ['$projectId', '$$projectId'] },
                    { $in: [req.user._id, '$assigneeIds'] },
                  ],
                },
              },
            },
          ],
          as: 'tasks',
        },
      },
    ]);

    const formattedProjects = projects.map((p) => {
      return {
        name: p.name,
        id: p._id,
        tasks: p.tasks.map((t) => ({ name: t.name, id: t._id })),
      };
    });

    console.log(JSON.stringify(formattedProjects));

    const file = req.file;
    if (!file) {
      return res.status(400).send({ error: 'No audio uploaded' });
    }

    const transcription = await transcribeAudioToText(`./${file.path}`);

    const timeEntryJson = await getTimeEntryJson(
      transcription,
      formattedProjects
    );
    // console.log(timeEntryJson);
    res.json({ timeEntryJson: JSON.parse(timeEntryJson), transcription });
  } catch (error) {
    next(error);
  }
};
