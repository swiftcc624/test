const httpStatus = require('http-status');
const AsyncTask = require('../models/asyncTask.model');
const { asyncTaskQueue } = require('../services/asyncTask.service.js');

exports.list = async (req, res, next) => {
  try {
    const { status, types, offset = 0, limit = 10 } = req.query;
    const queryOptions = {};

    if (status) {
      queryOptions.status = status;
    }
    if (types) {
      queryOptions.type = { $in: types };
    }

    const asyncTasks = await AsyncTask.find(queryOptions)
      .sort({
        createdAt: -1,
      })
      .skip(parseInt(offset))
      .limit(parseInt(limit));

    res.json(asyncTasks);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const { types, mode, startDateTime } = req.body;

    const savedAsyncTasks = [];
    let priority = 0;
    for (const type of types) {
      const asyncTask = new AsyncTask({
        type,
        taskData: { mode, startDateTime },
      });

      const savedAsyncTask = await asyncTask.save();
      savedAsyncTasks.push(savedAsyncTask);

      asyncTaskQueue.add(
        'sync',
        { type, mode, startDateTime },
        { jobId: savedAsyncTask._id, priority: priority++ }
      );
    }

    res.status(httpStatus.CREATED);
    res.json(savedAsyncTasks);
  } catch (error) {
    next(error);
  }
};
