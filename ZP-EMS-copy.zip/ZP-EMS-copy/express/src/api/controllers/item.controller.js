const httpStatus = require('http-status');
const Item = require('../models/item.model');
const {
  getPagination,
  getQueryOptions,
  getSortOptions,
  buildPaginatedResponse,
} = require('../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const queryOptions = getQueryOptions(req);
    const sortOptions = getSortOptions(req);
    const { offset, limit } = getPagination(req);

    let query = Item.find(queryOptions);
    if (Object.keys(sortOptions).length > 0) {
      query = query.sort(sortOptions);
    }
    if (offset > 0) {
      query = query.skip(offset);
    }
    if (limit > 0) {
      query = query.limit(limit);
    }
    const items = await query.exec();

    const totalResults = await Item.countDocuments(queryOptions);
    const results = await buildPaginatedResponse(items, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const item = new Item({ ...req.body });
    const savedItem = await item.save();

    res.status(httpStatus.CREATED);
    res.json(savedItem);
  } catch (error) {
    next(error);
  }
};

exports.get = async (req, res, next) => {
  try {
    const item = await Item.findById(req.params.id);
    res.json(item);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const item = await Item.findById(req.params.id);
    Object.keys(req.body).forEach((key) => {
      item[key] = req.body[key];
    });
    const savedItem = await item.save();
    res.json(savedItem);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const item = await Item.findById(req.params.id);
    await item.remove();
    res.status(httpStatus.NO_CONTENT).end();
  } catch (error) {
    next(error);
  }
};
