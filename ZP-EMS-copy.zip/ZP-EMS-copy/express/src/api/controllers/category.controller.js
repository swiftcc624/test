const httpStatus = require('http-status');
const Category = require('../models/category.model');
const {
  getPagination,
  getQueryOptions,
  getSortOptions,
  buildPaginatedResponse,
} = require('../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const { offset, limit } = getPagination(req);
    const queryOptions = getQueryOptions(req);
    const sortOptions = getSortOptions(req);

    let query = Category.find(queryOptions);
    if (Object.keys(sortOptions).length > 0) {
      query = query.sort(sortOptions);
    }
    if (offset > 0) {
      query = query.skip(offset);
    }
    if (limit > 0) {
      query = query.limit(limit);
    }

    const totalResults = await Category.countDocuments(queryOptions);

    const categories = await query.exec();

    const results = await buildPaginatedResponse(categories, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};

exports.create = async (req, res, next) => {
  try {
    const category = new Category({ ...req.body });
    const savedCategory = await category.save();

    res.status(httpStatus.CREATED);
    res.json(savedCategory);
  } catch (error) {
    next(error);
  }
};

exports.get = async (req, res, next) => {
  try {
    const category = await Category.findById(req.params.id);
    res.json(category);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const category = await Category.findById(req.params.id);
    Object.keys(req.body).forEach((key) => {
      category[key] = req.body[key];
    });
    const savedCategory = await category.save();
    res.json(savedCategory);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const category = await Category.findById(req.params.id);
    if (!category) {
      throw new ApiError(httpStatus.NOT_FOUND, 'Category not found');
    }
    await Category.findByIdAndDelete(req.params.id);

    res.status(httpStatus.NO_CONTENT).end();
  } catch (error) {
    next(error);
  }
};
