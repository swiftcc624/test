const httpStatus = require('http-status');
const { omit, omitBy, isNil } = require('lodash');

const User = require('../models/user.model');
const Expense = require('../models/expense.model');

const {
  getPagination,
  getSortOptions,
  buildPaginatedResponse,
} = require('../utils/pagination');

/**
 * Load user and append to req.
 * @public
 */
exports.load = async (req, res, next, id) => {
  try {
    const user = await User.get(id);
    req.locals = { user };
    return next();
  } catch (error) {
    return next(error);
  }
};

/**
 * Get user
 * @public
 */
exports.get = (req, res) => res.json(req.locals.user.transform());

/**
 * Get logged in user info
 * @public
 */
exports.loggedIn = (req, res) => res.json(req.user.transform());

/**
 * Create new user
 * @public
 */
exports.create = async (req, res, next) => {
  try {
    const user = new User(req.body);
    const savedUser = await user.save();
    res.status(httpStatus.CREATED);
    res.json(savedUser.transform());
  } catch (error) {
    next(User.checkDuplicateEmail(error));
  }
};

/**
 * Replace existing user
 * @public
 */
exports.replace = async (req, res, next) => {
  try {
    const { user } = req.locals;
    const newUser = new User(req.body);
    const ommitRole = user.role !== 'admin' ? 'role' : '';
    const newUserObject = omit(newUser.toObject(), 'id', ommitRole);

    await user.updateOne(newUserObject, { override: true, upsert: true });
    const savedUser = await User.findOne({ id: user.id });

    res.json(savedUser.transform());
  } catch (error) {
    next(User.checkDuplicateEmail(error));
  }
};

/**
 * Update existing user
 * @public
 */
exports.update = async (req, res, next) => {
  const ommitRole =
    req.user.role !== 'admin' && req.locals.user.role !== 'admin' ? 'role' : '';
  const updatedUser = omit(req.body, ommitRole);
  const user = Object.assign(req.locals.user, updatedUser);

  try {
    const savedUser = await user.save();
    res.json(savedUser.transform());
  } catch (e) {
    console.log(e);
    next(User.checkDuplicateEmail(e));
  }

  // user
  //   .save()
  //   .then((savedUser) => res.json(savedUser.transform()))
  //   .catch((e) => next(User.checkDuplicateEmail(e)));
};

/**
 * Get user list
 * @public
 */
exports.list = async (req, res, next) => {
  try {
    const sortOptions = getSortOptions(req);
    const { offset, limit } = getPagination(req);

    const { name, email, role, userType } = req.query;

    const options = omitBy({ name, email, role, userType }, isNil);

    let query = User.find(options);
    if (Object.keys(sortOptions).length > 0) {
      query = query.sort(sortOptions);
    }
    if (offset > 0) {
      query = query.skip(offset);
    }
    if (limit > 0) {
      query = query.limit(limit);
    }

    const users = await query.exec();
    const totalResults = await User.countDocuments(options);

    const results = await buildPaginatedResponse(users, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};

/**
 * Delete user
 * @public
 */
exports.remove = async (req, res, next) => {
  try {
    const { user } = req.locals;

    const expenseCount = await Expense.countDocuments({
      deletedAt: null,
      attendee: { $in: [user.id] },
    });

    if (expenseCount > 0) {
      user.status = 'inactive';
      await user.save();
      res.json(user.transform());
    } else {
      await user.deleteOne();
      res.status(httpStatus.NO_CONTENT).end();
    }
  } catch (error) {
    next(error);
  }
};

exports.changePassword = async (req, res, next) => {
  try {
    const user = req.user;
    const { oldPassword, newPassword } = req.body;
    if (user && (await user.passwordMatches(oldPassword))) {
      user.password = newPassword;
      await user.save();
    } else {
      res
        .status(httpStatus.BAD_REQUEST)
        .json({ message: 'Incorrect old password' });
    }
    res.json(user);
  } catch (error) {
    console.log(error);
    next(error);
  }
};
