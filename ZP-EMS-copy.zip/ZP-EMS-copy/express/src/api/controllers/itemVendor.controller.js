const ItemVendor = require('../models/itemVendor.model');
const {
  getPagination,
  getQueryOptions,
  getSortOptions,
  buildPaginatedResponse,
} = require('../utils/pagination');

exports.list = async (req, res, next) => {
  try {
    const queryOptions = getQueryOptions(req);
    const sortOptions = getSortOptions(req);
    const { offset, limit } = getPagination(req);

    let query = ItemVendor.find(queryOptions)
      .populate('vendor')
      .sort(sortOptions)
      .skip(offset);
    if (limit > 0) {
      query = query.limit(limit);
    }
    const items = await query.exec();

    const totalResults = await ItemVendor.countDocuments(queryOptions);
    const results = await buildPaginatedResponse(items, totalResults, {
      offset,
      limit,
    });
    res.json(results);
  } catch (error) {
    next(error);
  }
};
