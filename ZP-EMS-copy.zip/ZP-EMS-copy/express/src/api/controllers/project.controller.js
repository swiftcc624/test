const Project = require('../models/project.model');

exports.list = async (req, res, next) => {
  try {
    const projects = await Project.find({}).populate('customerId');

    res.json(projects);
  } catch (error) {
    next(error);
  }
};
