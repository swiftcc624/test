const httpStatus = require('http-status');
const Settings = require('../models/settings.model');
const { OpenAI } = require('openai');
const {
  loadNetsuitConnectionSettings,
  executeSuiteQLQuery,
} = require('../services/netsuite');

exports.get = async (req, res, next) => {
  try {
    const settings = await Settings.findOne({});

    if (req.user.role !== 'admin') {
      res.json({
        logo: settings.logo,
        dateFormat: settings.dateFormat,
        timeFormat: settings.timeFormat,
        expenseSettings: settings.settings,
      });
      return;
    }
    res.json(settings);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    let settings = await Settings.findOne({});

    if (!settings) {
      settings = new Settings();
    }
    Object.keys(req.body).forEach((key) => {
      settings[key] = req.body[key];
    });

    const savedSettings = await settings.save();
    await loadNetsuitConnectionSettings();

    res.json(savedSettings);
  } catch (error) {
    next(error);
  }
};

exports.testNetsuiteConnection = async (req, res, next) => {
  try {
    const result = await executeSuiteQLQuery(`select * from expensecategory`);
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
};

exports.testOpenAIConnection = async (req, res, next) => {
  try {
    const { openAIAPIKey } = req.body;
    const openai = new OpenAI({ apiKey: openAIAPIKey });
    const chatCompletion = await openai.chat.completions.create({
      messages: [{ role: 'user', content: 'Say this is a test' }],
      model: 'gpt-3.5-turbo',
    });

    const message = chatCompletion.choices[0].message.content;

    res.json({ ok: message.toLowerCase().includes('this is a test') });
  } catch (error) {
    next(error);
  }
};

const {
  VerifyDomainIdentityCommand,
  VerifyDomainDkimCommand,
  GetIdentityVerificationAttributesCommand,
  GetIdentityDkimAttributesCommand,
} = require('@aws-sdk/client-ses');
const { sesClient } = require('../../config/awsConfig');

exports.verifyEmailDomainIdentity = async (req, res, next) => {
  try {
    const { emailDomain } = req.body;

    let settings = await Settings.findOne({});
    if (!settings) {
      settings = new Settings();
    }
    settings.emailDomain = emailDomain;
    await settings.save();

    // Verify domain identity
    const verifyDomainParams = { Domain: emailDomain };
    const verifyDomainCommand = new VerifyDomainIdentityCommand(
      verifyDomainParams
    );

    // Verify DKIM for the domain
    const verifyDkimParams = { Domain: emailDomain };
    const verifyDkimCommand = new VerifyDomainDkimCommand(verifyDkimParams);

    // Send the verify domain identity command
    const domainData = await sesClient.send(verifyDomainCommand);

    // Send the verify DKIM command
    const dkimData = await sesClient.send(verifyDkimCommand);

    res.status(200).json({
      message: 'Verification initiated',
      verificationToken: domainData.VerificationToken,
      dkimTokens: dkimData.DkimTokens,
    });
  } catch (error) {
    console.log(error);
    next(error);
  }
};

exports.getEmailDomainIdentity = async (req, res, next) => {
  try {
    let settings = await Settings.findOne({});
    if (!settings) {
      res.status(400).json({ message: 'Email domain not set' });
    }
    const emailDomain = settings.emailDomain;

    const identityParams = { Identities: [emailDomain] };
    const verificationCommand = new GetIdentityVerificationAttributesCommand(
      identityParams
    );
    const dkimCommand = new GetIdentityDkimAttributesCommand(identityParams);

    const verificationData = await sesClient.send(verificationCommand);
    const dkimData = await sesClient.send(dkimCommand);

    const verificationAttributes =
      verificationData.VerificationAttributes[emailDomain];
    const dkimAttributes = dkimData.DkimAttributes[emailDomain];

    if (verificationAttributes) {
      res.status(200).json({
        emailDomain,
        verificationStatus: verificationAttributes.VerificationStatus,
        verificationToken: verificationAttributes.VerificationToken,
        dkimEnabled: dkimAttributes.DkimEnabled,
        dkimTokens: dkimAttributes.DkimTokens,
      });
    } else {
      res.status(404).json({ message: 'Email Domain identity not found' });
    }
  } catch (error) {
    console.log(error);
    next(error);
  }
};
