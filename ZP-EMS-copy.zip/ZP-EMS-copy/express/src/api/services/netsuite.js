const crypto = require('crypto');
const oauth1a = require('oauth-1.0a');
const axios = require('axios');
const mongoose = require('mongoose');
const moment = require('moment-timezone');

const Settings = require('../models/settings.model');

const { RecordType, processRecords } = require('./sync.service');
const { UserType } = require('../models/user.model');

const User = require('../models/user.model');
const Customer = require('../models/customer.model');
const Project = require('../models/project.model');
const Item = require('../models/item.model');
const Vendor = require('../models/vendor.model');
const Currency = require('../models/currency.model');

// accountId: "",
// consumerKey: "",
// consumerSecret: "",
// tokenId: "",
// tokenSecret: "",

let CONSUMERKEY, CONSUMERSECRET, TOKENKEY, TOKENSECRET, REALM;

async function loadNetsuitConnectionSettings() {
  const settings = await Settings.findOne(); // replace with your actual query

  const { accountId, consumerKey, consumerSecret, tokenId, tokenSecret } =
    settings.netsuiteConnectionInfo;

  CONSUMERKEY = consumerKey;
  CONSUMERSECRET = consumerSecret;
  TOKENKEY = tokenId;
  TOKENSECRET = tokenSecret;
  REALM = accountId;

  console.log('settings loaded', settings);
}

mongoose.connection.on('connected', () => {
  loadNetsuitConnectionSettings().catch(console.error);
});

class Oauth1Helper {
  static getAuthHeaderForRequest(request) {
    const oauth = oauth1a({
      consumer: {
        key: CONSUMERKEY,
        secret: CONSUMERSECRET,
      },
      signature_method: 'HMAC-SHA256',
      hash_function(base_string, key) {
        return crypto
          .createHmac('sha256', key)
          .update(base_string)
          .digest('base64');
      },
      realm: REALM, // Replace 'your_realm' with the actual realm
      version: '1.0', // Specify OAuth version 1.0
    });
    const authorization = oauth.authorize(request, {
      key: TOKENKEY,
      secret: TOKENSECRET,
    });
    return oauth.toHeader(authorization);
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

const executeSuiteQLQuery = async (query, limit = 100, offset = 0) => {
  const request = {
    url: `https://${REALM.toLowerCase()}.suitetalk.api.netsuite.com/services/rest/query/v1/suiteql?limit=${limit}&offset=${offset}`,
    method: 'POST', // TODO: is this correct? what is it for?
  };

  const authHeader = Oauth1Helper.getAuthHeaderForRequest(request);

  const response = await axios.post(
    request.url,
    {
      // q: 'SELECT * FROM expensecategory',
      q: query,
    },
    {
      headers: {
        Authorization: authHeader['Authorization'],
        'Content-Type': 'application/json',
        Prefer: 'transient',
      },
    }
  );
  return response.data;
};

const getSuiteQLQuery = (recordType, syncStartDatetime) => {
  const formmatedSyncStartDatetime = moment(syncStartDatetime).format(
    'YYYY-MM-DD HH:mm:ss'
  );
  switch (recordType) {
    case RecordType.EMPLOYEE:
      return `
          SELECT * 
          FROM employee 
          where lastmodifieddate > TO_TIMESTAMP( '${formmatedSyncStartDatetime}', 'YYYY-MM-DD HH24:MI:SSxFF' ) 
          order by lastmodifieddate
          `;
    case RecordType.VENDOR:
      return `
          SELECT id, currency, entityid, email, isinactive
          FROM Vendor 
          where lastmodifieddate > TO_TIMESTAMP( '${formmatedSyncStartDatetime}', 'YYYY-MM-DD HH24:MI:SSxFF' ) 
          order by lastmodifieddate
          `;
    case RecordType.CUSTOMER:
      return `
          SELECT id, currency, entityid, email, isinactive
          FROM customer 
          where lastmodifieddate > TO_TIMESTAMP( '${formmatedSyncStartDatetime}', 'YYYY-MM-DD HH24:MI:SSxFF' ) 
          order by lastmodifieddate
          `;
    case RecordType.CATEGORY:
      return `
      SELECT * 
      FROM expensecategory 
      where lastmodifieddate > TO_TIMESTAMP( '${formmatedSyncStartDatetime}', 'YYYY-MM-DD HH24:MI:SSxFF' ) 
      order by lastmodifieddate
      `;
    case RecordType.CURRENCY:
      return `
      SELECT * 
      FROM currency 
      where lastmodifieddate > TO_TIMESTAMP( '${formmatedSyncStartDatetime}', 'YYYY-MM-DD HH24:MI:SSxFF' ) 
      order by lastmodifieddate
      `;
    case RecordType.PROJECT:
      return `
        SELECT job.lastmodifieddate, job.id, job.altname, job.customer as customerid 
        FROM job 
        where job.lastmodifieddate > TO_TIMESTAMP( '${formmatedSyncStartDatetime}', 'YYYY-MM-DD HH24:MI:SSxFF' ) 
        order by job.lastmodifieddate
        `;
    case RecordType.TASK:
      return `
        SELECT MAX(projecttask.id) as projecttask_id, MAX(projecttask.title) as projecttask_name, MAX(projecttask.message) as projecttask_message, MAX(projecttask.status) as projecttask_status,
        MAX(projecttask.project) as project_id, LISTAGG(projecttaskassignee.resource, ',') as assigneeIds
        FROM systemnote 
        RIGHT JOIN projecttask ON systemnote.recordId = projecttask.id 
        RIGHT JOIN projecttaskassignee ON projecttaskassignee.projecttask = projecttask.id
        WHERE systemnote.date > TO_TIMESTAMP( '${formmatedSyncStartDatetime}', 'YYYY-MM-DD HH24:MI:SSxFF' ) AND systemnote.recordtypeid='-20'
        GROUP BY projecttask.id
      `;

    case RecordType.ITEM:
      return `
          SELECT item.id, item.itemid as sku, item.itemtype as type, item.description as description FROM item
          where lastmodifieddate > TO_TIMESTAMP( '${formmatedSyncStartDatetime}', 'YYYY-MM-DD HH24:MI:SSxFF' ) 
      `;

    case RecordType.ITEMVENDOR:
      return `
          SELECT itemvendor.item as item_internalid, itemvendor.vendor as vendor_id, itemvendor.preferredvendor as is_preferred, itemvendor.purchaseprice as vendorprice, itemvendor.vendorcurrencyid as currency_id 
          FROM itemvendor 
          LEFT JOIN item ON item.id = itemvendor.item
          WHERE item.lastmodifieddate > TO_TIMESTAMP( '${formmatedSyncStartDatetime}', 'YYYY-MM-DD HH24:MI:SSxFF' ) 
          order by item.lastmodifieddate
      `;

    default:
      return '';
  }
};

const getMapRecordToModel = (recordType) => {
  switch (recordType) {
    case RecordType.EMPLOYEE:
      return (record, operation = 'create') => {
        const mappedRecord = {
          nid: record['id'],
          name: record['entityid'],
          email: record['email'],
          status: record['isinactive'] === 'T' ? 'inactive' : 'active',
          userType: UserType.EMPLOYEE,
          role: 'user',
          password: '123qweasd',
        };
        if (operation === 'update') {
          delete mappedRecord.email;
          delete mappedRecord.role;
          delete mappedRecord.password;
        }
        return mappedRecord;
      };
    case RecordType.VENDOR:
      return (record, operation = 'create') => {
        const mappedRecord = {
          nid: record['id'],
          name: record['entityid'],
          email: record['email'],
          status: record['isinactive'] === 'T' ? 'inactive' : 'active',
          userType: UserType.VENDOR,
          role: 'user',
          password: '123qweasd',
        };
        if (operation === 'update') {
          delete mappedRecord.email;
          delete mappedRecord.role;
          delete mappedRecord.password;
        }
        return mappedRecord;
      };
    case RecordType.CUSTOMER:
      return (record, operation = 'create') => {
        const mappedRecord = {
          nid: record['id'],
          name: record['entityid'],
          email: record['email'],
          status: record['isinactive'] === 'T' ? 'inactive' : 'active',
          userType: UserType.CUSTOMER,
          role: 'user',
          password: '123qweasd',
        };
        if (operation === 'update') {
          delete mappedRecord.email;
          delete mappedRecord.role;
          delete mappedRecord.password;
        }
        return mappedRecord;
      };

    case RecordType.CATEGORY:
      return (record) => ({
        nid: record['id'],
        name: record['name'],
        glCode: record['id'],
        status: record['isinactive'] === 'T' ? 'inactive' : 'active', // TODO: rename status field to isActive
      });
    case RecordType.CURRENCY:
      return (record) => ({
        nid: record['id'],
        name: record['name'],
        symbol: record['symbol'],
        status: record['isinactive'] === 'T' ? 'inactive' : 'active', // TODO: rename status field to isActive
      });
    case RecordType.PROJECT:
      return async (record) => {
        if (record['customerid']) {
          const customer = await Customer.findOne({
            nid: record['customerid'],
          });

          if (!customer) {
            throw new Error(
              `Customer not found with nid ${record['customerid']}`
            );
          }

          return {
            nid: record['id'],
            name: record['altname'],
            customerId: customer._id,
          };
        } else {
          return {
            nid: record['id'],
            name: record['altname'],
          };
        }
      };
    case RecordType.TASK:
      return async (record) => {
        const project = await Project.findOne({
          nid: record['project_id'],
        });

        if (!project) {
          throw new Error(`Project not found with nid ${record['project_id']}`);
        }

        const assigneeIds = [];
        let uniqueAssigneeIds = [...new Set(record['assigneeids'].split(','))];
        console.log(uniqueAssigneeIds);
        for (const assigneeId of uniqueAssigneeIds) {
          // TODO: use Employee?
          const assignee = await User.findOne({
            nid: assigneeId,
          });

          if (!assignee) {
            throw new Error(`User not found with nid ${assigneeId}`);
          }

          assigneeIds.push(assignee._id);
        }

        return {
          nid: record['projecttask_id'],
          name: record['projecttask_name'],
          description: record['projecttask_message'],
          status: record['projecttask_status'],
          projectId: project._id,
          assigneeIds,
        };
      };
    case RecordType.ITEM:
      return (record) => ({
        nid: record['id'],
        name: record['sku'],
        type: record['type'],
        description: record['description'],
      });
    case RecordType.ITEMVENDOR:
      return async (record) => {
        const item = await Item.findOne({
          nid: record['item_internalid'],
        });

        if (!item) {
          throw new Error(
            `Item not found with nid ${record['item_internalid']}`
          );
        }

        const vendor = await Vendor.findOne({
          nid: record['vendor_id'],
        });

        if (!vendor) {
          throw new Error(`Vendor not found with nid ${record['vendor_id']}`);
        }

        const currency = await Currency.findOne({
          nid: record['currency_id'],
        });

        if (!currency) {
          throw new Error(
            `Currency not found with nid ${record['currency_id']}`
          );
        }

        return {
          nid: `${record['item_internalid']}-${record['vendor_id']}`,
          isPreferred: record['is_preferred'] === 'T',
          vendorPrice: record['vendorprice'],
          itemId: item._id,
          vendorId: vendor._id,
          currencyId: currency._id,
        };
      };
    default:
      return () => {};
  }
};

const syncData = async (recordType, syncStartDatetime, model, limit = 100) => {
  const result = {
    success: false,
    syncedRecordCount: 0,
    errors: [],
  };

  try {
    let offset = 0;
    let hasMore = true;

    const mapRecordToModel = getMapRecordToModel(recordType);

    while (hasMore) {
      const queryCommand = getSuiteQLQuery(recordType, syncStartDatetime);
      console.log('queryCommand', queryCommand);

      const queryResult = await executeSuiteQLQuery(
        queryCommand,
        limit,
        offset
      );

      const records = queryResult.items || [];

      const { syncedCount, errors } = await processRecords(
        records,
        model,
        mapRecordToModel
      );
      result.syncedRecordCount += syncedCount;
      result.errors.push(...errors);

      hasMore = queryResult.hasMore;
      offset += limit;
    }

    result.success = true;
  } catch (error) {
    result.errors.push(`Error syncing data: ${error.message}`);
  }

  console.log('syncData result', recordType, result);

  return result;
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

const createExpenseReport = async (body) => {
  const request = {
    url: `https://${REALM.toLowerCase()}.suitetalk.api.netsuite.com/services/rest/record/v1/expensereport`, // 8066958
    method: 'POST',
  };

  const authHeader = Oauth1Helper.getAuthHeaderForRequest(request);
  //   console.log(authHeader);

  const response = await axios.post(request.url, body, {
    headers: {
      Authorization: authHeader['Authorization'],
      'Content-Type': 'application/json',
    },
  });
  return response.data;
};

const updateExpenseReport = async (id, body) => {
  const request = {
    url: `https://${REALM.toLowerCase()}.suitetalk.api.netsuite.com/services/rest/record/v1/expensereport/${id}?replace=expense`, // 8066958
    method: 'PATCH',
  };

  const authHeader = Oauth1Helper.getAuthHeaderForRequest(request);
  //   console.log(authHeader);

  const response = await axios.patch(request.url, body, {
    headers: {
      Authorization: authHeader['Authorization'],
      'Content-Type': 'application/json',
    },
  });
  return response.data;
};

const createTimeEntry = async (body) => {
  const request = {
    url: `https://${REALM.toLowerCase()}.suitetalk.api.netsuite.com/services/rest/record/v1/timebill`,
    method: 'POST',
  };

  const authHeader = Oauth1Helper.getAuthHeaderForRequest(request);
  //   console.log(authHeader);

  const response = await axios.post(request.url, body, {
    headers: {
      Authorization: authHeader['Authorization'],
      'Content-Type': 'application/json',
    },
  });
  return response.data;
};

const updateTimeEntry = async (id, body) => {
  const request = {
    url: `https://${REALM.toLowerCase()}.suitetalk.api.netsuite.com/services/rest/record/v1/timebill/${id}`,
    method: 'PATCH',
  };

  const authHeader = Oauth1Helper.getAuthHeaderForRequest(request);
  //   console.log(authHeader);

  const response = await axios.patch(request.url, body, {
    headers: {
      Authorization: authHeader['Authorization'],
      'Content-Type': 'application/json',
    },
  });
  return response.data;
};

module.exports = {
  loadNetsuitConnectionSettings,
  //////////////////////////////////////
  executeSuiteQLQuery,
  getSuiteQLQuery,
  syncData,
  //////////////////////////////////////
  createExpenseReport,
  updateExpenseReport,
  createTimeEntry,
  updateTimeEntry,
};
