const Queue = require('bull');
const moment = require('moment-timezone');

const AsyncTask = require('../models/asyncTask.model');
const User = require('../models/user.model');
const Employee = require('../models/employee.model');
const Category = require('../models/category.model');
const Currency = require('../models/currency.model');
const Project = require('../models/project.model');
const Task = require('../models/task.model');
const Item = require('../models/item.model');
const ItemVendor = require('../models/itemVendor.model');
const Vendor = require('../models/vendor.model');
const Customer = require('../models/customer.model');

const { syncData } = require('../services/netsuite');
const { RecordType } = require('../services/sync.service');

const getSyncStartDatetime = async (jobData) => {
  return moment('2000-01-01').toDate();
  const { type, mode, startDateTime } = jobData;

  if (mode === 'custom' && startDateTime) {
    return startDateTime;
  } else {
    // if (mode === 'automatic') {
    // get last sync date
    const lastSync = await AsyncTask.findOne({
      type,
      status: 'completed',
    }).sort({ createdAt: -1 });

    if (lastSync) {
      return lastSync.createdAt;
    } else {
      return moment('2000-01-01').toDate();
    }
  }
};

const asyncTaskQueue = new Queue('asyncTaskQueue', {
  limiter: {
    max: 1,
    duration: 1000,
  },
  //   settings: {
  //     lockDuration: 30000,
  //   },
});

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

asyncTaskQueue.process('sync', 1, async (job, done) => {
  console.log(`processing job ${job.id} with  priority ${job.opts.priority}`);

  const syncStartDatetime = await getSyncStartDatetime(job);

  const { type } = job.data;
  try {
    if (type === 'sync_employee') {
      const result = await syncData(
        RecordType.EMPLOYEE,
        syncStartDatetime,
        Employee
      );
      console.log(result);
    } else if (type === 'sync_vendor') {
      await syncData(RecordType.VENDOR, syncStartDatetime, Vendor);
    } else if (type === 'sync_customer') {
      await syncData(RecordType.CUSTOMER, syncStartDatetime, Customer);
    } else if (type === 'sync_category') {
      await syncData(RecordType.CATEGORY, syncStartDatetime, Category);
    } else if (type === 'sync_currency') {
      await syncData(RecordType.CURRENCY, syncStartDatetime, Currency);
    } else if (type === 'sync_project') {
      await syncData(RecordType.PROJECT, syncStartDatetime, Project);
    } else if (type === 'sync_task') {
      await syncData(RecordType.TASK, syncStartDatetime, Task);
    } else if (type === 'sync_item') {
      await syncData(RecordType.ITEM, syncStartDatetime, Item);
    } else if (type === 'sync_itemvendor') {
      await syncData(RecordType.ITEMVENDOR, syncStartDatetime, ItemVendor);
    } else {
      await delay(1000);
    }

    console.log(`finished job ${job.id} with  priority ${job.opts.priority}`);

    done(null, {});
  } catch (error) {
    console.log(error.response.data);
    try {
      done(error.response.data);
    } catch (e) {
      done('Something went wrong');
    }
  }
});

asyncTaskQueue.on('completed', async (job, result) => {
  console.log(`Job completed: ${job.id}, Type: ${job.name}, Result: ${result}`);

  console.log(job.id, job.name, job.data);
  await AsyncTask.findByIdAndUpdate(job.id, {
    status: 'completed',
    resultData: result,
  });
});

asyncTaskQueue.on('failed', async (job, error) => {
  console.log(
    `Job failed: ${job.id}, Type: ${job.name}, Error: ${error.message}`
  );

  await AsyncTask.findByIdAndUpdate(job.id, {
    status: 'failed',
    resultData: error,
  });
});

asyncTaskQueue.on('active', async (job) => {
  console.log(`Job active: ${job.id}, Type: ${job.name}`);

  await AsyncTask.findByIdAndUpdate(job.id, { status: 'active' });
});

asyncTaskQueue.on('waiting', async (jobId) => {
  console.log(`Job waiting: ${jobId} ${typeof jobId}`);
});

module.exports.asyncTaskQueue = asyncTaskQueue;
