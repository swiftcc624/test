const RecordType = {
  EMPLOYEE: 'employee',
  VENDOR: 'vendor',
  CUSTOMER: 'customer',
  CATEGORY: 'category',
  CURRENCY: 'currency',
  PROJECT: 'project',
  TASK: 'task',
  ITEM: 'item',
  ITEMVENDOR: 'itemVendor',
};

const processRecords = async (records, model, mapRecordToModel) => {
  let syncedCount = 0;
  const errors = [];

  for (const record of records) {
    try {
      const mappedRecord = await mapRecordToModel(record);
      const existingRecord = await model.findOne({
        nid: mappedRecord.nid,
      });
      if (existingRecord) {
        await updateRecord(existingRecord, record, mapRecordToModel);
      } else {
        await createRecord(model, record, mapRecordToModel);
      }
      syncedCount++;
    } catch (error) {
      errors.push(
        `Error processing record, ${JSON.stringify(record)}: ${error.message}`
      );
    }
  }

  return { syncedCount, errors };
};

const updateRecord = async (existingRecord, record, mapRecordToModel) => {
  const mappedRecord = await mapRecordToModel(record, 'update');
  Object.assign(existingRecord, mappedRecord);
  await existingRecord.save();
};

const createRecord = async (model, record, mapRecordToModel) => {
  const mappedRecord = await mapRecordToModel(record, 'create');
  await model.create(mappedRecord);
};

module.exports = {
  RecordType,
  processRecords,
};
