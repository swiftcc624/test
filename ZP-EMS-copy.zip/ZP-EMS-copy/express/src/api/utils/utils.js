const uuid = require('uuid');

function isUUIDv4(str) {
  try {
    return uuid.version(str) === 4;
  } catch (error) {
    return false;
  }
}

module.exports = {
  isUUIDv4,
};
