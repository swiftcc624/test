const getQueryOptions = (req) => {
  const { sorting, offset: _offset, limit: _limit, ...filters } = req.query;
  const queryOptions = {};
  Object.keys(filters).forEach((key) => {
    // if (filters[key] !== undefined && filters[key] !== null) {
    if (filters[key]) {
      queryOptions[key] = filters[key];
    }
  });

  return queryOptions;
};

const getSortOptions = (req) => {
  const { sorting } = req.query;
  const sortOptions = {};
  if (sorting) {
    const sortFields = sorting.split(',');
    sortFields.forEach((sortField) => {
      const sortOrder = sortField.startsWith('-') ? -1 : 1;
      const fieldName = sortField.replace(/^-/, '').replace(/-/, '.');
      sortOptions[fieldName] = sortOrder;
    });
  }
  return sortOptions;
};

const getPagination = (req) => {
  const { offset: _offset, limit: _limit } = req.query;
  const offset = parseInt(_offset || 0);
  const limit = parseInt(_limit || 10);

  return { offset, limit };
};

const buildPaginatedResponse = (items, totalResults, pagination) => {
  return {
    items,
    totalResults,
    count: items.length,
    offset: pagination.offset,
    limit: pagination.limit,
  };
};

module.exports = {
  getQueryOptions,
  getSortOptions,
  getPagination,
  buildPaginatedResponse,
};
