const express = require('express');
const { authorize } = require('../../middlewares/auth');
const File = require('../../models/file.model');
const moment = require('moment-timezone');

const router = express.Router();

const multer = require('multer');
const fs = require('fs');
const path = require('path');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const dir = `public/uploads/${moment().format('YYYY')}/${moment().format(
      'MM'
    )}`;
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(path.resolve(dir), { recursive: true });
    }
    cb(null, dir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  },
});
const upload = multer({ storage: storage });

const uploadFile = async (req, res) => {
  // req.file contains information about the uploaded file
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }

  const fileUrl = `${process.env.API_URL}/${req.file.path}`;

  // Send response
  res.send({
    message: 'File uploaded successfully.',
    fileUrl,
  });
};

router.route('/upload').post(authorize(), upload.single('file'), uploadFile);

const uploadFile2 = async (req, res) => {
  // req.file contains information about the uploaded file
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }

  const file = new File({
    filename: req.file.filename,
    filepath: req.file.path,
    url: `${process.env.API_URL}/${req.file.path}`,
    size: req.file.size,
    type: req.file.mimetype,
  });
  await file.save();

  res.send(file);
};

router.route('/upload2').post(authorize(), upload.single('file'), uploadFile2);

module.exports = router;
