const express = require('express');
const controller = require('../../controllers/asyncTask.controller');
const { authorize } = require('../../middlewares/auth');

const router = express.Router();

router.route('/').get(authorize(), controller.list);
router.route('/').post(authorize(), controller.create);
// router.route('/run').post(authorize(), controller.run);

// router.route('/:asyncTaskId').get(authorize(), controller.get);
// router.route('/:asyncTaskId').patch(authorize(), controller.update);
// router.route('/:asyncTaskId').delete(authorize(), controller.remove);

module.exports = router;
