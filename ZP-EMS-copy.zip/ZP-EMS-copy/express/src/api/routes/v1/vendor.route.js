const express = require('express');

const controller = require('../../controllers/vendor.controller');
const { authorize } = require('../../middlewares/auth');

const router = express.Router();

router.route('/:id').get(authorize(), controller.get);
router.route('/:id').put(authorize(), controller.update);
router.route('/:id').patch(authorize(), controller.update);

module.exports = router;
