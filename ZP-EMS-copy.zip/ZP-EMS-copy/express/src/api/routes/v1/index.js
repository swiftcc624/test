const express = require('express');
const userRoutes = require('./user.route');
const authRoutes = require('./auth.route');
const asyncTaskRoutes = require('./asyncTask.route');
const fileRoutes = require('./files.route');
const transactionRoutes = require('./transaction.route');
const transactionLineRoutes = require('./transactionLine.route');
const itemRoutes = require('./item.route');
const itemVendorRoutes = require('./itemVendor.route');

const settingsRoutes = require('./settings.route');
const expenseRoutes = require('./expense.route');
const expenseReportRoutes = require('./expenseReport.route');
const categoryRoutes = require('./category.route');
const currencyRoutes = require('./currency.route');
const invoiceRoutes = require('./invoice.route');

const projectRoutes = require('./project.route');
const taskRoutes = require('./task.route');
const timeEntryRoutes = require('./timeEntry.route');
const lineTimesheetRoutes = require('./lineTimesheet.route');
const weeklyTimesheetRoutes = require('./weeklyTimesheet.route');

const vendorRoutes = require('./vendor.route');

const adminRoutes = require('./admin/index.route');
const { authorize, ADMIN } = require('../../middlewares/auth');

const router = express.Router();

/**
 * GET v1/status
 */
router.get('/status', (req, res) => res.send('OK'));

/**
 * GET v1/docs
 */
router.use('/docs', express.static('docs'));

router.use('/users', userRoutes);
router.use('/auth', authRoutes);
router.use('/async-tasks', asyncTaskRoutes);
router.use('/files', fileRoutes);

router.use('/transactions', transactionRoutes);
router.use('/transaction-lines', transactionLineRoutes);
router.use('/items', itemRoutes);
router.use('/item-vendors', itemVendorRoutes);

router.use('/settings', settingsRoutes);

router.use('/categories', categoryRoutes);
router.use('/currencies', currencyRoutes);
router.use('/expenses', expenseRoutes);
router.use('/expense-reports', expenseReportRoutes);

router.use('/invoices', invoiceRoutes);

router.use('/projects', projectRoutes);
router.use('/tasks', taskRoutes);
router.use('/time-entries', timeEntryRoutes);
router.use('/line-timesheets', lineTimesheetRoutes);
router.use('/weekly-timesheets', weeklyTimesheetRoutes);

router.use('/vendors', vendorRoutes);

router.use('/admin', authorize(ADMIN), adminRoutes);

module.exports = router;
