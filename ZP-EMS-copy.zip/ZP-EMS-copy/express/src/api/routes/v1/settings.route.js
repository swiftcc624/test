const express = require('express');
const controller = require('../../controllers/settings.controller');
const { authorize, ADMIN } = require('../../middlewares/auth');

const router = express.Router();

router.route('/').get(authorize(), controller.get);
router.route('/').patch(authorize(), controller.update);

router
  .route('/test-netsuite-connection')
  .post(authorize(), controller.testNetsuiteConnection);

router
  .route('/verify-email-domain-identity')
  .post(authorize(ADMIN), controller.verifyEmailDomainIdentity);

router
  .route('/email-domain-identity')
  .get(authorize(ADMIN), controller.getEmailDomainIdentity);

// TODO: deprecated
// router
//   .route('/test-openai-connection')
//   .post(authorize(), controller.testOpenAIConnection);

module.exports = router;
