const express = require('express');
const controller = require('../../../controllers/admin/task.controller');

const router = express.Router();

router.route('/').get(controller.list);
router.route('/:id').patch(controller.update);

module.exports = router;
