const express = require('express');

const projectRoutes = require('./project.route');
const taskRoutes = require('./task.route');
const vendorRoutes = require('./vendor.route');

const router = express.Router();

router.use('/projects', projectRoutes);
router.use('/tasks', taskRoutes);
router.use('/vendors', vendorRoutes);

module.exports = router;
