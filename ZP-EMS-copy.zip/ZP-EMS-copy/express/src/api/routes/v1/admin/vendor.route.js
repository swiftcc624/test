const express = require('express');

const controller = require('../../../controllers/admin/vendor.controller');

const router = express.Router();

router.route('/').get(controller.list);
router.route('/').post(controller.create);

router.route('/invite').post(controller.invite);

router.route('/:id').get(controller.get);
router.route('/:id').put(controller.update);
router.route('/:id').patch(controller.update);
router.route('/:id').delete(controller.remove);

module.exports = router;
