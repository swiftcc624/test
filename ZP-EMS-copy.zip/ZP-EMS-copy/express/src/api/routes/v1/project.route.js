const express = require('express');
const controller = require('../../controllers/project.controller');
const { authorize, ADMIN } = require('../../middlewares/auth');

const router = express.Router();

router.route('/').get(authorize(), controller.list);

module.exports = router;
