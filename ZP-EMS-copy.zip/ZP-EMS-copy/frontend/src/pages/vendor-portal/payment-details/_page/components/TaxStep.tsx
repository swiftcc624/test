import { useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

import { usePaymentDetailsStore } from "../zustand/usePaymentDetailsStore";
import { TaxForm } from "./TaxForm";
import { TaxView } from "./TaxView";
import { updateVendor } from "@/api/sap/vendors";
import { uploadFile2 } from "@/api/files";

export const TaxStep = ({ data }: any) => {
  const queryClient = useQueryClient();
  const formRef = useRef(null);

  const { activeStepIndex, getActiveStep, setStepOptions } =
    usePaymentDetailsStore();

  const activeStep = getActiveStep();

  const { isEditing } = activeStep.options;

  const handleSave = async (values: any) => {
    try {
      const { taxFormFile } = values;
      let uploadedFile: any;
      if (typeof taxFormFile !== "string") {
        try {
          uploadedFile = await uploadFile2(taxFormFile);
        } catch (error) {
          console.log(error);
          toast.error("Error uploading tax form.");
          // return;
        }
      }
      if (!uploadedFile) {
        setStepOptions(activeStepIndex, { isEditing: false });
        return;
      }

      await updateVendor(data._id, {
        taxForm: { taxFormFileId: uploadedFile?._id },
      });
      toast.success("The tax form has updated successfully!");
      queryClient.invalidateQueries({ queryKey: ["vendorData"] });
      setStepOptions(activeStepIndex, { isEditing: false });
    } catch (error) {
      console.log(error);
      toast.error("Failed to update the tax form");
    }
  };

  return (
    <>
      {isEditing ? (
        <TaxForm initialValues={data} onSubmit={handleSave} ref={formRef} />
      ) : (
        <TaxView
          initialValues={data}
          onEdit={() => setStepOptions(activeStepIndex, { isEditing: true })}
        />
      )}
    </>
  );
};
