//@ts-nocheck
import { forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

import { Form } from "@/components/ui/form";
import { InputField } from "@/components/fields/InputField";
import { SelectField } from "@/components/fields/SelectField";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

import { usePaymentDetailsStore } from "../zustand/usePaymentDetailsStore";
import { CheckboxField } from "@/components/fields/CheckboxField";
import { CurrencyComboboxField } from "@/components/fields/advanced/CurrencyComboboxField";

interface PaymentMethodFormProps {
  onSubmit?: (data: any) => void;
  initialValues?: any;
  disabled?: boolean;
}

const LocalBankTransferFormGroup = ({ disabled }) => {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <Label className="w-40">Payment Currency</Label>
        <CurrencyComboboxField
          name="currencyId"
          className="w-full"
          disabled={disabled}
        />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">Name On Account</Label>
        <InputField
          name="nameOnAccount"
          className="w-full"
          disabled={disabled}
        />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">Bank Name</Label>
        <InputField name="bankName" className="w-full" disabled={disabled} />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">SWIFT</Label>
        <InputField name="swift" className="w-full" disabled={disabled} />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">IBAN</Label>
        <InputField name="iban" className="w-full" disabled={disabled} />
      </div>
      <div>
        Payment method minimum threshold: USD 50.00. Transaction fees:USD 5.00
      </div>
      <div className="flex items-center gap-2">
        <CheckboxField name="acceptFees" disabled={disabled} />
        <Label>2.5% FX fee may apply. </Label>
      </div>
    </div>
  );
};

const WireTransferFormGroup = ({ disabled }) => {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <Label className="w-40">Payment Currency</Label>
        <CurrencyComboboxField
          name="currencyId"
          className="w-full"
          disabled={disabled}
        />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">Name On Account</Label>
        <InputField
          name="nameOnAccount"
          className="w-full"
          disabled={disabled}
        />
      </div>

      <div className="flex items-center gap-2">
        <Label className="w-40">IBAN</Label>
        <InputField name="iban" className="w-full" disabled={disabled} />
      </div>

      <div className="flex items-center gap-2">
        <Label className="w-40">SWIFT</Label>
        <InputField name="swift" className="w-full" disabled={disabled} />
      </div>

      <div className="flex items-center gap-2">
        <Label className="w-40">Bank Name</Label>
        <InputField name="bankName" className="w-full" disabled={disabled} />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">Bank Street Address</Label>
        <InputField
          name="bankStreetAddress"
          className="w-full"
          disabled={disabled}
        />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">Bank Street Address</Label>
        <InputField name="bankAddress" className="w-full" disabled={disabled} />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">Bank Address 2</Label>
        <InputField
          name="bankAddress2"
          className="w-full"
          disabled={disabled}
        />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">Bank City, Province, ZIP</Label>
        <InputField
          name="bankCityProvinceZip"
          className="w-full"
          disabled={disabled}
        />
      </div>
    </div>
  );
};

const CheckFormGroup = ({ disabled }) => {
  return (
    <>
      <div>
        <Label className="py-4">
          Checks are sent by post to the address below. Please allow 15 business
          days for the check to arrive. <br />
          Checks are for deposit only, and cannot be transferred. <br />
          The checks' currency will be as displayed above.
        </Label>
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">Currency</Label>

        <CurrencyComboboxField
          name="currencyId"
          className="w-full"
          disabled={disabled}
        />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">Name on Check</Label>
        <InputField name="nameOnCheck" className="w-full" disabled={disabled} />
      </div>
      <div className="flex items-center gap-2">
        <Label className="w-40">Address to Send Check</Label>
        <InputField
          name="addressToSend"
          className="w-full"
          disabled={disabled}
        />
      </div>
      <div>
        <Label className="py-4">
          Payment method minimum threshold: USD 50.00. No transaction fees.
        </Label>
      </div>
    </>
  );
};

export const PaymentMethodForm = forwardRef(
  (
    { initialValues, onSubmit, disabled = false }: PaymentMethodFormProps,
    ref
  ) => {
    const { activeStepIndex, setStepOptions } = usePaymentDetailsStore();

    const formSchema = z.object({
      method: z.string().min(1),
      // data: z.object({
      //   paymentCurrency: z.string().min(1),
      //   nameOnAccount: z.string().min(1),
      //   bankName: z.string().min(1),
      //   swift: z.string().min(1),
      //   iban: z.string().min(1),
      //   bankStreetAddress: z.string().min(1),
      //   bankAddress: z.string().min(1),
      //   bankAddress2: z.string().min(1),
      //   bankCityProvinceZip: z.string().min(1),
      // }),
      // currency: z.string().min(1),
      // nameOnCheck: z.string().min(1),
      // addressToSend: z.string().min(1),
    });

    const form = useForm({
      // resolver: zodResolver(formSchema),
      defaultValues: {
        ...(initialValues?.paymentMethod ? initialValues.paymentMethod : {}),
      },
    });

    useImperativeHandle(ref, () => ({
      submit: form.handleSubmit(onSubmit),
    }));

    const method = form.watch("method");

    return (
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="flex flex-col gap-4"
        >
          <div className="flex items-center gap-2">
            <Label className="w-40">Payment Method: </Label>
            <SelectField
              name="method"
              label=""
              options={[
                {
                  key: "local_bank_transfer",
                  label: "Local Bank Transfer / SEPA Transfer",
                },
                { key: "wire_transfer", label: "Wire Transfer" },
                { key: "check", label: "Check" },
              ]}
              getOptionValue={(option) => option.key}
              getOptionLabel={(option) => option.label}
              className="w-full"
              disabled={disabled}
            />
          </div>

          {method === "local_bank_transfer" && (
            <LocalBankTransferFormGroup disabled={disabled} />
          )}
          {method === "wire_transfer" && (
            <WireTransferFormGroup disabled={disabled} />
          )}
          {method === "check" && <CheckFormGroup disabled={disabled} />}
        </form>
      </Form>
    );
  }
);
