import { forwardRef, useImperativeHandle } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

import { Form } from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

import { usePaymentDetailsStore } from "../zustand/usePaymentDetailsStore";
import { DropzoneField } from "@/components/fields/DropzoneField";

interface TaxFormProps {
  onSubmit: SubmitHandler<{ taxFormFile: any }>;
  initialValues?: any;
}

export const TaxForm = forwardRef(
  ({ initialValues, onSubmit }: TaxFormProps, ref) => {
    const { activeStepIndex, setStepOptions } = usePaymentDetailsStore();

    const formSchema = z.object({
      taxFormFile: z.any(),
    });

    const form = useForm({
      resolver: zodResolver(formSchema),
      defaultValues: {
        taxFormFile: initialValues?.taxForm?.taxFormFile?.url || "",
      },
    });

    useImperativeHandle(ref, () => ({
      submit: form.handleSubmit(onSubmit),
    }));

    return (
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="flex flex-col gap-4"
        >
          <div className="flex flex-col gap-2">
            <Label className="w-40 pt-3">Upload a tax form: </Label>
            <DropzoneField name="taxFormFile" multiple={false} />
          </div>

          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setStepOptions(activeStepIndex, { isEditing: false });
              }}
            >
              Cancel
            </Button>
            <Button>Save</Button>
          </div>
        </form>
      </Form>
    );
  }
);
