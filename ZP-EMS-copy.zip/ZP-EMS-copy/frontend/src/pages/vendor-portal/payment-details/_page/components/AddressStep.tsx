import { updateVendor } from "@/api/sap/vendors";
import { useQueryClient } from "@tanstack/react-query";
import { useRef } from "react";
import { toast } from "sonner";
import { AddressForm } from "./AddressForm";
import { usePaymentDetailsStore } from "../zustand/usePaymentDetailsStore";
import { Button } from "@/components/ui/button";

export const AddressStep = ({ data }: any) => {
  const queryClient = useQueryClient();
  const formRef = useRef(null);

  const { activeStepIndex, getActiveStep, setStepOptions } =
    usePaymentDetailsStore();

  const activeStep = getActiveStep();

  const { isEditing } = activeStep.options;

  const handleSave = async (values: any) => {
    console.log(values);
    try {
      await updateVendor(data._id, { address: values });
      toast.success("The vendor address has updated successfully!");
      queryClient.invalidateQueries({ queryKey: ["vendorData"] });
      setStepOptions(activeStepIndex, { isEditing: false });
    } catch (error) {
      console.log(error);
      toast.error("Failed to update the vendor address");
    }
  };

  return (
    <>
      <AddressForm
        initialValues={data}
        onSubmit={handleSave}
        ref={formRef}
        disabled={!isEditing}
      />

      <div className="flex justify-end gap-2">
        {isEditing ? (
          <>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setStepOptions(activeStepIndex, { isEditing: false });
              }}
            >
              Cancel
            </Button>
            <Button onClick={() => formRef.current?.submit()}>Save</Button>
          </>
        ) : (
          <Button
            variant="outline"
            onClick={() => setStepOptions(activeStepIndex, { isEditing: true })}
          >
            Edit
          </Button>
        )}
      </div>
    </>
  );
};
