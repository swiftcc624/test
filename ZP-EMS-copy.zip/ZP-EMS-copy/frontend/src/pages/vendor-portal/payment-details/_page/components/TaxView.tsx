import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import PDFViewer from "@/components/widgets/PdfViewer";

export const TaxView = ({
  initialValues,
  onEdit,
}: {
  initialValues: any;
  onEdit: () => void;
}) => {
  const { taxForm } = initialValues || {};
  const { taxFormFile } = taxForm || {};

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-2">
        <Label className="w-40 pt-3">Tax Form: </Label>
        {taxFormFile && (
          <div>
            {taxFormFile.url.endsWith(".pdf") ? (
              <PDFViewer
                pdfUrl={taxFormFile.url}
                // width={120}
                height={200}
              />
            ) : (
              <img className="h-[120px] w-auto" src={taxFormFile.url} />
            )}
          </div>
        )}
      </div>
      <div className="flex justify-end">
        <Button onClick={onEdit} variant="outline">
          Edit
        </Button>
      </div>
    </div>
  );
};
