import { updateVendor } from "@/api/sap/vendors";
import { useQueryClient } from "@tanstack/react-query";
import { useRef } from "react";
import { toast } from "sonner";
import { usePaymentDetailsStore } from "../zustand/usePaymentDetailsStore";
import { PaymentMethodForm } from "./PaymentMethodForm";
import { Button } from "@/components/ui/button";

export const PaymentMethodStep = ({ data }: any) => {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);

  const { activeStepIndex, getActiveStep, setStepOptions } =
    usePaymentDetailsStore();

  const activeStep = getActiveStep();

  const { isEditing } = activeStep.options;

  const handleSave = async (values: any) => {
    try {
      await updateVendor(data._id, { paymentMethod: values });
      toast.success("The payment method has updated successfully!");
      queryClient.invalidateQueries({ queryKey: ["vendorData"] });
      setStepOptions(activeStepIndex, { isEditing: false });
    } catch (error) {
      console.log(error);
      toast.error("Failed to update the payment method");
    }
  };

  return (
    <>
      <PaymentMethodForm
        initialValues={data}
        onSubmit={handleSave}
        ref={formRef}
        disabled={!isEditing}
      />

      <div className="flex justify-end gap-2">
        {isEditing ? (
          <>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setStepOptions(activeStepIndex, { isEditing: false });
              }}
            >
              Cancel
            </Button>
            <Button onClick={() => formRef.current?.submit()}>Save</Button>
          </>
        ) : (
          <Button
            variant="outline"
            onClick={() => setStepOptions(activeStepIndex, { isEditing: true })}
          >
            Edit
          </Button>
        )}
      </div>
    </>
  );
};
