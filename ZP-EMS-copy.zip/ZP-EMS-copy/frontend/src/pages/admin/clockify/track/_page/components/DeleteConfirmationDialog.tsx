import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";

export const DeleteConfirmationDialog = ({
  dialogId = DIALOG_ID.DELETE_CONFIRMATION,
  onConfirm,
  title,
}: {
  dialogId?: DIALOG_ID;
  onConfirm: (dialogData: any) => void;
  title: string;
}) => {
  useDialogStore((state) => state.dialogs[dialogId]);

  return (
    <AlertDialog
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          <AlertDialogDescription></AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>No</AlertDialogCancel>
          <AlertDialogAction
            onClick={() => onConfirm(dialogActions.getDialogData(dialogId))}
          >
            Yes
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
