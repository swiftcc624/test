import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";

import { DIALOG_ID, useDialogStore } from "@/zustand/useDialogStore";
import { useClockifyTrackStore } from "../zustand/useClockifyTrackStore";

export const EditTimeEntryDescriptionDialog = ({
  dialogId = DIALOG_ID.EDIT_TIME_ENTRY_DESCRIPTION,
}: {
  dialogId?: DIALOG_ID;
}) => {
  const { updateLineTimesheetTimeEntry }: any = useClockifyTrackStore();

  const { isDialogOpen, getDialogData, closeDialog }: any = useDialogStore();

  const dialogData = getDialogData(dialogId);

  const [description, setDescription] = useState("");

  useEffect(() => {
    if (dialogData) {
      const { lineTimesheet, date } = dialogData;
      setDescription(lineTimesheet?.timeEntries?.[date]?.description || "");
    }
  }, [dialogData]);

  const handleSave = async () => {
    const { lineTimesheet, date } = dialogData;

    await updateLineTimesheetTimeEntry(lineTimesheet, date, {
      description,
    });

    closeDialog(dialogId);
    toast.success("Time entry description updated successfully!");
  };

  return (
    <Dialog
      open={isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) {
          closeDialog(dialogId);
        }
      }}
    >
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Edit Time Entry Description</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <Textarea
            placeholder=""
            value={description}
            onChange={(e) => {
              setDescription(e.target.value);
            }}
          />
        </div>
        <DialogFooter>
          <Button onClick={handleSave}>Save changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
