// @ts-nocheck
import React from "react";
import { ColumnDef } from "@tanstack/react-table";
import { Trash2Icon, PencilIcon } from "lucide-react";
import moment from "moment-timezone";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Combobox } from "@/components/fields/Combobox";

import {
  useClockifyTrackStore,
  getDateForWeekday,
} from "../zustand/useClockifyTrackStore";

import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { getProjects } from "@/api/clockify/projects";
import { useQuery } from "@tanstack/react-query";
import { getTasks } from "@/api/clockify/tasks";

const formatDate = (date) => moment(date).format("MMM DD");

const ProjectCell = ({ getValue, row: { index }, column: { id }, table }) => {
  const { updateLineTimesheetProject } = useClockifyTrackStore();

  const { data: projects } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      return await getProjects({});
    },
  });

  const lineTimesheet = table.options.data[index];

  const containerRef = React.useRef(null);
  const initialValue = getValue();

  const [value, setValue] = React.useState(initialValue);

  React.useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  return (
    <Combobox
      value={value}
      containerRef={containerRef}
      onSelect={(value) => {
        setValue(value);
        updateLineTimesheetProject(lineTimesheet, value);
      }}
      options={projects || []}
      getOptionValue={(option) => option._id}
      getOptionLabel={(option) => option.name}
      className={lineTimesheet.projectId ? "" : "border-red-500"}
      multipleGroups={true}
      getGroupValue={(option) => option.customerId?._id || "nocustomer"}
      getGroupLabel={(option) => option.customerId?.name || "No Customer"}
    />
  );
};

const TaskCell = ({ getValue, row: { index }, column: { id }, table }) => {
  const { updateLineTimesheetTask } = useClockifyTrackStore();

  const lineTimesheet = table.options.data[index];

  const { data: tasks } = useQuery({
    queryKey: ["tasks", lineTimesheet.projectId],
    queryFn: async () => {
      return await getTasks({ projectId: lineTimesheet.projectId });
    },
  });

  const containerRef = React.useRef(null);
  const initialValue = getValue();

  const [value, setValue] = React.useState(initialValue);

  React.useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  return (
    <Combobox
      value={value}
      containerRef={containerRef}
      onSelect={async (value) => {
        setValue(value);
        await updateLineTimesheetTask(lineTimesheet, value);
      }}
      options={tasks || []}
      getOptionValue={(option) => option._id}
      getOptionLabel={(option) => option.name}
      className={lineTimesheet.taskId ? "" : "border-red-500"}
    />
  );
};

const TimeEntryCell = ({ getValue, row: { index }, column: { id }, table }) => {
  const { updateLineTimesheetTimeEntry, weekStartDate } =
    useClockifyTrackStore();

  const ref = React.useRef(null);

  const [error, setError] = React.useState("");

  const lineTimesheet = table.options.data[index];

  const initialValue =
    lineTimesheet.timeEntries?.[getDateForWeekday(id, weekStartDate)]
      ?.duration || "";

  const [value, setValue] = React.useState(initialValue);

  const onBlur = () => {
    setError("");
    if (!value) {
      return;
    }

    if (isNaN(value) || parseFloat(value) <= 0) {
      toast.error("Invalid value");
      setError("Invalid value");
      ref?.current.focus();
      return;
    }

    const date = getDateForWeekday(id, weekStartDate);
    updateLineTimesheetTimeEntry(lineTimesheet, date, {
      duration: value,
    });
  };

  React.useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  return (
    <div className="flex justify-between gap-[2px]">
      <Input
        ref={ref}
        value={value as string}
        onChange={(e) => setValue(e.target.value)}
        onBlur={onBlur}
        disabled={!lineTimesheet.projectId || !lineTimesheet.taskId}
        className={cn("min-w-[60px]", error ? "border-red-500" : "")}
      />

      <Button
        variant="ghost"
        size="icon"
        onClick={() => {
          {
            dialogActions.openDialog(DIALOG_ID.EDIT_TIME_ENTRY_DESCRIPTION, {
              lineTimesheet,
              date: getDateForWeekday(id, weekStartDate),
            });
          }
        }}
      >
        <PencilIcon className="h-4 w-4" />
      </Button>
    </div>
  );
};

export const columns: ColumnDef[] = [
  {
    accessorKey: "id",
    header: ({ column }) => {
      return <div>Id</div>;
    },
    cell: ({ row }) => {
      return <div>{row.original._id}</div>;
    },
    isVisible: false,
  },
  {
    accessorKey: "rowId",
    header: ({ column }) => {
      return <div>Row Id</div>;
    },
  },

  {
    accessorKey: "projectId",
    header: ({ column }) => {
      return <div className="w-[200px]">Project</div>;
    },
    cell: ProjectCell,
  },
  {
    accessorKey: "taskId",
    header: ({ column }) => {
      return <div className="w-[200px]">Task</div>;
    },
    cell: TaskCell,
  },
  {
    accessorKey: "mon",
    header: ({ column }) => {
      const { weekStartDate } = useClockifyTrackStore();

      return (
        <div>
          {formatDate(getDateForWeekday(column.id, weekStartDate))}, Mon
        </div>
      );
    },
    cell: TimeEntryCell,
  },
  {
    accessorKey: "tue",
    header: ({ column }) => {
      const { weekStartDate } = useClockifyTrackStore();

      return (
        <div>
          {formatDate(getDateForWeekday(column.id, weekStartDate))}, Tue
        </div>
      );
    },
    cell: TimeEntryCell,
  },
  {
    accessorKey: "wed",
    header: ({ column }) => {
      const { weekStartDate } = useClockifyTrackStore();

      return (
        <div>
          {formatDate(getDateForWeekday(column.id, weekStartDate))}, Wed
        </div>
      );
    },
    cell: TimeEntryCell,
  },
  {
    accessorKey: "thu",
    header: ({ column }) => {
      const { weekStartDate } = useClockifyTrackStore();

      return (
        <div>
          {formatDate(getDateForWeekday(column.id, weekStartDate))}, Thu
        </div>
      );
    },
    cell: TimeEntryCell,
  },
  {
    accessorKey: "fri",
    header: ({ column }) => {
      const { weekStartDate } = useClockifyTrackStore();

      return (
        <div>
          {formatDate(getDateForWeekday(column.id, weekStartDate))}, Fri
        </div>
      );
    },
    cell: TimeEntryCell,
  } /*
  {
    accessorKey: "sat",
    header: ({ column }) => {
      const { weekStartDate } = useClockifyTrackStore();

      return (
        <div>
          {formatDate(getDateForWeekday(column.id, weekStartDate))}, Sat
        </div>
      );
    },
    cell: TimeEntryCell,
  },
  {
    accessorKey: "sun",
    header: ({ column }) => {
      const { weekStartDate } = useClockifyTrackStore();

      return (
        <div>
          {formatDate(getDateForWeekday(column.id, weekStartDate))}, Sun
        </div>
      );
    },
    cell: TimeEntryCell,
  },*/,
  {
    accessorKey: "actions",
    header: ({ column }) => {
      return <div>Actions</div>;
    },
    cell: ({ row }) => {
      return (
        <Button
          variant="icon"
          onClick={() =>
            dialogActions.openDialog(
              DIALOG_ID.DELETE_CONFIRMATION,
              row.original
            )
          }
        >
          <Trash2Icon />
        </Button>
      );
    },
  },
];
