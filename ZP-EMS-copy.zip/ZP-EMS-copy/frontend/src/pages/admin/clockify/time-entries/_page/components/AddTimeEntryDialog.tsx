import { useEffect, useRef } from "react";
import { toast } from "sonner";
import { Loader2Icon } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import {
  useDialogStore,
  dialogActions,
  DIALOG_ID,
} from "@/zustand/useDialogStore";
import { useFormStore, formActions, FormState } from "@/zustand/useFormStore";
import { TimeEntryForm } from "./TimeEntryForm";
import { createTimeEntry } from "@/api/clockify/timeEntries";
import { useQueryClient } from "@tanstack/react-query";

export const ADD_TIME_ENTRY_FORM = "add_time_entry_form";

export const AddTimeEntryDialog = ({
  dialogId = DIALOG_ID.ADD_TIME_ENTRY,
}: {
  dialogId?: DIALOG_ID;
}) => {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore();
  useFormStore();

  useEffect(() => {
    formActions.setFormState(ADD_TIME_ENTRY_FORM, FormState.Ready);
  }, []);

  const handleSave = async (values: any) => {
    formActions.setFormState(ADD_TIME_ENTRY_FORM, FormState.Submititng);

    try {
      await createTimeEntry(values);

      dialogActions.closeDialog(dialogId);
      toast.success("Time entry added successfully!");
      queryClient.invalidateQueries({ queryKey: ["clockifyTimeEntries"] });
    } catch (error) {
      console.log(error);
      toast.error("Failed to add time entry");
    }

    formActions.setFormState(ADD_TIME_ENTRY_FORM, FormState.Ready);
  };

  const formState = formActions.getFormState(ADD_TIME_ENTRY_FORM);

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) {
          dialogActions.closeDialog(dialogId);
        }
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>New Time Entry</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          <TimeEntryForm
            onSubmit={handleSave}
            ref={formRef}
            initialValues={dialogActions.getDialogData(dialogId)}
          />
        </div>
        <SheetFooter>
          <Button
            className="w-full"
            onClick={() => formRef?.current?.submit()}
            disabled={
              formState === FormState.Loading ||
              formState === FormState.Submititng
            }
          >
            {formState === FormState.Submititng && (
              <Loader2Icon className="mr-2 h-4 w-4 animate-spin" />
            )}
            Save
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
};
