//@ts-nocheck
import { forwardRef, useImperativeHandle, useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useQuery } from "@tanstack/react-query";

import { Form } from "@/components/ui/form";
import { InputField } from "@/components/fields/InputField";
import { TextareaField } from "@/components/fields/TextareaField";
import { ComboboxField } from "@/components/fields/ComboboxField";

import { getProjects } from "@/api/clockify/projects";
import { getTasks } from "@/api/clockify/tasks";

interface TimeEntryFormProps {
  onSubmit?: (data: any) => void;
  initialValues?: any;
}

export const TimeEntryForm = forwardRef(
  ({ initialValues, onSubmit }: TimeEntryFormProps, ref) => {
    const { data: projects } = useQuery({
      queryKey: ["clockifyProjects"],
      queryFn: async () => {
        return await getProjects({});
      },
    });

    const formSchema = z.object({
      projectId: z.string().min(1),
      taskId: z.string().min(1),
      date: z.string().min(1), // TODO: better date validation
      duration: z.coerce.number().min(0.001).max(100),
      description: z.string().optional(),
    });

    const form = useForm({
      resolver: zodResolver(formSchema),
      defaultValues: {
        projectId: initialValues?.lineTimesheet?.projectId || "",
        taskId: initialValues?.lineTimesheet?.taskId || "",
        date: initialValues?.date
          ? new Date(initialValues?.date).toISOString().split("T")[0]
          : new Date().toISOString().split("T")[0],
        duration: initialValues?.duration || "",
        description: initialValues?.description || "",
      },
    });

    const projectId = form.watch("projectId");

    const { data: tasks } = useQuery({
      queryKey: ["clockifyTasks"],
      queryFn: async () => {
        return await getTasks({ projectId });
      },
      enabled: !!projectId,
    });

    useImperativeHandle(ref, () => ({
      submit: form.handleSubmit(onSubmit),
    }));

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <ComboboxField
            name="projectId"
            options={projects || []}
            getOptionValue={(option) => option._id}
            getOptionLabel={(option) => option.name}
          />
          <ComboboxField
            name="taskId"
            options={tasks || []}
            getOptionValue={(option) => option._id}
            getOptionLabel={(option) => option.name}
          />

          <div className="flex gap-2">
            <InputField
              name="date"
              label="Date"
              type="date"
              className="w-full"
            />
          </div>
          <div className="flex gap-2">
            <InputField name="duration" label="Duration" className="w-full" />
          </div>

          <div className="flex gap-2">
            <TextareaField
              name="description"
              label="Description"
              className="w-full"
            />
          </div>
        </form>
      </Form>
    );
  }
);
