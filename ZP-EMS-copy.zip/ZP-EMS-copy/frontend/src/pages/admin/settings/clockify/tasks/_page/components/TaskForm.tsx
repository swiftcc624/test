//@ts-nocheck
import { forwardRef, useEffect, useImperativeHandle, useMemo } from "react";
import { useForm } from "react-hook-form";
import { useQuery } from "@tanstack/react-query";

import * as z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import { Form } from "@/components/ui/form";
import { InputField } from "@/components/fields/InputField";
import { TextareaField } from "@/components/fields/TextareaField";
import { ComboboxField } from "@/components/fields/ComboboxField";
import { FancyMultiSelectField } from "@/components/fields/FancyMultiSelectField";

import { getUsers } from "@/api/users";

interface TaskFormProps {
  onSubmit?: (data: any) => void;
  initialValues?: any;
}

export const TaskForm = forwardRef(
  ({ initialValues, onSubmit }: TaskFormProps, ref) => {
    const formSchema = z.object({
      customerId: z.string().min(1),
      projectId: z.string().min(1),
      name: z.string().min(1),
      description: z.string().optional(),
      assigneeIds: z.string().array().optional(),
    });

    const form = useForm({
      resolver: zodResolver(formSchema),
      defaultValues: {
        customerId: initialValues?.customer?.id || "",
        projectId: initialValues?.project?.id || "",
        name: initialValues?.name || "",
        description: initialValues?.description || "",
        assigneeIds: initialValues?.assigneeIds || [],
      },
    });

    const { data: customers } = useQuery({
      queryKey: ["customers"],
      queryFn: async () => {
        return await getClientProjects({});
      },
    });

    const { data: users } = useQuery({
      queryKey: ["getUsers"],
      queryFn: async () => {
        const users = await getUsers({});

        const userOptions = users?.map((user) => ({
          value: user.id,
          label: user.name,
        }));

        return userOptions;
      },
    });

    const customerId = form.watch("customerId");

    const projects = useMemo(() => {
      let _projects = [];
      try {
        _projects = customers.find((c) => c._id === customerId).projects || [];
      } catch (e) {}

      return _projects;
    }, [customers, customerId]);

    useImperativeHandle(ref, () => ({
      submit: form.handleSubmit(onSubmit),
    }));

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <ComboboxField
            name="customerId"
            label="Customer"
            options={customers}
            getOptionValue={(option) => option._id}
            getOptionLabel={(option) => option.name}
            onSelect={(value) => {
              form.setValue("customerId", value);
              form.setValue("projectId", "");
            }}
          />
          <ComboboxField
            name="projectId"
            label="Project"
            options={projects || []}
            getOptionValue={(option) => option._id}
            getOptionLabel={(option) => option.name}
          />

          <div className="flex gap-2">
            <InputField name="name" label="Name" className="w-full" />
          </div>

          <div className="flex gap-2">
            <TextareaField
              name="description"
              label="Description"
              className="w-full"
            />
          </div>

          <div className="flex gap-2">
            <FancyMultiSelectField
              name="assigneeIds"
              label="Assignees"
              options={users || []}
              placeholder="Select Assignees"
              className="w-full"
            />
          </div>
        </form>
      </Form>
    );
  }
);
