// @ts-nocheck
import React from "react";
import { ColumnDef } from "@tanstack/react-table";

import { Button } from "@/components/ui/button";
import { DataTableColumnHeader } from "@/components/widgets/data-table/DataTableColumnHeader";
import { EDIT_TASK_DIALOG } from "./EditTaskDialog";
import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";

export const columns: ColumnDef[] = [
  //   {
  //     accessorKey: "id",
  //     header: ({ column }) => {
  //       return <DataTableColumnHeader column={column} title="ID" />;
  //     },
  //     cell: ({ row }) => {
  //       return <span>{row.original.id}</span>;
  //     },
  //   },

  {
    accessorKey: "customerName",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Customer" />;
    },
    cell: ({ row }) => {
      return <span>{row.original.project?.customer?.name}</span>;
    },
  },
  {
    accessorKey: "project.name",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Project" />;
    },
    cell: ({ row }) => {
      return <span>{row.original.project?.name}</span>;
    },
  },
  {
    accessorKey: "name",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Name" />;
    },
    cell: ({ row }) => {
      return <span>{row.original.name}</span>;
    },
  },
  {
    accessorKey: "description",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Description" />;
    },
    cell: ({ row }) => {
      return (
        <span>
          {row.original.description?.length > 50
            ? row.original.description.substring(0, 50) + "..."
            : row.original.description}
        </span>
      );
    },
  },
  {
    accessorKey: "assignees",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Assignees" />;
    },
    cell: ({ row }) => {
      return (
        <span>
          {row.original.assignees?.map((user) => user.name).join(", ")}
        </span>
      );
    },
  },
  {
    id: "actions",
    cell: ({ row, table }) => (
      <div className="flex gap-2">
        {/* <Button
          variant="default"
          onClick={() => {
            dialogActions.openDialog(DIALOG_ID.EDIT_TASK, row.original);
          }}
        >
          Edit
        </Button> */}
      </div>
    ),
  },
];
