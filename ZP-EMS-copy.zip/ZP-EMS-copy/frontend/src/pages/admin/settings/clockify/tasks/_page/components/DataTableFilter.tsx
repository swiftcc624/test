// @ts-nocheck
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { RotateCcwIcon, SearchIcon, SlidersHorizontalIcon } from "lucide-react";
import { useForm } from "react-hook-form";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Form } from "@/components/ui/form";
import { ComboboxField } from "@/components/fields/ComboboxField";

const DEFAULT_VALUES = {
  projectId: "",
  customerId: "",
};

export const DataTableFilter = ({ filters, setFilters }: any) => {
  // const { authUser } = useRouteLoaderData("root");
  const form = useForm({
    defaultValues: DEFAULT_VALUES,
  });

  const { data: customers } = useQuery({
    queryKey: ["customers"],
    queryFn: async () => {
      return await getClientProjects({});
    },
  });

  const [showFilters, setShowFilters] = useState(true);

  const filterCount = useMemo(() => {
    return Object.keys(filters).reduce((filterCount, key: string) => {
      // @ts-ignore
      if (filters[key] != DEFAULT_VALUES[key]) {
        return filterCount + 1;
      }
      return filterCount;
    }, 0);
  }, [filters]);

  const handleShowFilters = () => {
    setShowFilters(!showFilters);
  };

  const handleReset = () => {
    form.reset({ ...DEFAULT_VALUES });
  };

  const customerId = form.watch("customerId");
  const projectId = form.watch("projectId");

  const handleFilter = (values: any) => {
    setFilters(values);
  };

  const projects = useMemo(() => {
    let _projects = [];
    try {
      _projects = customers.find((c) => c._id === customerId).projects || [];
    } catch (e) {}

    return _projects;
  }, [customers, customerId]);

  useEffect(() => {
    form.setValue("projectId", "");
  }, [customerId]);

  useEffect(() => {
    handleFilter({
      customerId,
      projectId,
    });
  }, [customerId, projectId]);

  return (
    <div>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(() => {})} className="space-y-4">
          <div className="flex gap-4">
            <Button size="sm" onClick={handleShowFilters}>
              <SlidersHorizontalIcon className="mr-2 h-4 w-4" />
              {showFilters ? "Hide Filters" : "Show Filters"}
              {filterCount !== 0 && (
                <Badge variant="secondary" className="ml-2">
                  {filterCount}
                </Badge>
              )}
            </Button>

            {filterCount !== 0 && (
              <Button
                variant="ghost"
                size="sm"
                type="button"
                onClick={handleReset}
              >
                <RotateCcwIcon className="mr-2 h-4 w-4" /> Reset
              </Button>
            )}
          </div>

          {showFilters && (
            <div className="mt-2 flex flex-col gap-2">
              <div className="flex gap-4">
                <div className="flex items-center h-[40px]">
                  <SearchIcon className="h-4 w-4" />
                </div>
                <div className="flex-1 grid xs:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-2">
                  <ComboboxField
                    name="customerId"
                    label=""
                    options={[
                      { _id: "", name: "All Customers" },
                      ...(customers || []),
                    ]}
                    getOptionLabel={(option) => option.name}
                    getOptionValue={(option) => option._id}
                    placeholder="Select Customer..."
                  />
                  <ComboboxField
                    name="projectId"
                    label=""
                    options={[
                      { _id: "", name: "All Projects" },
                      ...(projects || []),
                    ]}
                    getOptionLabel={(option) => option.name}
                    getOptionValue={(option) => option._id}
                    placeholder="Select Project..."
                  />
                </div>
              </div>
            </div>
          )}
        </form>
      </Form>
    </div>
  );
};
