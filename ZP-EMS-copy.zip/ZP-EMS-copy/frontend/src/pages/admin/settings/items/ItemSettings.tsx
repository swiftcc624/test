import { useState } from "react";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { PaginationState, SortingState } from "@tanstack/react-table";

import { Button } from "@/components/ui/button";

import { DataTable } from "@/components/widgets/data-table/DataTable";
import { columns } from "./components/columns";

import { HeaderPortal } from "@/pages/_page/HeaderPortal";

import { useSync } from "../connections/_page/hooks/useSync";
import { getItems } from "@/api/items";
import { generateSortingParam } from "@/lib/utils";

export const ItemSettings = () => {
  const queryClient = useQueryClient();

  const [sorting, setSorting] = useState<SortingState>([]);
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });

  const { data } = useQuery({
    queryKey: ["items", sorting, pagination],
    queryFn: async () => {
      return await getItems({
        sorting: generateSortingParam(sorting),
        limit: pagination.pageSize,
        offset: pagination.pageIndex * pagination.pageSize,
      });
    },
  });

  const { handleSync } = useSync(["sync_item", "sync_itemvendor"], () => {
    queryClient.invalidateQueries({ queryKey: ["items"] });
  });

  return (
    <div>
      <HeaderPortal>
        <h1 className="text-xl font-bold">Items</h1>
        <div className="flex gap-2">
          <Button onClick={handleSync}>Sync</Button>
        </div>
      </HeaderPortal>
      <div className="p-4">
        <DataTable
          columns={columns}
          data={data?.items || []}
          sorting={sorting}
          setSorting={setSorting}
          pagination={pagination}
          setPagination={setPagination}
          rowCount={data?.totalResults || 0}
        />
      </div>
    </div>
  );
};
