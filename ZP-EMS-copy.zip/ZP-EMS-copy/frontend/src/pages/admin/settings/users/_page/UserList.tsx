import { useQuery, useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";

import { columns } from "./components/columns";
import { DataTable } from "@/components/widgets/data-table/DataTable";
import { AddUserDialog } from "./components/AddUserDialog";
import { EditUserDialog } from "./components/EditUserDialog";
import { HeaderPortal } from "@/pages/_page/HeaderPortal";
import { useSync } from "../../connections/_page/hooks/useSync";
import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";
import { useState } from "react";
import { PaginationState, SortingState } from "@tanstack/react-table";
import { deleteUser, getUsers, updateUser } from "@/api/users";
import { generateSortingParam } from "@/lib/utils";
import { DeleteConfirmationDialog } from "@/pages/admin/clockify/track/_page/components/DeleteConfirmationDialog";
import { toast } from "sonner";

export const UserList = () => {
  const queryClient = useQueryClient();

  const [sorting, setSorting] = useState<SortingState>([]);
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });

  const { data } = useQuery({
    queryKey: ["users", sorting, pagination],
    queryFn: async () => {
      return await getUsers({
        userType: "employee",
        sorting: generateSortingParam(sorting),
        limit: pagination.pageSize,
        offset: pagination.pageIndex * pagination.pageSize,
      });
    },
  });

  const { handleSync } = useSync(["sync_employee"], () => {
    queryClient.invalidateQueries({ queryKey: ["users"] });
  });

  const handleDelete = async (dialogData: any) => {
    try {
      await deleteUser(dialogData.user.id);
      queryClient.invalidateQueries({ queryKey: ["users"] });
      toast.success("User removed");
    } catch (error) {
      console.error(error);
      toast.error("Error removing user");
    }
  };

  return (
    <div>
      <HeaderPortal>
        <h1 className="text-xl font-bold">Users</h1>
        <div className="flex gap-2">
          <Button onClick={handleSync}>Sync</Button>

          <Button
            className="ml-auto"
            onClick={() => dialogActions.openDialog(DIALOG_ID.ADD_USER)}
          >
            New User
          </Button>
        </div>
      </HeaderPortal>
      <div className="p-4">
        <DataTable
          columns={columns}
          data={data?.items || []}
          sorting={sorting}
          setSorting={setSorting}
          pagination={pagination}
          setPagination={setPagination}
          rowCount={data?.totalResults || 0}
          meta={{
            toggleActive: async (row: any, checked: boolean) => {
              try {
                await updateUser(row.original._id, {
                  status: checked ? "active" : "inactive",
                });

                queryClient.invalidateQueries({ queryKey: ["users"] });
                toast.success("User updated");
              } catch (error) {
                console.error(error);
                toast.error("Error updating user");
              }
            },
          }}
        />
      </div>
      <AddUserDialog />
      <EditUserDialog />
      <DeleteConfirmationDialog
        title="Are you sure you want to delete this user?"
        onConfirm={handleDelete}
      />
    </div>
  );
};
