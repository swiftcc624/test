// @ts-nocheck
import { ColumnDef } from "@tanstack/react-table";

import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";
import { DataTableColumnHeader } from "@/components/widgets/data-table/DataTableColumnHeader";

// This type is used to define the shape of our data.
// You can use a Zod schema here if you want.

export const columns: ColumnDef[] = [
  {
    id: "active",

    cell: ({ row, table }) => {
      const { toggleActive } = table.options.meta;
      return (
        <Switch
          checked={row.original.status === "active"}
          onCheckedChange={(checked) => toggleActive(row, checked)}
          aria-label="Check row"
        />
      );
    },
    enableSorting: false,
    enableHiding: false,
  },

  {
    accessorKey: "name",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Name" />;
    },
    cell: ({ row }) => <span>{row.original.name}</span>,
  },
  {
    accessorKey: "email",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Email" />;
    },
    cell: ({ row }) => <span>{row.original.email}</span>,
  },
  {
    accessorKey: "role",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Role" />;
    },
    cell: ({ row }) => <span>{row.original.role}</span>,
  },

  {
    id: "actions",
    cell: ({ row, table }) => (
      <div className="flex gap-2">
        <Button
          variant="default"
          onClick={() => {
            dialogActions.openDialog(DIALOG_ID.EDIT_USER, {
              user: row.original,
            });
          }}
        >
          Edit
        </Button>
        <Button
          variant="destructive"
          onClick={() => {
            dialogActions.openDialog(DIALOG_ID.DELETE_CONFIRMATION, {
              user: row.original,
            });
          }}
        >
          Remove
        </Button>
      </div>
    ),
  },
];
