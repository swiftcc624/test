import { useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import { UserForm } from "./UserForm";
import { toast } from "sonner";

import { updateUser } from "@/api/users";
import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";

export function EditUserDialog({
  dialogId = DIALOG_ID.EDIT_USER,
}: {
  dialogId?: DIALOG_ID;
}) {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore((state) => state.dialogs[dialogId]);

  const { user } = dialogActions.getDialogData(dialogId);

  const handleEdit = async (data: any) => {
    try {
      await updateUser(user._id, data);

      queryClient.invalidateQueries({ queryKey: ["users"] });
      dialogActions.closeDialog(dialogId);
      toast.success("User updated");
    } catch (error) {
      console.error(error);
      toast.error("Error updating user");
    }
  };

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>Edit User</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          {user && (
            <UserForm
              onSubmit={handleEdit}
              initialValues={user}
              ref={formRef}
            />
          )}
        </div>
        <SheetFooter>
          <Button onClick={() => formRef?.current?.submit()}>Save</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
