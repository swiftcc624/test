import { useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import { UserForm } from "./UserForm";
import { toast } from "sonner";

import { createUser } from "@/api/users";
import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";

export function AddUserDialog({
  dialogId = DIALOG_ID.ADD_USER,
}: {
  dialogId?: DIALOG_ID;
}) {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore((state) => state.dialogs[dialogId]);

  const handleAdd = async (data: any) => {
    try {
      await createUser({ ...data, password: "123qweasd" });

      queryClient.invalidateQueries({ queryKey: ["users"] });
      dialogActions.closeDialog(dialogId);
      toast.success("User created");
    } catch (error) {
      console.error(error);
      toast.error("Error creating user");
    }
  };

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>New User</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          <UserForm onSubmit={handleAdd} initialValues={{}} ref={formRef} />
        </div>
        <SheetFooter>
          <Button onClick={() => formRef?.current?.submit()}>Save</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
