import { forwardRef, useImperativeHandle } from "react";
import { useForm } from "react-hook-form";

import * as z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import { Form } from "@/components/ui/form";
import { RadioGroupField } from "@/components/fields/RadioGroupField";
import { InputField } from "@/components/fields/InputField";
interface SyncFormProps {
  onSubmit: (data: any) => void;
  initialValues?: any;
}

export const SyncForm = forwardRef(({ onSubmit }: SyncFormProps, ref) => {
  const formSchema = z
    .object({
      mode: z.string(),
      startDate: z.string().optional(),
      startTime: z.string().optional(),
    })
    .superRefine((data, ctx) => {
      if (
        data.mode === "custom" &&
        (data.startDate === undefined || data.startTime === undefined)
      ) {
        if (data.startDate === undefined) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: "Required",
            path: ["startDate"],
          });
        }
        if (data.startTime === undefined) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: "Required",
            path: ["startTime"],
          });
        }
      }
    });

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      mode: "automatic",
    },
  });

  useImperativeHandle(ref, () => ({
    submit: form.handleSubmit(onSubmit),
  }));

  const mode = form.watch("mode");

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <RadioGroupField
            name="mode"
            label=""
            options={[
              {
                value: "automatic",
                label: "Automatic",
              },
              {
                value: "custom",
                label: "Custom",
              },
            ]}
            getOptionValue={(option: any) => option.value}
            getOptionLabel={(option: any) => option.label}
          />
        </div>
        <div className="flex gap-2">
          <InputField
            type="date"
            name="startDate"
            label="Date"
            disabled={mode !== "custom"}
          />
          <InputField
            type="time"
            name="startTime"
            label="Time"
            disabled={mode !== "custom"}
          />
        </div>
      </form>
    </Form>
  );
});
