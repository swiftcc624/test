import { useCallback } from "react";
import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";

export const useSync = (
  asyncTaskTypes: any[],
  onSuccess: () => void = () => {}
) => {
  const handleSync = useCallback(() => {
    dialogActions.openDialog(DIALOG_ID.SYNC2, {
      asyncTaskTypes,
      onSuccess,
      triggered: false,
    });
  }, []);

  return { handleSync };
};
