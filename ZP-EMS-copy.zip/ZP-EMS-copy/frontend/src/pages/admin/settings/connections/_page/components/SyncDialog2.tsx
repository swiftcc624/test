import { useEffect, useMemo, useRef } from "react";
import { toast } from "sonner";
import { CheckIcon, Loader2Icon, XIcon } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import moment from "moment-timezone";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import {
  useDialogStore,
  dialogActions,
  DIALOG_ID,
} from "@/zustand/useDialogStore";

import { SyncForm } from "./SyncForm";

import { getAsyncTasks, createAsyncTask } from "@/api/asyncTask";

const syncDescriptions: any = {
  sync_employee: "Sync Employees",
  sync_category: "Sync Categories",
  sync_currency: "Sync Currencies",
  sync_project: "Sync Projects",
  sync_task: "Sync Tasks",
  sync_item: "Sync Items",
  sync_vendor: "Sync Vendors",
  sync_itemvendor: "Sync ItemVendors",
  sync_customer: "Sync Customers",
};

export const SyncDialog2 = ({
  dialogId = DIALOG_ID.SYNC2,
}: {
  dialogId?: DIALOG_ID;
}) => {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore((state) => state.dialogs[dialogId]);

  const { asyncTaskTypes, onSuccess, triggered } =
    dialogActions.getDialogData(dialogId);

  const { data: asyncTasks } = useQuery({
    queryKey: ["asyncTasks", asyncTaskTypes],
    queryFn: async () => {
      const res = await getAsyncTasks({
        // status: "active",
        types: asyncTaskTypes,
        offset: 0,
        limit: asyncTaskTypes.length,
      });

      return res;
    },
    enabled: !!asyncTaskTypes && dialogActions.isDialogOpen(dialogId),
    refetchInterval: 2000,
  });

  const isRunning = useMemo(() => {
    if (asyncTasks) {
      const allDone = asyncTasks.every(
        (task: any) => task.status === "completed" || task.status === "failed"
      );
      return !allDone;
    }
    return false;
  }, [asyncTasks]);

  useEffect(() => {
    if (!isRunning) {
      onSuccess?.();
    }
  }, [isRunning]);

  const mutation = useMutation({ mutationFn: createAsyncTask });

  const handleSave = async (values: any) => {
    const { asyncTaskTypes } = dialogActions.getDialogData(dialogId) || {};

    if (!asyncTaskTypes || asyncTaskTypes.length === 0) {
      return;
    }

    try {
      console.log(values);
      const { mode, startDate, startTime } = values;

      let startDateTime;
      if (mode === "custom") {
        try {
          startDateTime = moment(`${startDate} ${startTime}`).toDate();
        } catch (e) {}
      }
      const resp = await mutation.mutateAsync({
        types: asyncTaskTypes,
        mode,
        startDateTime,
      });
      console.log(resp);

      queryClient.invalidateQueries({ queryKey: ["asyncTasks"] });

      dialogActions.setDialogData(dialogId, {
        ...dialogActions.getDialogData(dialogId),
        triggered: true,
      });
    } catch (error) {
      toast.error("Failed to sync");
    }
  };

  return (
    <Dialog
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <DialogContent className="flex flex-col gap-4 w-[600px] min-h-[300px]">
        <DialogHeader>
          <DialogTitle>Sync Data from Netsuite</DialogTitle>
        </DialogHeader>

        {!isRunning && !triggered ? (
          <div className="grow flex flex-col justify-between">
            <div className="grid gap-4 py-4">
              <SyncForm
                onSubmit={handleSave}
                ref={formRef}
                initialValues={dialogActions.getDialogData(dialogId)}
              />
            </div>
            <DialogFooter>
              <Button
                className="w-full"
                // @ts-ignore
                onClick={() => formRef?.current?.submit()}
                disabled={mutation.isPending}
              >
                {mutation.isPending && (
                  <Loader2Icon className="mr-2 h-4 w-4 animate-spin" />
                )}
                Run
              </Button>
            </DialogFooter>
          </div>
        ) : (
          <>
            <div className="grow flex flex-col gap-2">
              {asyncTasks &&
                asyncTasks
                  .sort(
                    (a: any, b: any) =>
                      new Date(a.createdAt).getTime() -
                      new Date(b.createdAt).getTime()
                  )
                  .map((task: any, index: number) => (
                    <div
                      key={index}
                      className="flex justify-between items-center gap-2"
                    >
                      <span>{syncDescriptions[task.type]}</span>
                      <span>
                        {task.status === "completed" && (
                          <CheckIcon className="h-6 w-6 text-primary" />
                        )}
                        {task.status === "failed" && (
                          <XIcon className="h-6 w-6 text-red-500" />
                        )}
                        {task.status === "waiting" && ""}
                        {task.status === "active" && (
                          <Loader2Icon className="h-6 w-6 animate-spin" />
                        )}
                      </span>
                    </div>
                  ))}
            </div>
            <DialogFooter>
              <Button
                className="w-full"
                variant="outline"
                onClick={() => dialogActions.closeDialog(dialogId)}
              >
                Close
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};
