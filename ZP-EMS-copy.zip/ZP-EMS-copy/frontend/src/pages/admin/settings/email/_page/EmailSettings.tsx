import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

import { HeaderPortal } from "@/pages/_page/HeaderPortal";

import {
  getEmailDomainIdentity,
  getSettings,
  verifyEmailDomainIdentity,
} from "@/api/settings";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import { EmailDomainForm } from "./components/EmailDomainForm";

export const EmailSettings = () => {
  const { data: settings, isLoading } = useQuery({
    queryKey: ["settings"],
    queryFn: async () => {
      return await getSettings();
    },
  });

  const { data: domainIdentityData, isLoading: isDomainIdentityLoading } =
    useQuery({
      queryKey: ["emailDomainIdentity"],
      queryFn: async () => {
        return await getEmailDomainIdentity();
      },
      refetchInterval: 5000,
    });

  const handleUpdate = async (data: any) => {
    try {
      await verifyEmailDomainIdentity(data);
      toast.success("Email domain updated successfully");
      //   queryClient.invalidateQueries({ queryKey: ["settings"] });
    } catch (error) {
      console.error(error);
      toast.error("Error updating email domain");
    }
  };

  return (
    <div>
      <HeaderPortal>
        <h1 className="text-xl font-bold">Email Settings</h1>
      </HeaderPortal>

      <div className="p-4">
        <div className="flex flex-col gap-4">
          {!isLoading && (
            <EmailDomainForm initialValues={settings} onSubmit={handleUpdate} />
          )}
          {!isDomainIdentityLoading && domainIdentityData?.emailDomain && (
            <div className="flex flex-col gap-2">
              <h2>
                Verification Status: {domainIdentityData?.verificationStatus}
              </h2>

              {domainIdentityData?.dkimTokens && (
                <>
                  <h2>
                    Please add the following DKIM records to your DNS settings
                    to complete the verification process.
                  </h2>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Type</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Value</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {domainIdentityData?.dkimTokens.map(
                        (dkimToken: string) => (
                          <TableRow key={dkimToken}>
                            <TableCell>CNAME</TableCell>
                            <TableCell>{`${dkimToken}._domainkey`}</TableCell>
                            <TableCell>
                              {`${dkimToken}.dkim.amazonses.com`}
                            </TableCell>
                          </TableRow>
                        )
                      )}
                      <TableRow>
                        <TableCell>TXT</TableCell>
                        <TableCell>_dmarc</TableCell>
                        <TableCell>"v=DMARC1; p=none;"</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
