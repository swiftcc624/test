import { forwardRef, useImperativeHandle } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

import { Form } from "@/components/ui/form";
import { InputField } from "@/components/fields/InputField";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

const formSchema = z.object({
  emailDomain: z.string().min(1),
});

interface EmailDomainFormProps {
  onSubmit?: (data: any) => void;
  initialValues?: any;
}

export const EmailDomainForm = forwardRef(
  ({ initialValues, onSubmit = (_: any) => {} }: EmailDomainFormProps, ref) => {
    const form = useForm({
      resolver: zodResolver(formSchema),
      defaultValues: {
        emailDomain: initialValues?.emailDomain ?? "",
      },
    });

    useImperativeHandle(ref, () => ({
      submit: form.handleSubmit(
        onSubmit as SubmitHandler<{ emailDomain: any }>
      ),
    }));

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="flex gap-2 items-center">
            <Label>Email Domain:</Label>
            <InputField name="emailDomain" className="w-[300px]" />
            <Button>Update</Button>
          </div>
        </form>
      </Form>
    );
  }
);
