import { useState } from "react";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { PaginationState, SortingState } from "@tanstack/react-table";

import { Button } from "@/components/ui/button";

import { columns } from "./components/columns";
import { AddCurrencyDialog } from "./components/AddCurrencyDialog";
import { EditCurrencyDialog } from "./components/EditCurrencyDialog";
import { HeaderPortal } from "@/pages/_page/HeaderPortal";
import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";
import { useSync } from "../../connections/_page/hooks/useSync";
import { DataTable } from "@/components/widgets/data-table/DataTable";
import { generateSortingParam } from "@/lib/utils";
import {
  deleteCurrency,
  getCurrencies,
  updateCurrency,
} from "@/api/currencies";
import { toast } from "sonner";
import { DeleteConfirmationDialog } from "@/pages/admin/clockify/track/_page/components/DeleteConfirmationDialog";

export const CurrencySettings = () => {
  const queryClient = useQueryClient();

  const [sorting, setSorting] = useState<SortingState>([]);
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });

  const { data } = useQuery({
    queryKey: ["currencies", sorting, pagination],
    queryFn: async () => {
      return await getCurrencies({
        sorting: generateSortingParam(sorting),
        limit: pagination.pageSize,
        offset: pagination.pageIndex * pagination.pageSize,
      });
    },
  });

  const { handleSync } = useSync(["sync_currency"], () => {
    queryClient.invalidateQueries({ queryKey: ["currencies"] });
  });

  const handleDelete = async (dialogData: any) => {
    try {
      await deleteCurrency(dialogData.id);

      queryClient.invalidateQueries({ queryKey: ["currencies"] });
      toast.success("Currency removed");
    } catch (error) {
      console.error(error);
      toast.error("Error removing currency");
    }
  };

  return (
    <div>
      <HeaderPortal>
        <h1 className="text-xl font-bold">Currencies</h1>
        <div className="flex gap-2">
          <Button onClick={handleSync}>Sync</Button>

          <Button
            className="ml-auto"
            onClick={() => dialogActions.openDialog(DIALOG_ID.ADD_CURRENCY)}
          >
            New Currency
          </Button>
        </div>
      </HeaderPortal>
      <div className="p-4">
        <DataTable
          columns={columns}
          data={data?.items || []}
          sorting={sorting}
          setSorting={setSorting}
          pagination={pagination}
          setPagination={setPagination}
          rowCount={data?.totalResults || 0}
          meta={{
            toggleActive: async (row: any, checked: boolean) => {
              try {
                await updateCurrency(row.original._id, {
                  status: checked ? "active" : "inactive",
                });

                queryClient.invalidateQueries({ queryKey: ["currencies"] });
                toast.success("Currency updated");
              } catch (error) {
                console.error(error);
                toast.error("Error updating currency");
              }
            },
          }}
        />
      </div>
      <AddCurrencyDialog />
      <EditCurrencyDialog />
      <DeleteConfirmationDialog
        title="Are you sure you want to delete this currency?"
        onConfirm={handleDelete}
      />
    </div>
  );
};
