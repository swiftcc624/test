import { useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import { CurrencyForm } from "./CurrencyForm";
import { toast } from "sonner";

import { createCurrency } from "@/api/currencies";
import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";

export function AddCurrencyDialog({
  dialogId = DIALOG_ID.ADD_CURRENCY,
}: {
  dialogId?: DIALOG_ID;
}) {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore((state) => state.dialogs[dialogId]);

  const handleAdd = async (data: any) => {
    try {
      await createCurrency({ ...data });

      queryClient.invalidateQueries({ queryKey: ["currencies"] });
      dialogActions.closeDialog(dialogId);
      toast.success("Currency created");
    } catch (error) {
      console.error(error);
      toast.error("Error creating currency");
    }
  };

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>New Currency</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          <CurrencyForm onSubmit={handleAdd} initialValues={{}} ref={formRef} />
        </div>
        <SheetFooter>
          <Button onClick={() => formRef?.current?.submit()}>Save</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
