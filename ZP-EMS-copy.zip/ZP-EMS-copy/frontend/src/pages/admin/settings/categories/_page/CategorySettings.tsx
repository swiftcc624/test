import { useQuery, useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";

import { columns } from "./components/columns";
import { AddCategoryDialog } from "./components/AddCategoryDialog";
import { EditCategoryDialog } from "./components/EditCategoryDialog";
import { HeaderPortal } from "@/pages/_page/HeaderPortal";
import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";
import { useSync } from "../../connections/_page/hooks/useSync";
import { DataTable } from "@/components/widgets/data-table/DataTable";
import { PaginationState, SortingState } from "@tanstack/react-table";
import { useState } from "react";
import {
  deleteCategory,
  getCategories,
  updateCategory,
} from "@/api/categories";
import { generateSortingParam } from "@/lib/utils";
import { DeleteConfirmationDialog } from "@/pages/admin/clockify/track/_page/components/DeleteConfirmationDialog";
import { toast } from "sonner";

export const CategorySettings = () => {
  const queryClient = useQueryClient();

  const [sorting, setSorting] = useState<SortingState>([]);
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });

  const { data } = useQuery({
    queryKey: ["categories", sorting, pagination],
    queryFn: async () => {
      return await getCategories({
        sorting: generateSortingParam(sorting),
        limit: pagination.pageSize,
        offset: pagination.pageIndex * pagination.pageSize,
      });
    },
  });

  const { handleSync } = useSync(["sync_category"], () => {
    queryClient.invalidateQueries({ queryKey: ["categories"] });
  });

  const handleDelete = async (dialogData: any) => {
    try {
      await deleteCategory(dialogData.id);

      queryClient.invalidateQueries({ queryKey: ["categories"] });
      toast.success("Category removed");
    } catch (error) {
      console.error(error);
      toast.error("Error removing category");
    }
  };

  return (
    <div>
      <HeaderPortal>
        <h1 className="text-xl font-bold">Categories</h1>
        <div className="flex gap-2">
          <Button onClick={handleSync}>Sync</Button>

          <Button
            className="ml-auto"
            onClick={() => {
              dialogActions.openDialog(DIALOG_ID.ADD_CATEGORY);
            }}
          >
            New Category
          </Button>
        </div>
      </HeaderPortal>
      <div className="p-4">
        <DataTable
          columns={columns}
          data={data?.items || []}
          sorting={sorting}
          setSorting={setSorting}
          pagination={pagination}
          setPagination={setPagination}
          rowCount={data?.totalResults || 0}
          meta={{
            toggleActive: async (row: any, checked: boolean) => {
              try {
                await updateCategory(row.original.id, {
                  status: checked ? "active" : "inactive",
                });

                queryClient.invalidateQueries({ queryKey: ["categories"] });
                toast.success("Category updated");
              } catch (error) {
                console.error(error);
                toast.error("Error updating category");
              }
            },
          }}
        />
      </div>
      <AddCategoryDialog />
      <EditCategoryDialog />
      <DeleteConfirmationDialog
        title="Are you sure you want to delete this category?"
        onConfirm={handleDelete}
      />
    </div>
  );
};
