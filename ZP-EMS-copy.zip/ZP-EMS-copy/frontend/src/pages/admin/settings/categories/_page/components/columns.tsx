// @ts-nocheck
import { ColumnDef } from "@tanstack/react-table";

import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { DataTableColumnHeader } from "@/components/widgets/data-table/DataTableColumnHeader";
import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";

// This type is used to define the shape of our data.
// You can use a Zod schema here if you want.

export const columns: ColumnDef[] = [
  {
    id: "active",
    cell: ({ row, table }) => {
      const { toggleActive } = table.options.meta;
      return (
        <Switch
          checked={row.original.status === "active"}
          onCheckedChange={(checked) => toggleActive(row, checked)}
          aria-label="Check row"
        />
      );
    },
    enableSorting: false,
    enableHiding: false,
  },

  {
    accessorKey: "name",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Name" />;
    },
    cell: ({ row }) => <span>{row.original.name}</span>,
  },
  {
    accessorKey: "glCode",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="GL Code" />;
    },
    cell: ({ row }) => <span>{row.original.glCode}</span>,
  },

  {
    id: "actions",
    cell: ({ row, table }) => (
      <div className="flex gap-2">
        <Button
          variant="default"
          onClick={() => {
            dialogActions.openDialog(DIALOG_ID.EDIT_CATEGORY, {
              category: row.original,
            });
          }}
        >
          Edit
        </Button>
        <Button
          variant="destructive"
          onClick={() => {
            dialogActions.openDialog(
              DIALOG_ID.DELETE_CONFIRMATION,
              row.original
            );
          }}
        >
          Remove
        </Button>
      </div>
    ),
  },
];
