import { useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import { CategoryForm } from "./CategoryForm";
import { toast } from "sonner";

import { updateCategory } from "@/api/categories";
import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";

export function EditCategoryDialog({
  dialogId = DIALOG_ID.EDIT_CATEGORY,
}: {
  dialogId?: DIALOG_ID;
}) {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore((state) => state.dialogs[dialogId]);

  const { category } = dialogActions.getDialogData(dialogId);

  const handleEdit = async (data: any) => {
    try {
      console.log(category);
      await updateCategory(category._id, data);

      queryClient.invalidateQueries({ queryKey: ["categories"] });
      dialogActions.closeDialog(dialogId);
      toast.success("Category updated");
    } catch (error) {
      console.error(error);
      toast.error("Error updating category");
    }
  };

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>Edit Category</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          {category && (
            <CategoryForm
              onSubmit={handleEdit}
              initialValues={category}
              ref={formRef}
            />
          )}
        </div>
        <SheetFooter>
          <Button onClick={() => formRef?.current?.submit()}>Save</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
