import { useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import { CategoryForm } from "./CategoryForm";
import { toast } from "sonner";

import { createCategory } from "@/api/categories";
import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";

export function AddCategoryDialog({
  dialogId = DIALOG_ID.ADD_CATEGORY,
}: {
  dialogId?: DIALOG_ID;
}) {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore((state) => state.dialogs[dialogId]);

  const handleAdd = async (data: any) => {
    try {
      await createCategory({ ...data });

      queryClient.invalidateQueries({ queryKey: ["categories"] });
      dialogActions.closeDialog(dialogId);
      toast.success("Category created");
    } catch (error) {
      console.error(error);
      toast.error("Error creating category");
    }
  };

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>New Category</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          <CategoryForm onSubmit={handleAdd} initialValues={{}} ref={formRef} />
        </div>
        <SheetFooter>
          <Button onClick={() => formRef?.current?.submit()}>Save</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
