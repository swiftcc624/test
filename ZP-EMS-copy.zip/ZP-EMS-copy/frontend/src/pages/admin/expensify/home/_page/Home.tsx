import { useQuery } from "@tanstack/react-query";

import { DataTable } from "./components/DataTable";
import { columns } from "./components/columns";
import { ExpenseGroupDialog } from "./components/ExpenseGroupDialog";

import { getActiveCategories } from "@/api/categories";
import { HeaderPortal } from "@/pages/_page/HeaderPortal";

export const Home = () => {
  const { data: categories } = useQuery({
    queryKey: ["categories", "active"],
    queryFn: async () => {
      const categories = await getActiveCategories();
      return categories;
    },
  });

  return (
    <div>
      <HeaderPortal>
        <h1 className="text-xl font-bold">Home</h1>
      </HeaderPortal>
      <div className="p-4 flex flex-col gap-4">
        <DataTable columns={columns} categories={categories?.items || []} />
      </div>
      <ExpenseGroupDialog />
    </div>
  );
};
