import moment from "moment-timezone";

import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";

export function ExpenseGroupDialog({
  dialogId = DIALOG_ID.EXPENSE_GROUP,
}: {
  dialogId?: DIALOG_ID;
}) {
  useDialogStore((state) => state.dialogs[dialogId]);

  const dialogData = dialogActions.getDialogData(dialogId);
  const expenses = dialogData?.expenses ?? [];

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>Category - {dialogData?.id}</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Merchant</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {expenses.map((expense: any, index: number) => (
                <TableRow key={index}>
                  <TableCell>{expense.merchantName}</TableCell>
                  <TableCell>
                    {moment(expense.date).format("MM-DD-YYYY")}
                  </TableCell>
                  <TableCell>
                    {expense.total} {expense.currency?.symbol}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <SheetFooter></SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
