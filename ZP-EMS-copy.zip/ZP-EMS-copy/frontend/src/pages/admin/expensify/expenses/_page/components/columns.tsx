// @ts-nocheck
import { ColumnDef } from "@tanstack/react-table";
import moment from "moment-timezone";

import { Button } from "@/components/ui/button";
import { DataTableColumnHeader } from "@/components/widgets/data-table/DataTableColumnHeader";

import PDFViewer from "@/components/widgets/PdfViewer";
import { useSettings } from "@/hooks/useSettings";
import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";

// This type is used to define the shape of our data.
// You can use a Zod schema here if you want.

export const columns: ColumnDef[] = [
  {
    accessorKey: "receiptFile",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Receipt Image" />;
    },
    cell: ({ row }) => (
      <span>
        {row.original.receiptFile?.url &&
        row.original.receiptFile.url.endsWith(".pdf") ? (
          <PDFViewer
            pdfUrl={row.original.receiptFile.url}
            // width={120}
            height={120}
          />
        ) : (
          <img
            className="h-[120px] w-auto"
            src={row.original.receiptFile.url}
          />
        )}
      </span>
    ),
  },
  {
    accessorKey: "merchantName",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Merchant" />;
    },
    cell: ({ row }) => <span>{row.original.merchantName}</span>,
  },
  {
    accessorKey: "date",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Date" />;
    },
    cell: ({ row }) => {
      const { settings } = useSettings();

      return (
        <span>{moment(row.original.date).format(settings?.dateFormat)}</span>
      );
    },
  },
  {
    accessorKey: "rate",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Total" />;
    },
    cell: ({ row }) => (
      <span>
        {row.original.rate} {row.original.currency?.symbol}
      </span>
    ),
  },
  {
    accessorKey: "category",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Category" />;
    },
    cell: ({ row }) => {
      return <span>{row.original.category?.name}</span>;
    },
  },
  {
    accessorKey: "transaction",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Expense Report" />;
    },
    cell: ({ row }) => (
      <span>
        {row.original.transaction?.tranId &&
          `EXP #${row.original.transaction?.tranId}`}
      </span>
    ),
  },
  {
    accessorKey: "status",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Status" />;
    },
    cell: ({ row }) => <span>{row.original.transaction?.status}</span>,
  },

  {
    id: "actions",
    cell: ({ row, table }) => (
      <div className="flex gap-2">
        <Button
          variant="default"
          onClick={() => {
            dialogActions.openDialog(DIALOG_ID.EDIT_EXPENSE, {
              expense: row.original,
            });
          }}
        >
          Edit
        </Button>
        <Button
          variant="destructive"
          onClick={() => {
            dialogActions.openDialog(
              DIALOG_ID.DELETE_CONFIRMATION,
              row.original
            );
          }}
        >
          Remove
        </Button>
      </div>
    ),
  },
];
