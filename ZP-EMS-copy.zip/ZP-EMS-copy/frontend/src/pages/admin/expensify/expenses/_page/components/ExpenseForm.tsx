import { forwardRef, useImperativeHandle, useState } from "react";
import { useRouteLoaderData } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import moment from "moment-timezone";
import { toast } from "sonner";

import { Form } from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import { InputField } from "@/components/fields/InputField";
import { DropzoneField } from "@/components/fields/DropzoneField";
import { Button } from "@/components/ui/button";
import { UserComboboxField } from "@/components/fields/advanced/UserComboboxField";
import { CurrencyComboboxField } from "@/components/fields/advanced/CurrencyComboboxField";
import { CategoryComboboxField } from "@/components/fields/advanced/CategoryComboboxField";

import { uploadFile2 } from "@/api/files";
import { scanReceipt } from "@/api/expenses";
import { Loader2Icon } from "lucide-react";
import { getSettings } from "@/api/settings";
import { getActiveCurrencies } from "@/api/currencies";
import { ExpenseReportComboboxField } from "@/components/fields/advanced/ExpenseReportComboboxField";

interface ExpenseFormProps {
  onSubmit?: (data: any) => void;
  initialValues?: any;
}

export const ExpenseForm = forwardRef(
  ({ initialValues, onSubmit = () => {} }: ExpenseFormProps, ref) => {
    const { authUser }: any = useRouteLoaderData("root");

    const { data: settings } = useQuery({
      queryKey: ["settings"],
      queryFn: getSettings,
    });

    const formSchema = z.object({
      receiptFile: z.any(),
      receiptFileId: z.any(),
      merchantName: z.string().min(1),
      date: z.string().min(1), // TODO: better date validation
      rate: z.coerce
        .number()
        .min(settings?.expenseSettings?.receiptRequiredAmount || 0.01)
        .max(settings?.expenseSettings?.maxExpenseAmount || 1000000),
      description: z.string().optional(),
      currencyId: z.string().min(1),
      categoryId: z.string().min(1),
      entityId: z.any(),
      transactionId: z
        .any()
        .transform((value) => (value === "" ? null : value)),
    });

    const form = useForm({
      resolver: zodResolver(formSchema),
      defaultValues: {
        receiptFile: initialValues?.receiptFile?.url ?? "",
        receiptFileId: initialValues?.receiptFileId ?? "",
        merchantName: initialValues?.merchantName ?? "",
        date: initialValues?.date
          ? new Date(initialValues?.date).toISOString().split("T")[0]
          : new Date().toISOString().split("T")[0],
        rate: initialValues?.rate ?? "",
        description: initialValues?.description ?? "",
        //
        categoryId: initialValues?.categoryId ?? "",
        currencyId: initialValues?.currencyId ?? "",
        transactionId: initialValues?.transactionId ?? null,
        entityId: initialValues?.entityId ?? authUser.id,
      },
    });

    useImperativeHandle(ref, () => ({
      submit: form.handleSubmit(onSubmit),
    }));

    const { data: currencies } = useQuery({
      queryKey: ["currencies", "active"],
      queryFn: async () => {
        return await getActiveCurrencies();
      },
    });

    const [isScanning, setIsScanning] = useState(false);

    const handleScan = async () => {
      setIsScanning(true);
      let receiptFile = form.getValues("receiptFile");

      //upload image
      if (typeof receiptFile !== "string") {
        try {
          const uploadedFile: any = await uploadFile2(receiptFile);
          form.setValue("receiptFile", uploadedFile?.url);
          form.setValue("receiptFileId", uploadedFile?.id);
        } catch (error) {
          console.log(error);
          setIsScanning(false);
          return;
        }
      }

      console.log("receiptFile", form.getValues("receiptFile"));
      const receiptFileId = form.getValues("receiptFileId");
      if (receiptFileId) {
        try {
          const { result, expenseData } = await scanReceipt({ receiptFileId });
          console.log("-----------Scan Receipt Result-----------");
          console.log(result);
          console.log(expenseData);

          const parsedExpenseData = JSON.parse(expenseData);
          console.log(parsedExpenseData);

          if (parsedExpenseData?.merchantName) {
            form.setValue("merchantName", parsedExpenseData?.merchantName);
          }
          if (parsedExpenseData?.date) {
            form.setValue(
              "date",
              moment(parsedExpenseData?.date).format("YYYY-MM-DD")
            );
          }
          if (parsedExpenseData?.total) {
            form.setValue("rate", parsedExpenseData?.total);
          }
          if (parsedExpenseData?.currency) {
            const foundCurrency = currencies?.items?.find(
              (currency: any) => currency.symbol === parsedExpenseData?.currency
            );

            if (foundCurrency) {
              form.setValue("currencyId", foundCurrency._id);
            }
          }
          if (parsedExpenseData?.categoryId) {
            form.setValue("categoryId", parsedExpenseData?.categoryId + "");
          }
        } catch (error) {
          console.log(error);
          toast.error("Error scanning receipt");
        }
      }
      setIsScanning(false);
    };

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="pb-4 flex flex-col space-y-2">
            <Label>Receipt Image</Label>
            <DropzoneField name="receiptFile" multiple={false} />
            <Button type="button" onClick={handleScan} disabled={isScanning}>
              {isScanning && (
                <Loader2Icon className="mr-2 h-4 w-4 animate-spin" />
              )}
              Scan
            </Button>
          </div>
          <div className="flex gap-2">
            <InputField
              name="merchantName"
              label="Merchant"
              className="w-[50%]"
            />
            <InputField
              name="date"
              label="Date"
              type="date"
              className="w-[50%]"
            />
          </div>
          <div className="flex gap-2">
            <div className="flex-1">
              <CategoryComboboxField name="categoryId" label="Category" />
            </div>
            <div className="flex-1 flex gap-2">
              <InputField name="rate" label="Total" className="flex-1" />
              <CurrencyComboboxField name="currencyId" label="Currency" />
            </div>
          </div>

          <div className="flex gap-2">
            <div className="flex-1">
              <UserComboboxField
                name="entityId"
                label="Attendee"
                userType="employee"
              />
            </div>

            <div className="flex-1">
              <ExpenseReportComboboxField
                name="transactionId"
                label="Expense Report"
                className="w-full"
              />
            </div>
          </div>

          <InputField name="description" label="Description" />
        </form>
      </Form>
    );
  }
);
