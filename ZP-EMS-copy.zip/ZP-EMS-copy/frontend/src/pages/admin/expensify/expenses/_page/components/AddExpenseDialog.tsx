import { useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2Icon } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import { ExpenseForm } from "./ExpenseForm";
import { toast } from "sonner";

import { createExpense } from "@/api/expenses";
import { uploadFile2 } from "@/api/files";
import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";
import { formActions, useFormStore, FormState } from "@/zustand/useFormStore";

export const ADD_EXPENSE_FORM_ID = "add_expense_form";

export function AddExpenseDialog({
  dialogId = DIALOG_ID.ADD_EXPENSE,
}: {
  dialogId?: DIALOG_ID;
}) {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore((state) => state.dialogs[dialogId]);
  useFormStore((state) => state.forms[ADD_EXPENSE_FORM_ID]);

  const formState = formActions.getFormState(ADD_EXPENSE_FORM_ID);

  useEffect(() => {
    formActions.setFormState(ADD_EXPENSE_FORM_ID, FormState.Ready);
  }, []);

  const handleAdd = async (data: any) => {
    formActions.setFormState(ADD_EXPENSE_FORM_ID, FormState.Submititng);

    try {
      const { receiptFile } = data;
      if (typeof receiptFile !== "string") {
        try {
          const uploadedFile: any = await uploadFile2(receiptFile);
          data = {
            ...data,
            receiptFileId: uploadedFile?.id,
          };
        } catch (error) {
          console.log(error);
          toast.error("Error uploading receipt image");
          // return;
        }
      }

      await createExpense({
        ...data,
        quantity: 1,
        amount: data.rate,
      });

      queryClient.invalidateQueries({ queryKey: ["expenses"] });
      dialogActions.closeDialog(dialogId);
      toast.success("Expense created");
    } catch (error) {
      console.error(error);
      toast.error("Error creating expense");
    }

    formActions.setFormState(ADD_EXPENSE_FORM_ID, FormState.Ready);
  };

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>New Expense</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          <ExpenseForm onSubmit={handleAdd} initialValues={{}} ref={formRef} />
        </div>
        <SheetFooter>
          <Button
            className="w-full"
            onClick={() => formRef?.current?.submit()}
            disabled={
              formState === FormState.Loading ||
              formState === FormState.Submititng
            }
          >
            {formState === FormState.Submititng && (
              <Loader2Icon className="mr-2 h-4 w-4 animate-spin" />
            )}
            Save
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
