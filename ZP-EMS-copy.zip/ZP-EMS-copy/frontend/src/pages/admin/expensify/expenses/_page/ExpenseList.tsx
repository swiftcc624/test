import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { SortingState, PaginationState } from "@tanstack/react-table";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";

import { columns } from "./components/columns";
import { DataTable } from "@/components/widgets/data-table/DataTable";

import { AddExpenseDialog } from "./components/AddExpenseDialog";
import { EditExpenseDialog } from "./components/EditExpenseDialog";

import { HeaderPortal } from "@/pages/_page/HeaderPortal";

import {
  deleteExpense,
  getExpenses,
  importExpensesFromCSV,
} from "@/api/expenses";
import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";
import { DeleteConfirmationDialog } from "@/pages/admin/clockify/track/_page/components/DeleteConfirmationDialog";
import { DataTableFilter } from "./components/DataTableFilter";
import { generateSortingParam } from "@/lib/utils";

export const ExpenseList = () => {
  const queryClient = useQueryClient();

  const [sorting, setSorting] = useState<SortingState>([]);

  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });

  const [filters, setFilters] = useState({
    dateFrom: "",
    dateTo: "",
    merchantName: "",
    categoryId: null,
    entityScope: "mine",
    status: ["open", "submitted", "approved", "rejected", "not_reported"],
  });

  const { data } = useQuery({
    queryKey: ["expenses", pagination, sorting, filters],
    queryFn: async () => {
      return await getExpenses({
        limit: pagination.pageSize,
        offset: pagination.pageIndex * pagination.pageSize,
        sorting: generateSortingParam(sorting),
        ...filters,
        status: filters.status.length > 0 ? filters.status.join(",") : "none",
      });
    },
  });

  const handleDelete = async (dialogData: any) => {
    try {
      await deleteExpense(dialogData?._id);
      queryClient.invalidateQueries({ queryKey: ["expenses"] });
      toast.success("Expense removed");
    } catch (error) {
      console.error(error);
      toast.error("Error removing expense");
    }
  };

  const handleExport = async () => {
    const expenses = await getExpenses({
      ...filters,
    });

    const csvString = [
      ["ExpenseID", "Merchant", "ExpenseDate", "Total", "Category", "Attendee"], // Replace with your headers
      ...expenses.items.map((expense: any) => [
        expense._id, // Replace with actual fields from your API data
        expense.merchantName,
        expense.date,
        expense.total,
        expense.category.name,
        expense.attendee,
      ]),
    ]
      .map((e) => e.join(","))
      .join("\n");

    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "expenses.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleImport = () => {
    // Create a file input element
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".csv";
    input.style.display = "none";
    document.body.appendChild(input);

    // Trigger the file input
    input.click();

    // Handle the file input change
    input.onchange = async (e) => {
      // @ts-ignore
      const file = e.target.files[0];
      if (!file) return;

      // Prepare the file to be sent in a FormData object
      const formData = new FormData();
      formData.append("csvfile", file);

      // Send the file to your API
      try {
        await importExpensesFromCSV(formData);

        // Optional: Update your UI or state to reflect the imported data
        queryClient.invalidateQueries({ queryKey: ["expenses"] });
        toast.success("Expenses imported");
      } catch (error) {
        toast.error("Error importing expenses");
        console.error("Error during import:", error);
      }
    };

    // Remove the file input element from the document
    document.body.removeChild(input);
  };

  return (
    <div>
      <HeaderPortal>
        <h1 className="text-xl font-bold">Expenses</h1>

        <div className="flex gap-2">
          <Button onClick={handleImport}>Import</Button>
          <Button onClick={handleExport}>Export</Button>
          <Button
            onClick={() => dialogActions.openDialog(DIALOG_ID.ADD_EXPENSE)}
          >
            New
          </Button>
        </div>
      </HeaderPortal>

      <div className="p-4">
        <DataTable
          columns={columns}
          data={data?.items || []}
          filter={<DataTableFilter filters={filters} setFilters={setFilters} />}
          sorting={sorting}
          setSorting={setSorting}
          pagination={pagination}
          setPagination={setPagination}
          rowCount={data?.totalResults || 0}
        />
      </div>
      <AddExpenseDialog />
      <EditExpenseDialog />
      <DeleteConfirmationDialog
        title="Are you sure you want to delete this expense?"
        onConfirm={handleDelete}
      />
    </div>
  );
};
