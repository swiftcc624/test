import { useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2Icon } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import { ExpenseForm } from "./ExpenseForm";
import { toast } from "sonner";

import { updateExpense } from "@/api/expenses";
import { uploadFile2 } from "@/api/files";
import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";
import { formActions, useFormStore, FormState } from "@/zustand/useFormStore";

export const EDIT_EXPENSE_FORM_ID = "edit_expense_form";

export function EditExpenseDialog({
  dialogId = DIALOG_ID.EDIT_EXPENSE,
}: {
  dialogId?: DIALOG_ID;
}) {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore((state) => state.dialogs[dialogId]);
  useFormStore((state) => state.forms[EDIT_EXPENSE_FORM_ID]);

  const formState = formActions.getFormState(EDIT_EXPENSE_FORM_ID);

  useEffect(() => {
    formActions.setFormState(EDIT_EXPENSE_FORM_ID, FormState.Ready);
  }, []);

  const { expense } = dialogActions.getDialogData(dialogId);

  const handleEdit = async (data: any) => {
    formActions.setFormState(EDIT_EXPENSE_FORM_ID, FormState.Submititng);

    try {
      const { receiptFile } = data;
      if (typeof receiptFile !== "string") {
        try {
          const uploadedFile: any = await uploadFile2(receiptFile);
          data = { ...data, receiptFileId: uploadedFile?.id };
        } catch (error) {
          console.log(error);
          toast.error("Error uploading receipt image");
          // return;
        }
      }

      await updateExpense(expense._id, data);

      queryClient.invalidateQueries({ queryKey: ["expenses"] });
      dialogActions.closeDialog(dialogId);
      toast.success("Expense updated");
    } catch (error) {
      console.error(error);
      toast.error("Error updating expense");
    }

    formActions.setFormState(EDIT_EXPENSE_FORM_ID, FormState.Ready);
  };

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>Edit Expense</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          {expense && (
            <ExpenseForm
              onSubmit={handleEdit}
              initialValues={expense}
              ref={formRef}
            />
          )}
        </div>
        <SheetFooter>
          <Button
            className="w-full"
            onClick={() => formRef?.current?.submit()}
            disabled={
              formState === FormState.Loading ||
              formState === FormState.Submititng
            }
          >
            {formState === FormState.Submititng && (
              <Loader2Icon className="mr-2 h-4 w-4 animate-spin" />
            )}
            Save
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
