// @ts-nocheck
import { ColumnDef } from "@tanstack/react-table";
import { Loader2Icon } from "lucide-react";
import moment from "moment-timezone";

import { Button } from "@/components/ui/button";
import { DataTableColumnHeader } from "@/components/widgets/data-table/DataTableColumnHeader";

import { useSettings } from "@/hooks/useSettings";
import { DIALOG_ID, dialogActions } from "@/zustand/useDialogStore";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { submitExpenseReport } from "@/api/expenseReports";
import { toast } from "sonner";

// This type is used to define the shape of our data.
// You can use a Zod schema here if you want.

export const columns: ColumnDef[] = [
  {
    accessorKey: "memo",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Report Name" />;
    },
    cell: ({ row }) => <span>{row.original.memo}</span>,
  },
  {
    accessorKey: "date",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Date" />;
    },
    cell: ({ row }) => {
      const { settings } = useSettings();

      return (
        <span>{moment(row.original.date).format(settings?.dateFormat)}</span>
      );
    },
  },
  {
    accessorKey: "tranId",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Tran Id" />;
    },
    cell: ({ row }) => <span>{`EXP #${row.original.tranId}`}</span>,
  },
  {
    accessorKey: "lines",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Expenses" />;
    },
    cell: ({ row }) => (
      <div>
        {row.original.lines &&
          row.original.lines.map((expense) => (
            <div key={expense._id} className="flex gap-2">
              <span>{expense.merchantName}</span>
            </div>
          ))}
      </div>
    ),
  },

  {
    accessorKey: "status",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Status" />;
    },
    cell: ({ row }) => <span>{row.original.status}</span>,
  },
  {
    accessorKey: "lastSubmittedAt",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Submitted At" />;
    },
    cell: ({ row }) => {
      const { settings } = useSettings();

      return (
        <span>
          {row.original.lastSubmittedAt &&
            moment(row.original.lastSubmittedAt).format(
              `${settings?.dateFormat} ${settings?.timeFormat}`
            )}
        </span>
      );
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const queryClient = useQueryClient();
      const submitMutation = useMutation({ mutationFn: submitExpenseReport });

      const handleSubmit = async (expenseReport) => {
        try {
          const data = await submitMutation.mutateAsync(expenseReport._id);
          console.log(data);

          queryClient.invalidateQueries({ queryKey: ["expenseReports"] });
          toast.success("Expense Report submitted");
        } catch (error) {
          console.error(error.response.data);
          const resp = error.response.data;

          let errorDetail = "";
          try {
            errorDetail =
              error.message + " - " + resp.error["o:errorDetails"][0].detail;
          } catch (error) {
            errorDetail = error.message;
          }

          toast.error("Error sending expense report", {
            description: errorDetail,
          });
        }
      };
      return (
        <div className="flex gap-2">
          <Button
            onClick={() => handleSubmit(row.original)}
            disabled={submitMutation.isPending}
          >
            {submitMutation.isPending && (
              <Loader2Icon className="mr-2 h-4 w-4 animate-spin" />
            )}
            Submit
          </Button>
          <Button
            variant="default"
            onClick={() => {
              dialogActions.openDialog(DIALOG_ID.EDIT_EXPENSE_REPORT, {
                expenseReport: row.original,
              });
            }}
          >
            Edit
          </Button>
          <Button
            variant="destructive"
            onClick={() => {
              dialogActions.openDialog(DIALOG_ID.DELETE_CONFIRMATION, {
                expenseReport: row.original,
              });
            }}
          >
            Remove
          </Button>
        </div>
      );
    },
  },
];
