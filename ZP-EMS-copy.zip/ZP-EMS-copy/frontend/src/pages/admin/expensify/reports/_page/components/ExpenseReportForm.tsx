import { forwardRef, useImperativeHandle } from "react";
import { useRouteLoaderData } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

import { Form } from "@/components/ui/form";
import { InputField } from "@/components/fields/InputField";
import { UserComboboxField } from "@/components/fields/advanced/UserComboboxField";
import { CurrencyComboboxField } from "@/components/fields/advanced/CurrencyComboboxField";

const formSchema = z.object({
  memo: z.string().min(1),
  date: z.string().min(1), // TODO: better date validation
  entityId: z.string().min(1),
  currencyId: z.string().min(1),
});

interface ExpenseReportFormProps {
  onSubmit?: (data: any) => void;
  initialValues?: any;
}

export const ExpenseReportForm = forwardRef(
  ({ initialValues, onSubmit = () => {} }: ExpenseReportFormProps, ref) => {
    const { authUser }: any = useRouteLoaderData("root");

    const form = useForm({
      resolver: zodResolver(formSchema),
      defaultValues: {
        memo: initialValues?.memo ?? "",

        date: initialValues?.date
          ? new Date(initialValues?.date).toISOString().split("T")[0]
          : new Date().toISOString().split("T")[0],

        entityId: initialValues?.entityId ?? authUser.id,
        currencyId: initialValues?.currencyId ?? "",
      },
    });

    useImperativeHandle(ref, () => ({
      submit: form.handleSubmit(onSubmit),
    }));

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <InputField name="memo" label="Report Name" />
          <InputField name="date" label="Date" type="date" />
          <CurrencyComboboxField
            name="currencyId"
            label="Currency"
            className="w-full"
          />
          <UserComboboxField
            name="entityId"
            label="Attendee"
            userType="employee"
            className="w-full"
          />
        </form>
      </Form>
    );
  }
);
