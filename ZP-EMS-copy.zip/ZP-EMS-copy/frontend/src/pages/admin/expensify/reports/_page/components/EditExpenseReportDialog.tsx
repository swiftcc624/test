import { useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import moment from "moment-timezone";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import { ExpenseReportForm } from "./ExpenseReportForm";
import { toast } from "sonner";

import { updateExpenseReport } from "@/api/expenseReports";
import { formatPrice } from "@/lib/utils";
import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";

export function EditExpenseReportDialog({
  dialogId = DIALOG_ID.EDIT_EXPENSE_REPORT,
}: {
  dialogId?: DIALOG_ID;
}) {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore((state) => state.dialogs[dialogId]);

  const { expenseReport } = dialogActions.getDialogData(dialogId);

  const handleEdit = async (data: any) => {
    try {
      await updateExpenseReport(expenseReport._id, data);

      queryClient.invalidateQueries({ queryKey: ["expenseReports"] });
      dialogActions.closeDialog(dialogId);
      toast.success("ExpenseReport updated");
    } catch (error) {
      console.error(error);
      toast.error("Error updating expenseReport");
    }
  };

  const total = expenseReport?.lines?.reduce(
    (acc: any, expense: any) => acc + expense.amount,
    0
  );

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>Edit ExpenseReport</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          {expenseReport && (
            <ExpenseReportForm
              onSubmit={handleEdit}
              initialValues={expenseReport}
              ref={formRef}
            />
          )}
        </div>
        <SheetFooter>
          <Button onClick={() => formRef?.current?.submit()}>Save</Button>
        </SheetFooter>

        <div className="mt-10">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Merchant Name</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Category</TableHead>
                <TableHead className="text-right">Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {expenseReport?.lines?.map((expense: any) => {
                return (
                  <TableRow key={expense._id}>
                    <TableCell className="font-medium">
                      {expense.merchantName}
                    </TableCell>
                    <TableCell>
                      {moment(expense.date).format("MM-DD-YYYY")}
                    </TableCell>
                    <TableCell>{expense.category?.name}</TableCell>
                    <TableCell className="text-right">
                      {formatPrice(expense.amount)}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
            <TableFooter>
              <TableRow>
                <TableCell colSpan={3}>Total</TableCell>
                <TableCell className="text-right">
                  {formatPrice(total)}
                </TableCell>
              </TableRow>
            </TableFooter>
          </Table>
        </div>
      </SheetContent>
    </Sheet>
  );
}
