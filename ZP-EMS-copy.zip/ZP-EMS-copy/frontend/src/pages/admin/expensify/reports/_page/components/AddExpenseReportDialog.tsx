import { useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import { ExpenseReportForm } from "./ExpenseReportForm";
import { toast } from "sonner";

import { createExpenseReport } from "@/api/expenseReports";
import {
  DIALOG_ID,
  dialogActions,
  useDialogStore,
} from "@/zustand/useDialogStore";

export function AddExpenseReportDialog({
  dialogId = DIALOG_ID.ADD_EXPENSE_REPORT,
}: {
  dialogId?: DIALOG_ID;
}) {
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  useDialogStore((state) => state.dialogs[dialogId]);

  const handleAdd = async (data: any) => {
    try {
      await createExpenseReport(data);

      queryClient.invalidateQueries({ queryKey: ["expenseReports"] });
      dialogActions.closeDialog(dialogId);
      toast.success("Expense Report created");
    } catch (error) {
      console.error(error);
      toast.error("Error creating expense report");
    }
  };

  return (
    <Sheet
      open={dialogActions.isDialogOpen(dialogId)}
      onOpenChange={(open) => {
        if (!open) dialogActions.closeDialog(dialogId);
      }}
    >
      <SheetContent className="w-[800px] !max-w-[800px]">
        <SheetHeader>
          <SheetTitle>New ExpenseReport</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          <ExpenseReportForm
            onSubmit={handleAdd}
            initialValues={{}}
            ref={formRef}
          />
        </div>
        <SheetFooter>
          <Button onClick={() => formRef?.current?.submit()}>Save</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
