import { FC, useEffect } from "react";

import { InputField } from "@/components/fields/InputField";
import { Button } from "@/components/ui/button";
import { XIcon } from "lucide-react";

import { TableCell, TableRow } from "@/components/ui/table";
import { ItemComboboxField } from "@/components/fields/advanced/ItemComboboxField";
import { ComboboxField } from "@/components/fields/ComboboxField";
import { useQuery } from "@tanstack/react-query";
import { getItemVendors } from "@/api/itemVendors";
import { useFormContext } from "react-hook-form";

export const PurchaseRequisitionLine: FC<{
  index: number;
  removeLine: (index: number) => void;
}> = ({ index, removeLine }) => {
  const form = useFormContext();
  const itemId = form.watch(`lines.${index}.itemId`);
  const vendorId = form.watch(`lines.${index}.vendorId`);
  const quantity = form.watch(`lines.${index}.quantity`);
  const rate = form.watch(`lines.${index}.rate`);

  const { data: itemVendors } = useQuery({
    queryKey: ["itemVendors", itemId],
    queryFn: async () => {
      return await getItemVendors({ itemId, limit: -1 });
    },
  });

  useEffect(() => {
    if (itemId && itemVendors) {
      const preferred = itemVendors.items.find((item: any) => item.isPreferred);
      if (preferred) {
        form.setValue(`lines.${index}.vendorId`, preferred.vendor.id);
      }
    }
  }, [itemId, itemVendors]);

  useEffect(() => {
    if (itemId && vendorId && itemVendors) {
      const itemVendor = itemVendors.items.find(
        (item: any) => item.vendor.id === vendorId
      );
      if (itemVendor) {
        form.setValue(`lines.${index}.rate`, itemVendor.vendorPrice);
      }
    }
  }, [itemId, vendorId, itemVendors]);

  useEffect(() => {
    if (quantity && rate && !isNaN(quantity) && !isNaN(rate)) {
      form.setValue(`lines.${index}.amount`, quantity * rate);
    }
  }, [quantity, rate]);

  return (
    <TableRow>
      <TableCell className="p-2">
        <ItemComboboxField
          name={`lines.${index}.itemId`}
          onSelect={(option: any) => {
            if (option.description) {
              form.setValue(`lines.${index}.description`, option.description);
            }
          }}
          showErrorMessage={false}
        />
      </TableCell>
      <TableCell className="p-2">
        <ComboboxField
          name={`lines.${index}.vendorId`}
          options={itemVendors?.items || []}
          getOptionLabel={(option: any) => option.vendor.name}
          getOptionValue={(option: any) => option.vendor.id}
          label=""
          className=""
          showErrorMessage={false}
        />
      </TableCell>
      <TableCell className="p-2">
        <InputField
          name={`lines.${index}.description`}
          showErrorMessage={false}
        />
      </TableCell>
      <TableCell className="p-2">
        <InputField name={`lines.${index}.quantity`} showErrorMessage={false} />
      </TableCell>
      <TableCell className="p-2">
        <InputField name={`lines.${index}.rate`} showErrorMessage={false} />
      </TableCell>
      <TableCell className="p-2">
        <InputField name={`lines.${index}.amount`} showErrorMessage={false} />
      </TableCell>
      <TableCell className="p-2">
        <div className="flex justify-between items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="right-2 top-2 p-0 w-6 h-6 rounded-full"
            onClick={() => {
              removeLine(index);
            }}
          >
            <XIcon className="w-4 h-4" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
};
