import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PaginationState, SortingState } from "@tanstack/react-table";

import { HeaderPortal } from "@/pages/_page/HeaderPortal";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/widgets/data-table/DataTable";

import { getTransactions } from "@/api/transactions";
import { columns } from "./components/columns";
import { useNavigate } from "react-router-dom";
import { generateSortingParam } from "@/lib/utils";

export const PurchaseRequisitionList = () => {
  const navigate = useNavigate();
  const [sorting, setSorting] = useState<SortingState>([]);
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });

  const [filters, _] = useState({});

  const { data } = useQuery({
    queryKey: ["purchaseRequisitions", filters, sorting, pagination],
    queryFn: async () => {
      const res = await getTransactions({
        ...filters,
        sorting: generateSortingParam(sorting),
        limit: pagination.pageSize,
        offset: pagination.pageIndex * pagination.pageSize,
      });

      return res;
    },
  });

  return (
    <div>
      <HeaderPortal>
        <h1 className="text-xl font-bold">Purchase Requisitions</h1>

        <div className="flex gap-2">
          <Button
            onClick={() => {
              navigate("/admin/sap/purchase-requisitions/add");
            }}
          >
            New
          </Button>
        </div>
      </HeaderPortal>
      <div className="p-4 flex flex-col gap-4">
        <DataTable
          columns={columns}
          data={data?.items || []}
          //   filter={<DataTableFilter filters={filters} setFilters={setFilters} />}
          sorting={sorting}
          setSorting={setSorting}
          pagination={pagination}
          setPagination={setPagination}
          rowCount={data?.totalResults || 0}
          columnVisibility={{
            id: false,
          }}
        />
      </div>
    </div>
  );
};
