import { useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Loader2Icon } from "lucide-react";

import { Button } from "@/components/ui/button";

import { PurchaseRequisitionForm } from "./components/PurchaseRequisitionForm";
import { createTransaction } from "@/api/transactions";
import { HeaderPortal } from "@/pages/_page/HeaderPortal";

export const PurchaseRequisitionAdd = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);

  const mutation = useMutation({ mutationFn: createTransaction });

  const handleSave = async (values: any) => {
    try {
      await mutation.mutateAsync({ ...values, type: "PurchaseRequisition" });

      toast.success("Purchase requisition added successfully!");
      queryClient.invalidateQueries({ queryKey: ["purchaseRequisitions"] });
      navigate("/admin/sap/purchase-requisitions");
    } catch (error) {
      console.log(error);
      toast.error("Failed to add purchase requisition");
    }
  };

  return (
    <>
      <HeaderPortal>
        <h1 className="text-xl font-bold">Add Purchase Requisition</h1>
        <div>
          <Button
            className="w-full"
            onClick={() => formRef?.current?.submit()}
            disabled={mutation.isPending}
          >
            {mutation.isPending && (
              <Loader2Icon className="mr-2 h-4 w-4 animate-spin" />
            )}
            Save
          </Button>
        </div>
      </HeaderPortal>

      <div className="p-4">
        <PurchaseRequisitionForm onSubmit={handleSave} ref={formRef} />
      </div>
    </>
  );
};
