// @ts-nocheck
import moment from "moment-timezone";
import { useNavigate } from "react-router-dom";
import { ColumnDef } from "@tanstack/react-table";

import { Button } from "@/components/ui/button";
import { DataTableColumnHeader } from "@/components/widgets/data-table/DataTableColumnHeader";
import { useSettings } from "@/hooks/useSettings";

export const columns: ColumnDef[] = [
  {
    accessorKey: "id",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Id" />;
    },
    cell: ({ row }) => {
      return <span>{row.original._id}</span>;
    },
  },

  {
    accessorKey: "date",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Date" />;
    },
    cell: ({ row }) => {
      const { settings } = useSettings();

      return (
        <span>{moment(row.original.date).format(settings?.dateFormat)}</span>
      );
    },
  },
  {
    accessorKey: "receiveBy",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Receive By" />;
    },
    cell: ({ row }) => {
      const { settings } = useSettings();

      return (
        <span>
          {moment(row.original.receiveBy).format(settings?.dateFormat)}
        </span>
      );
    },
  },
  {
    accessorKey: "memo",
    header: ({ column }) => {
      return <DataTableColumnHeader column={column} title="Memo" />;
    },
    cell: ({ row }) => {
      return <span>{row.original.memo}</span>;
    },
  },

  {
    id: "actions",
    cell: ({ row, table }) => {
      const navigate = useNavigate();
      return (
        <div className="flex gap-2">
          <Button
            variant="default"
            onClick={() =>
              navigate(
                `/admin/sap/purchase-requisitions/${row.original._id}/edit`
              )
            }
          >
            Edit
          </Button>
        </div>
      );
    },
  },
];
