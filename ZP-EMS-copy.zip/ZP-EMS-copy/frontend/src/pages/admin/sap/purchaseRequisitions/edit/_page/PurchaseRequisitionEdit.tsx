import { useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { Loader2Icon } from "lucide-react";

import { Button } from "@/components/ui/button";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { getTransaction, updateTransaction } from "@/api/transactions";
import { HeaderPortal } from "@/pages/_page/HeaderPortal";
import { PurchaseRequisitionForm } from "../../add/_page/components/PurchaseRequisitionForm";

export const PurchaseRequisitionEdit = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const formRef = useRef<any>(null);
  const mutation = useMutation({
    mutationFn: ({ id, ...data }: any) => updateTransaction(id, data),
  });

  const { data, isLoading } = useQuery({
    queryKey: ["purchaseRequisitions", id],
    queryFn: () => {
      if (!id) return null;
      return getTransaction(id);
    },
    enabled: !!id,
  });

  const handleSave = async (values: any) => {
    if (!id) return;

    try {
      await mutation.mutateAsync({
        id,
        ...values,
        type: "PurchaseRequisition",
      });

      toast.success("Purchase requisition updated successfully!");
      queryClient.invalidateQueries({ queryKey: ["purchaseRequisitions"] });
      navigate("/admin/sap/purchase-requisitions");
    } catch (error) {
      console.log(error);
      toast.error("Failed to update purchase requisition");
    }
  };

  return (
    <>
      <HeaderPortal>
        <h1 className="text-xl font-bold">Edit Purchase Requisition</h1>
        <div>
          <Button
            className="w-full"
            onClick={() => formRef?.current?.submit()}
            disabled={mutation.isPending}
          >
            {mutation.isPending && (
              <Loader2Icon className="mr-2 h-4 w-4 animate-spin" />
            )}
            Save
          </Button>
        </div>
      </HeaderPortal>

      <div className="p-4">
        {!isLoading && (
          <PurchaseRequisitionForm
            onSubmit={handleSave}
            ref={formRef}
            initialValues={data}
          />
        )}
      </div>
    </>
  );
};
