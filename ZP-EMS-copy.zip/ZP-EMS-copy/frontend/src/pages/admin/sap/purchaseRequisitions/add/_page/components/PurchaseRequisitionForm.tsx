import { forwardRef, useImperativeHandle } from "react";
import { useFieldArray, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

import { Form } from "@/components/ui/form";
import { InputField } from "@/components/fields/InputField";
import { Button } from "@/components/ui/button";

import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DatePickerField } from "@/components/fields/DatePickerField";
import { PurchaseRequisitionLine } from "./PurchaseRequisitionLine";
import { CurrencyComboboxField } from "@/components/fields/advanced/CurrencyComboboxField";

interface PurchaseRequisitionFormProps {
  onSubmit: (data: any) => void;
  initialValues?: any;
}

const formSchema = z.object({
  date: z.any(),
  receiveBy: z.any(),
  memo: z.string().min(1),
  currencyId: z.string().min(1),
  lines: z.array(
    z.object({
      id: z.any(),
      itemId: z.string().min(1),
      vendorId: z.string().min(1),
      description: z.string().min(1),
      quantity: z.coerce.number().int().nonnegative(),
      rate: z.coerce.number(),
      amount: z.coerce.number(),
    })
  ),
});

export const PurchaseRequisitionForm = forwardRef(
  ({ initialValues, onSubmit }: PurchaseRequisitionFormProps, ref) => {
    const form = useForm({
      resolver: zodResolver(formSchema),
      defaultValues: {
        date: initialValues?.date || "",
        receiveBy: initialValues?.receiveBy || "",
        memo: initialValues?.memo || "",
        currencyId: initialValues?.currencyId || "",
        lines: initialValues?.lines || [],
      },
    });

    useImperativeHandle(ref, () => ({
      submit: form.handleSubmit(onSubmit),
    }));

    const {
      fields: lineFields,
      append: addLine,
      remove: removeLine,
    } = useFieldArray({
      control: form.control,
      name: "lines",
    });

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="flex gap-2">
            <DatePickerField
              name="date"
              label="Date"
              className="w-full"
              placeholder="Pick a date"
            />
          </div>
          <div className="flex gap-2">
            <DatePickerField
              name="receiveBy"
              label="Receive By"
              className="w-full"
              placeholder="Pick a date"
            />
          </div>
          <div className="flex gap-2">
            <InputField name="memo" label="Memo" className="w-full" />
          </div>
          <div className="flex gap-2">
            <CurrencyComboboxField
              name="currencyId"
              label="Currency"
              className="w-full"
            />
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="p-2">Item</TableHead>
                <TableHead className="p-2">Vendor</TableHead>
                <TableHead className="p-2">Description</TableHead>
                <TableHead className="p-2">Quantity</TableHead>
                <TableHead className="p-2">Rate</TableHead>
                <TableHead className="p-2">Amount</TableHead>
                <TableHead className="p-2">*</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {lineFields.map((line, index) => (
                <PurchaseRequisitionLine
                  key={line.id}
                  index={index}
                  removeLine={removeLine}
                />
              ))}
            </TableBody>
            <TableFooter>
              <TableRow>
                <TableCell colSpan={4} className="">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() =>
                      addLine({
                        description: "",
                        quantity: "",
                        rate: "",
                        amount: "",
                      })
                    }
                  >
                    Add Line
                  </Button>
                </TableCell>
              </TableRow>
            </TableFooter>
          </Table>
        </form>
      </Form>
    );
  }
);
