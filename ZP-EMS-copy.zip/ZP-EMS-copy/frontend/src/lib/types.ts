export type Category = {
  id: string;
  name: string;
  glCode: string;
  status: "active" | "inactive";
};

export type Expense = {
  receiptFile: string;
  merchantName: string;
  date: Date;
  total: number;
  currency: string;
  category: string;
  description: string;

  // TODO: update to reference field?
  expenseReportId: string;
  attendee: string;
  userId: string;
};

export type ExpenseGroup = {
  total: number;
  count: number;
  average: number;
  expenses: Expense[];
};
