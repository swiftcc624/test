import {
  createBrowserRouter,
  RouterProvider,
  redirect,
  Navigate,
  Outlet,
} from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/sonner";

import "./App.css";

import { Root } from "@/pages/_page/Root";

import { Root as AdminRoot } from "@/pages/admin/_page/Root";
import { Login } from "@/pages/auth/login/_page/Login";
import { Register } from "@/pages/auth/register/_page/Register";
import { Invitation } from "@/pages/auth/invitation/_page/Invitation";

import { Home } from "@/pages/admin/expensify/home/_page/Home";
import { ExpenseList } from "@/pages/admin/expensify/expenses/_page/ExpenseList";
import { ExpenseReportList } from "@/pages/admin/expensify/reports/_page/ExpenseReportList";

import { Track as TimeTrack } from "@/pages/admin/clockify/track/_page/Track";
import { TimeEntryList } from "@/pages/admin/clockify/time-entries/_page/TimeEntryList";
import { WeeklyTimesheetList } from "@/pages/admin/clockify/weekly-timesheets/_page/WeeklyTimesheetList";
import { Reports as TimeReports } from "@/pages/admin/clockify/reports/_page/Reports";

import { Profile } from "@/pages/admin/profile/_page/Profile";

import { requireAuth, requireAnon, checkAuthUser } from "@/utils/auth";

import { GeneralSettings } from "./pages/admin/settings/general/_page/GeneralSettings";
import { EmailSettings } from "./pages/admin/settings/email/_page/EmailSettings";
import { ConnectionSettings } from "./pages/admin/settings/connections/_page/ConnectionSettings";
import { CategorySettings } from "./pages/admin/settings/categories/_page/CategorySettings";
import { ExpenseSettings } from "./pages/admin/settings/expenses/_page/ExpenseSettings";
import { ReportSettings } from "./pages/admin/settings/reports/_page/ReportSettings";
import { UserList } from "./pages/admin/settings/users/_page/UserList";
import { ItemSettings } from "./pages/admin/settings/items/ItemSettings";

import { CustomerSettings as ClockifyCustomerSettings } from "./pages/admin/settings/clockify/customers/_page/CustomerSettings";
import { ProjectSettings as ClockifyProjectSettings } from "./pages/admin/settings/clockify/projects/_page/ProjectSettings";
import { TaskSettings as ClockifyTaskSettings } from "./pages/admin/settings/clockify/tasks/_page/TaskSettings";

import { VendorList } from "./pages/admin/sap/vendors/_page/VendorList";
import { VendorView } from "./pages/admin/sap/vendors/view/_page/VendorView";
import { PurchaseRequisitionList } from "./pages/admin/sap/purchaseRequisitions/_page/PurchaseRequisitionList";
import { PurchaseRequisitionAdd } from "./pages/admin/sap/purchaseRequisitions/add/_page/PurchaseRequisitionAdd";
import { PurchaseRequisitionEdit } from "./pages/admin/sap/purchaseRequisitions/edit/_page/PurchaseRequisitionEdit";

//vendor-portal
import { Root as VendorPortalRoot } from "./pages/vendor-portal/_page/Root";
import { PaymentDetails } from "./pages/vendor-portal/payment-details/_page/PaymentDetails";

import AdminRouteGuard from "./pages/_page/AdminRouteGuard";
import { CurrencySettings } from "./pages/admin/settings/currencies/_page/CurrencySettings";
import { SyncDialog2 } from "./pages/admin/settings/connections/_page/components/SyncDialog2";

const router = createBrowserRouter([
  {
    id: "root",
    path: "/",
    element: <Root />,
    loader: async () => {
      const authUser = await checkAuthUser();

      await requireAuth();

      if (!authUser) {
        throw redirect("/auth/login");
      }

      return { authUser };
    },
    children: [
      {
        index: true,
        element: <Navigate to="expensify" />,
      },

      {
        path: "admin",
        element: <AdminRoot />,
        children: [
          { index: true, element: <Navigate to="expensify" /> },
          {
            path: "expensify",
            element: <Outlet />,
            children: [
              {
                index: true,
                element: <Home />,
              },
              {
                path: "expenses",
                element: <ExpenseList />,
              },
              {
                path: "reports",
                element: <ExpenseReportList />,
              },
            ],
          },
          {
            path: "clockify",
            element: <Outlet />,
            children: [
              {
                path: "track",
                element: <TimeTrack />,
              },
              {
                path: "time-entries",
                element: <TimeEntryList />,
              },
              {
                path: "weekly-timesheets",
                element: <WeeklyTimesheetList />,
              },
              {
                path: "reports",
                element: <TimeReports />,
              },
            ],
          },
          {
            path: "sap",
            element: <Outlet />,
            children: [
              {
                path: "vendors",
                element: <VendorList />,
              },
              {
                path: "vendors/:id",
                element: <VendorView />,
              },
              {
                path: "purchase-requisitions",
                element: <PurchaseRequisitionList />,
              },
              {
                path: "purchase-requisitions/add",
                element: <PurchaseRequisitionAdd />,
              },
              {
                path: "purchase-requisitions/:id/edit",
                element: <PurchaseRequisitionEdit />,
              },
            ],
          },
          {
            path: "settings",
            element: (
              <AdminRouteGuard>
                <>
                  <Outlet />
                  <SyncDialog2 />
                </>
              </AdminRouteGuard>
            ),
            children: [
              {
                index: true,
                element: <GeneralSettings />,
              },
              {
                path: "email",
                element: <EmailSettings />,
              },
              {
                path: "categories",
                element: <CategorySettings />,
              },
              {
                path: "currencies",
                element: <CurrencySettings />,
              },
              {
                path: "users",
                element: <UserList />,
              },
              {
                path: "items",
                element: <ItemSettings />,
              },

              {
                path: "expenses",
                element: <ExpenseSettings />,
              },
              {
                path: "reports",
                element: <ReportSettings />,
              },
              {
                path: "connections",
                element: <ConnectionSettings />,
              },
              {
                path: "clockify",
                element: <Outlet />,
                children: [
                  {
                    index: true,
                    element: <ClockifyCustomerSettings />,
                  },
                  {
                    path: "customers",
                    element: <ClockifyCustomerSettings />,
                  },
                  {
                    path: "projects",
                    element: <ClockifyProjectSettings />,
                  },
                  {
                    path: "tasks",
                    element: <ClockifyTaskSettings />,
                  },
                ],
              },
            ],
          },

          {
            path: "profile",
            element: <Profile />,
          },
        ],
      },

      {
        path: "vendor-portal",
        element: <VendorPortalRoot />,
        children: [
          {
            index: true,
            element: <Navigate to="payment-details" />,
          },
          {
            path: "payment-details",
            element: <PaymentDetails />,
          },

          {
            path: "profile",
            element: <Profile />,
          },
        ],
      },

      {
        path: "*",
        element: <div>404</div>,
      },
    ],
  },

  {
    path: "/auth/login",
    element: <Login />,
    loader: async () => {
      await requireAnon();
      return null;
    },
  },
  {
    path: "/auth/register",
    element: <Register />,
    loader: async () => {
      await requireAnon();
      return null;
    },
  },

  {
    path: "/invitations/:invitationId",
    element: <Invitation />,
    loader: async () => {
      await requireAnon();
      return null;
    },
  },
]);

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
      <Toaster className="z-[100]" />
    </QueryClientProvider>
  );
}

export default App;
