export const expenseStatuses = [
  {
    value: 'open',
    label: 'Open',
  },
  {
    value: 'submitted',
    label: 'Submitted',
  },
  {
    value: 'approved',
    label: 'Approved',
  },
  {
    value: 'rejected',
    label: 'Rejected',
  },
]