//@ts-nocheck
import _ from "lodash";
import React, { useRef } from "react";
import { useFormContext } from "react-hook-form";

import {
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Combobox } from "./Combobox";

export function ComboboxField({
  name,
  label,
  className,
  showErrorMessage = true,
  disabled = false,
  ...props
}) {
  const containerRef = useRef(null);

  const {
    control,
    setValue,
    formState: { errors },
  } = useFormContext();

  return (
    <FormField
      control={control}
      name={name}
      render={({ field }) => {
        return (
          <FormItem ref={containerRef} className={className}>
            {label && <FormLabel>{label}</FormLabel>}
            <Combobox
              value={field.value}
              containerRef={containerRef}
              onSelect={(value) => setValue(name, value)}
              className={_.get(errors, name) ? "border-[red]" : ""}
              {...props}
              disabled={disabled}
            />
            {showErrorMessage && <FormMessage />}
          </FormItem>
        );
      }}
    />
  );
}
