import { FC } from "react";
import { useFormContext } from "react-hook-form";

import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "../../lib/utils";

export const CheckboxField: FC<{
  name: string;
  label?: string;
  className?: string;
  readOnly?: boolean;
}> = ({ name, label, className, readOnly = false }) => {
  const { control } = useFormContext();

  return (
    <FormField
      control={control}
      name={name}
      render={({ field }) => (
        <FormItem
          className={cn(
            "flex items-center space-y-0 gap-2 justify-between",
            className
          )}
        >
          {label && <FormLabel className="text-base">{label}</FormLabel>}
          <FormControl>
            <Checkbox
              checked={field.value}
              onCheckedChange={!readOnly ? field.onChange : () => {}}
              // disabled={readOnly}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
