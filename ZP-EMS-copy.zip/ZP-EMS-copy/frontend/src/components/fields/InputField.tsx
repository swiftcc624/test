//@ts-nocheck
import _ from "lodash";
import { FC } from "react";
import { useFormContext } from "react-hook-form";

import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

import { Input } from "@/components/ui/input";

export const InputField: FC<{
  name: string;
  label?: string;
  type?: string;
  readOnly?: boolean;
  disabled?: boolean;
  className?: string;
  placeholder?: string;
  showErrorMessage?: boolean;
}> = ({
  name,
  label,
  type,
  readOnly = false,
  disabled = false,
  placeholder,
  showErrorMessage = true,
  ...rest
}) => {
  const {
    control,
    formState: { errors },
  } = useFormContext();

  return (
    <FormField
      control={control}
      name={name}
      render={({ field }) => (
        <FormItem {...rest}>
          {label && <FormLabel>{label}</FormLabel>}
          <FormControl>
            <Input
              type={type ? type : "text"}
              readOnly={readOnly}
              disabled={disabled}
              placeholder={placeholder}
              className={_.get(errors, name) ? "border-[red]" : ""}
              {...field}
            />
          </FormControl>
          {showErrorMessage && <FormMessage />}
        </FormItem>
      )}
    />
  );
};
