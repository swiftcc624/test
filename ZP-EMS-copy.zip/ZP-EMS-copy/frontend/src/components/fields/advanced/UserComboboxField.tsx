import { FC } from "react";
import { useQuery } from "@tanstack/react-query";

import { getUsers } from "@/api/users";

import { ComboboxField } from "../ComboboxField";

export const UserComboboxField: FC<{
  name: string;
  label?: string;
  userType: string;
  className?: string;
  readOnly?: boolean;
}> = ({ name, label, userType, className, readOnly = false }) => {
  const { data: users } = useQuery({
    queryKey: ["users", "all", userType],
    queryFn: async () => {
      return await getUsers({ userType, limit: -1 });
    },
  });

  return (
    <ComboboxField
      name={name}
      label={label}
      options={users?.items || []}
      getOptionLabel={(option: any) => option.name}
      getOptionValue={(option: any) => option._id}
      className={className}
      readOnly={readOnly}
    />
  );
};
