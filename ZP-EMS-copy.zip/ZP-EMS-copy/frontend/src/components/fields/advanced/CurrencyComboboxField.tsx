import { FC } from "react";
import { useQuery } from "@tanstack/react-query";

import { getActiveCurrencies } from "@/api/currencies";

import { ComboboxField } from "../ComboboxField";

export const CurrencyComboboxField: FC<{
  name: string;
  label?: string;
  className?: string;
  readOnly?: boolean;
  disabled?: boolean;
}> = ({ name, label, className, readOnly = false, disabled = false }) => {
  const { data } = useQuery({
    queryKey: ["currencies", "active"],
    queryFn: async () => {
      const currencies = await getActiveCurrencies();
      return currencies?.items || [];
    },
  });

  return (
    <ComboboxField
      name={name}
      label={label}
      options={data || []}
      getOptionLabel={(option: any) => option.symbol}
      getOptionValue={(option: any) => option._id}
      className={className}
      readOnly={readOnly}
      disabled={disabled}
    />
  );
};
