import { FC, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";

import { getItems } from "@/api/items";

import { ComboboxField } from "../ComboboxField";
import { useWatch } from "react-hook-form";

export const ItemComboboxField: FC<{
  name: string;
  label?: string;
  className?: string;
  readOnly?: boolean;
  onSelect?: (value: any) => void;
  showErrorMessage?: boolean;
}> = ({
  name,
  label,
  className,
  readOnly = false,
  onSelect,
  showErrorMessage = true,
}) => {
  const selected = useWatch({ name });
  const { data } = useQuery({
    queryKey: ["items", "all"],
    queryFn: async () => {
      return await getItems({ limit: -1 });
    },
  });

  useEffect(() => {
    if (selected && data?.items) {
      const item = data.items.find((item: any) => item._id === selected);
      if (item) {
        onSelect?.(item);
      }
    }
  }, [selected, data]);

  return (
    <ComboboxField
      name={name}
      label={label}
      options={data?.items || []}
      getOptionLabel={(option: any) => option.name}
      getOptionValue={(option: any) => option._id}
      className={className}
      readOnly={readOnly}
      showErrorMessage={showErrorMessage}
    />
  );
};
