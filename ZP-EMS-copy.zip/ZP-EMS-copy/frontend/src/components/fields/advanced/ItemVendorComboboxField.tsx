import { FC } from "react";
import { useQuery } from "@tanstack/react-query";

import { ComboboxField } from "../ComboboxField";
import { getItemVendors } from "@/api/itemVendors";

export const ItemVendorComboboxField: FC<{
  name: string;
  label?: string;
  className?: string;
  readOnly?: boolean;
  itemId: string;
}> = ({ name, label, className, readOnly = false, itemId }) => {
  const { data: itemVendors } = useQuery({
    queryKey: ["itemVendors", itemId],
    queryFn: async () => {
      return await getItemVendors({ itemId, limit: -1 });
    },
  });

  return (
    <ComboboxField
      name={name}
      label={label}
      options={itemVendors?.items || []}
      getOptionLabel={(option: any) => option.vendor.name}
      getOptionValue={(option: any) => option.vendor.id}
      className={className}
      readOnly={readOnly}
    />
  );
};
