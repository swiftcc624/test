import { FC, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";

import { getExpenseReports } from "@/api/expenseReports";

import { ComboboxField } from "../ComboboxField";

export const ExpenseReportComboboxField: FC<{
  name: string;
  label?: string;
  className?: string;
  readOnly?: boolean;
}> = ({ name, label, className, readOnly = false }) => {
  const { data } = useQuery({
    queryKey: ["expenseReports", "all"],
    queryFn: async () => {
      return await getExpenseReports({ limit: -1 });
    },
  });

  console.log("data", data);

  const options = useMemo(() => {
    return data?.items || [];
  }, [data]);

  return (
    <ComboboxField
      name={name}
      label={label}
      options={[{ id: "", memo: "None" }, ...options]}
      getOptionLabel={(option: any) => option.memo}
      getOptionValue={(option: any) => option.id}
      className={className}
      readOnly={readOnly}
    />
  );
};
