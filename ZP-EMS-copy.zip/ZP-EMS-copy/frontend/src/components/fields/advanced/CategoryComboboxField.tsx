import { FC } from "react";
import { useQuery } from "@tanstack/react-query";

import { getActiveCategories } from "@/api/categories";

import { ComboboxField } from "../ComboboxField";

export const CategoryComboboxField: FC<{
  name: string;
  label?: string;
  className?: string;
  readOnly?: boolean;
  additionalOptions?: any[];
}> = ({ name, label, className, readOnly = false, additionalOptions = [] }) => {
  const { data } = useQuery({
    queryKey: ["categories", "active"],
    queryFn: async () => {
      const categories = await getActiveCategories();
      return categories;
    },
  });

  const options = [...additionalOptions, ...(data?.items || [])];

  return (
    <ComboboxField
      name={name}
      label={label}
      options={options}
      getOptionLabel={(option: any) => option.name}
      getOptionValue={(option: any) => option.id}
      className={className}
      readOnly={readOnly}
    />
  );
};
