//@ts-nocheck
import axios from "axios";
import qs from "qs";

const apiInstance = () =>
  axios.create({
    baseURL: import.meta.env.VITE_API_URL + "/vendors",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + localStorage.getItem("accessToken"),
    },
  });

export const getVendor = async (id) => {
  const response = await apiInstance().get(`/${id}`);
  return response.data;
};

export const updateVendor = async (id, data) => {
  const response = await apiInstance().patch(`/${id}`, data);
  return response.data;
};
