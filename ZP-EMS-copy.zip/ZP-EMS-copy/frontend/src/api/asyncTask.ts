//@ts-nocheck
import axios from "axios";
import qs from "qs";

const apiInstance = () =>
  axios.create({
    baseURL: import.meta.env.VITE_API_URL + "/async-tasks",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + localStorage.getItem("accessToken"),
    },
  });

export const getAsyncTasks = async (queryParams = {}) => {
  const response = await apiInstance().get(`/?${qs.stringify(queryParams)}`);

  return response.data;
};

export const createAsyncTask = async (asyncTaskData) => {
  const response = await apiInstance().post("/", asyncTaskData);
  return response.data;
};

// export const updateAsyncTask = async (asyncTaskId, asyncTaskData) => {
//   const response = await apiInstance().patch(`/${asyncTaskId}`, asyncTaskData);
//   return response.data;
// };

// export const deleteAsyncTask = async (asyncTaskId) => {
//   const response = await apiInstance().delete(`/${asyncTaskId}`);
//   return response.data;
// };

// export const runAsyncTasks = async () => {
//   const response = await apiInstance().post("/run");
//   return response.data;
// };
