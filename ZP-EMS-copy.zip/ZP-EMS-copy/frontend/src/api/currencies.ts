import axios from "axios";
import qs from "qs";

const apiInstance = () =>
  axios.create({
    baseURL: import.meta.env.VITE_API_URL + "/currencies",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + localStorage.getItem("accessToken"),
    },
  });

export const updateCurrency = async (currencyId: string, currencyData: any) => {
  const response = await apiInstance().patch(`/${currencyId}`, currencyData);
  return response.data;
};

export const getCurrencies = async (queryParams = {}) => {
  const response = await apiInstance().get(`/?${qs.stringify(queryParams)}`);
  return response.data;
};

export const getActiveCurrencies = async () => {
  const currencies = await getCurrencies({
    status: "active",
    limit: -1,
  });
  return currencies;
};

export const createCurrency = async (currencyData: any) => {
  const response = await apiInstance().post("/", currencyData);
  return response.data;
};

export const deleteCurrency = async (currencyId: string) => {
  const response = await apiInstance().delete(`/${currencyId}`);
  return response.data;
};
