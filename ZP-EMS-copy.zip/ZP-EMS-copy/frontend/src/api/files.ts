// @ts-nocheck
import axios from "axios";

const apiInstance = () =>
  axios.create({
    baseURL: import.meta.env.VITE_API_URL + "/files",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + localStorage.getItem("accessToken"),
    },
  });

// TODO: deprecate uploadFile and use uploadFile2
export const uploadFile = async (file) => {
  const formData = new FormData();
  formData.append("file", file);

  const response = await apiInstance().post("/upload", formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });

  return response.data;
};

export const uploadFile2 = async (file) => {
  const formData = new FormData();
  formData.append("file", file);

  const response = await apiInstance().post("/upload2", formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });

  return response.data;
};
