import axios from "axios";
import qs from "qs";

const apiInstance = () =>
  axios.create({
    baseURL: import.meta.env.VITE_API_URL + "/items",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + localStorage.getItem("accessToken"),
    },
  });

export const getItems = async (queryParams = {}) => {
  const response = await apiInstance().get(`/?${qs.stringify(queryParams)}`);
  return response.data;
};

export const createItem = async (itemData: any) => {
  const response = await apiInstance().post("/", itemData);
  return response.data;
};

export const updateItem = async (itemId: string, itemData: any) => {
  const response = await apiInstance().patch(`/${itemId}`, itemData);
  return response.data;
};

export const deleteItem = async (itemId: string) => {
  const response = await apiInstance().delete(`/${itemId}`);
  return response.data;
};
