import axios from "axios";
// @ts-ignore
import qs from "qs";

const apiInstance = () =>
  axios.create({
    baseURL: import.meta.env.VITE_API_URL + "/transactions",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + localStorage.getItem("accessToken"),
    },
  });

export const getTransactions = async (queryParams = {}) => {
  const response = await apiInstance().get(`/?${qs.stringify(queryParams)}`);
  return response.data;
};

export const getTransaction = async (transactionId: string) => {
  const response = await apiInstance().get(`/${transactionId}`);
  return response.data;
};

export const createTransaction = async (transactionData: any) => {
  const response = await apiInstance().post("/", transactionData);
  return response.data;
};

export const updateTransaction = async (
  transactionId: string,
  transactionData: any
) => {
  const response = await apiInstance().patch(
    `/${transactionId}`,
    transactionData
  );
  return response.data;
};

export const deleteTransaction = async (transactionId: string) => {
  const response = await apiInstance().delete(`/${transactionId}`);
  return response.data;
};
