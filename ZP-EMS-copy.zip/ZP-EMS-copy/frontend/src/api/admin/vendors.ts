import axios from "axios";
import qs from "qs";

const apiInstance = () =>
  axios.create({
    baseURL: import.meta.env.VITE_API_URL + "/admin/vendors",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + localStorage.getItem("accessToken"),
    },
  });

export const getVendors = async (queryParams = {}) => {
  const response = await apiInstance().get(`/?${qs.stringify(queryParams)}`);
  return response.data;
};

export const getVendor = async (id: string) => {
  const response = await apiInstance().get(`/${id}`);
  return response.data;
};

export const createVendor = async (data: any) => {
  const response = await apiInstance().post("/", data);
  return response.data;
};

export const updateVendor = async (id: string, data: any) => {
  const response = await apiInstance().patch(`/${id}`, data);
  return response.data;
};

export const deleteVendor = async (id: string) => {
  const response = await apiInstance().delete(`/${id}`);
  return response.data;
};

export const inviteVendor = async ({ email }: any) => {
  const response = await apiInstance().post("/invite", { email });
  return response.data;
};
