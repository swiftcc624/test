import axios from "axios";
import qs from "qs";

const apiInstance = () =>
  axios.create({
    baseURL: import.meta.env.VITE_API_URL + "/users",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + localStorage.getItem("accessToken"),
    },
  });

// export const updateProfile = async ({ name, email }) => {
//   const response = await apiInstance().post("/update-profile", { name, email });
//   return response.data;
// };

export const getProfile = async () => {
  // const api = axios.create({
  //   baseURL: import.meta.env.VITE_API_URL + "/",
  //   headers: {
  //     "Content-Type": "application/json",
  //     Authorization: "Bearer " + localStorage.getItem("accessToken"),
  //   },
  // });

  const response = await apiInstance().get("/profile");
  return response.data;
};

export const updateUser = async (userId: string, userData: any) => {
  const response = await apiInstance().patch(`/${userId}`, userData);
  return response.data;
};

export const getUsers = async (queryParams = {}) => {
  const response = await apiInstance().get(`/?${qs.stringify(queryParams)}`);
  return response.data;
};

export const createUser = async (userData: any) => {
  const response = await apiInstance().post("/", userData);
  return response.data;
};

export const deleteUser = async (userId: string) => {
  const response = await apiInstance().delete(`/${userId}`);
  return response.data;
};

export const changePassword = async ({ oldPassword, newPassword }: any) => {
  const response = await apiInstance().post("/profile/change-password", {
    oldPassword,
    newPassword,
  });
  return response.data;
};
