import qs from "qs";
import axios from "axios";

const apiInstance = () =>
  axios.create({
    baseURL: import.meta.env.VITE_API_URL + "/categories",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + localStorage.getItem("accessToken"),
    },
  });

export const updateCategory = async (categoryId: string, categoryData: any) => {
  const response = await apiInstance().patch(`/${categoryId}`, categoryData);
  return response.data;
};

export const getCategories = async (queryParams = {}) => {
  const response = await apiInstance().get(`/?${qs.stringify(queryParams)}`);
  return response.data;
};

export const getActiveCategories = async () => {
  const categories = await getCategories({
    status: "active",
    limit: -1,
  });
  return categories;
};

export const createCategory = async (categoryData: any) => {
  const response = await apiInstance().post("/", categoryData);
  return response.data;
};

export const deleteCategory = async (categoryId: string) => {
  const response = await apiInstance().delete(`/${categoryId}`);
  return response.data;
};
