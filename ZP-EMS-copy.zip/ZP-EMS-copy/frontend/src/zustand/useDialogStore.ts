import { create } from "zustand";

export enum DIALOG_ID {
  ADD_TIME_ENTRY = "ADD_TIME_ENTRY",
  EDIT_TIME_ENTRY = "EDIT_TIME_ENTRY",
  EDIT_TIME_ENTRY_DESCRIPTION = "EDIT_TIME_ENTRY_DESCRIPTION",

  INVITE_VENDOR = "INVITE_VENDOR",
  ADD_VENDOR = "ADD_VENDOR", // deprecated
  EDIT_TASK = "EDIT_TASK",
  SYNC2 = "SYNC2",
  DELETE_CONFIRMATION = "DELETE_CONFIRMATION",

  ADD_USER = "ADD_USER",
  EDIT_USER = "EDIT_USER",
  ADD_CATEGORY = "ADD_CATEGORY",
  EDIT_CATEGORY = "EDIT_CATEGORY",
  ADD_CURRENCY = "ADD_CURRENCY",
  EDIT_CURRENCY = "EDIT_CURRENCY",
  ADD_EXPENSE = "ADD_EXPENSE",
  EDIT_EXPENSE = "EDIT_EXPENSE",
  ADD_EXPENSE_REPORT = "ADD_EXPENSE_REPORT",
  EDIT_EXPENSE_REPORT = "EDIT_EXPENSE_REPORT",
  ADD_PURCHASE_REQUISITION = "ADD_PURCHASE_REQUISITION",
  EDIT_PURCHASE_REQUISITION = "EDIT_PURCHASE_REQUISITION",

  EXPENSE_GROUP = "EXPENSE_GROUP",
}

type DialogStore = {
  dialogs: Partial<Record<DIALOG_ID, { open: boolean; dialogData: any }>>;
  openDialog: (id: DIALOG_ID, dialogData?: any) => void;
  closeDialog: (id: DIALOG_ID) => void;
  isDialogOpen: (id: DIALOG_ID) => boolean;
  getDialogData: (id: DIALOG_ID) => any;
  setDialogData: (id: DIALOG_ID, dialogData: any) => void;
};

export const useDialogStore = create<DialogStore>()((set, get) => ({
  dialogs: {},

  openDialog: (id, dialogData = null) =>
    set((state) => ({
      dialogs: {
        ...state.dialogs,
        [id]: { ...state.dialogs[id], open: true, dialogData },
      },
    })),

  closeDialog: (id) =>
    set((state) => ({
      dialogs: {
        ...state.dialogs,
        [id]: { open: false, dialogData: null },
      },
    })),

  isDialogOpen: (id) => get().dialogs[id]?.open || false,
  getDialogData: (id) => get().dialogs[id]?.dialogData || {},
  setDialogData: (id, dialogData) =>
    set((state) => ({
      dialogs: {
        ...state.dialogs,
        [id]: { ...state.dialogs[id], dialogData },
      },
    })),
}));

export const dialogActions = {
  openDialog: (id: DIALOG_ID, dialogData: any = null) =>
    useDialogStore.getState().openDialog(id, dialogData),
  closeDialog: (id: DIALOG_ID) => useDialogStore.getState().closeDialog(id),
  isDialogOpen: (id: DIALOG_ID) => useDialogStore.getState().isDialogOpen(id),
  getDialogData: (id: DIALOG_ID) => useDialogStore.getState().getDialogData(id),
  setDialogData: (id: DIALOG_ID, dialogData: any) =>
    useDialogStore.getState().setDialogData(id, dialogData),
};
