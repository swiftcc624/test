#!/bin/sh

ssh zpems "source ~/.nvm/nvm.sh && cd /home/ubuntu/www/ZP-EMS/express/ && git reset --hard HEAD && git pull && yarn && pm2 restart 0"